// === ai.js — Modul AI Edit Teks (Groq) ===
// Flow:
//   1. /ai (reply teks) → AI tanya "apa yang perlu diedit?"
//   2. User jawab → AI edit, kirim hasil + tombol format
//   3. User pilih format atau minta revisi
//   4. /done atau /batal → selesai
//
// Tambahkan di config.js:
//   GROQ_API_KEY: 'gsk_...'

const fs = require('fs');
const axios = require('axios');
const { Markup } = require('telegraf');

const AI_USAGE_FILE = './ai_usage.json';
const AI_FREE_LIMIT = 3;
const GROQ_URL = 'https://api.groq.com/openai/v1/chat/completions';
const GROQ_MODEL = 'llama-3.1-8b-instant';

// === Usage tracker ===
const getAiUsage = (userId) => {
  try {
    if (!fs.existsSync(AI_USAGE_FILE)) return { count: 0, date: '' };
    const data = JSON.parse(fs.readFileSync(AI_USAGE_FILE));
    const today = new Date().toDateString();
    const entry = data[userId];
    if (!entry || entry.date !== today) return { count: 0, date: today };
    return entry;
  } catch { return { count: 0, date: '' }; }
};

const incrementAiUsage = (userId) => {
  try {
    const data = fs.existsSync(AI_USAGE_FILE) ? JSON.parse(fs.readFileSync(AI_USAGE_FILE)) : {};
    const today = new Date().toDateString();
    const cur = data[userId]?.date === today ? data[userId].count : 0;
    data[userId] = { count: cur + 1, date: today };
    fs.writeFileSync(AI_USAGE_FILE, JSON.stringify(data, null, 2));
  } catch {}
};

const canUseAi = (userId, isPremium) => {
  if (isPremium(userId)) return true;
  return getAiUsage(userId).count < AI_FREE_LIMIT;
};

const aiUsageLeft = (userId, isPremium) => {
  if (isPremium(userId)) return '∞';
  return Math.max(0, AI_FREE_LIMIT - getAiUsage(userId).count);
};

// === Format teks ===
// Escape HTML untuk teks biasa
const escapeHtml = (text) =>
  text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

const applyFormat = (text, fmt) => {
  const escaped = escapeHtml(text);
  switch (fmt) {
    case 'quote':   return `<blockquote>${escaped}</blockquote>`;
    case 'mono':    return `<code>${escaped}</code>`;
    case 'bold':    return `<b>${escaped}</b>`;
    case 'italic':  return `<i>${escaped}</i>`;
    case 'ai':      return null; // biarkan AI yang format
    default:        return escaped;
  }
};

// Tombol format yang ditampilkan setelah AI kirim hasil
const formatKeyboard = (userId) => Markup.inlineKeyboard([
  [
    Markup.button.callback('💬 Quote',  `aifmt_${userId}_quote`),
    Markup.button.callback('🔤 Mono',   `aifmt_${userId}_mono`),
  ],
  [
    Markup.button.callback('𝗕 Bold',   `aifmt_${userId}_bold`),
    Markup.button.callback('𝘐 Italic', `aifmt_${userId}_italic`),
  ],
  [
    Markup.button.callback('✨ Biarkan AI format', `aifmt_${userId}_ai`),
  ],
  [
    Markup.button.callback('✅ Selesai', `aifmt_${userId}_done`),
  ]
]);

// === Groq API ===
const callGroq = async (apiKey, messages) => {
  const response = await axios.post(
    GROQ_URL,
    { model: GROQ_MODEL, max_tokens: 1024, temperature: 0.7, messages },
    {
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
      timeout: 30000
    }
  );
  return response.data?.choices?.[0]?.message?.content?.trim();
};

// === Session store ===
// userId -> { originalText, lastResult, history, waitingReply }
const aiSessions = new Map();

module.exports = (bot, config, isPremium) => {

  // /done atau /batal — akhiri sesi
  bot.command(['done', 'batal'], async (ctx) => {
    const userId = ctx.from.id;
    if (!aiSessions.has(userId)) return;
    aiSessions.delete(userId);
    ctx.reply(
      `<blockquote>✅ <b>Sesi AI selesai.</b>\n\nKetik /ai lagi untuk memulai sesi baru.</blockquote>`,
      { parse_mode: 'HTML' }
    );
  });

  // Handler tombol format
  bot.action(/^aifmt_(\d+)_(quote|mono|bold|italic|ai|done)$/, async (ctx) => {
    ctx.answerCbQuery().catch(() => {});
    const userId = parseInt(ctx.match[1]);
    const fmt = ctx.match[2];

    // Hanya user pemilik sesi yang bisa klik
    if (ctx.from.id !== userId) {
      return ctx.answerCbQuery('❌ Bukan sesimu!', { show_alert: true });
    }

    const session = aiSessions.get(userId);
    if (!session?.lastResult) {
      return ctx.answerCbQuery('❌ Sesi tidak ditemukan.', { show_alert: true });
    }

    if (fmt === 'done') {
      aiSessions.delete(userId);
      await ctx.editMessageReplyMarkup({ inline_keyboard: [] }).catch(() => {});
      return ctx.reply(
        `<blockquote>✅ <b>Sesi AI selesai.</b>\n\nKetik /ai lagi untuk memulai sesi baru.</blockquote>`,
        { parse_mode: 'HTML' }
      );
    }

    if (fmt === 'ai') {
      // Minta AI format sendiri
      const loadingMsg = await ctx.reply('✨ <b>AI sedang memformat...</b>', { parse_mode: 'HTML' });
      try {
        const formatHistory = [
          ...session.history,
          {
            role: 'user',
            content:
              'Sekarang format teks hasil editanmu dengan format Telegram HTML yang paling sesuai. ' +
              'Gunakan kombinasi <b>, <i>, <code>, atau <blockquote> sesuai konteks teks. ' +
              'Kembalikan HANYA teks dengan tag HTML Telegram, tanpa penjelasan.'
          }
        ];
        const result = await callGroq(config.GROQ_API_KEY, formatHistory);
        await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
        await ctx.editMessageReplyMarkup({ inline_keyboard: [] }).catch(() => {});
        await ctx.reply(result, { parse_mode: 'HTML', ...formatKeyboard(userId) });
        session.lastResult = result;
      } catch {
        await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
        ctx.reply('❌ AI gagal memformat. Coba lagi.');
      }
      return;
    }

    // Format manual
    const formatted = applyFormat(session.lastResult, fmt);
    await ctx.editMessageReplyMarkup({ inline_keyboard: [] }).catch(() => {});
    await ctx.reply(formatted, { parse_mode: 'HTML', ...formatKeyboard(userId) });
    session.lastResult = session.lastResult; // tetap simpan teks asli untuk re-format
  });

  // /ai — mulai sesi
  bot.command('ai', async (ctx) => {
    const userId = ctx.from.id;

    if (!config.GROQ_API_KEY) {
      return ctx.reply('❌ Fitur AI belum dikonfigurasi. Hubungi owner.');
    }

    if (!canUseAi(userId, isPremium)) {
      return ctx.reply(
        `<blockquote>🚫 <b>Batas AI Habis</b>\n\n` +
        `Kamu sudah menggunakan AI <b>${AI_FREE_LIMIT}x</b> hari ini.\n` +
        `Reset besok atau upgrade ke <b>Premium</b> untuk unlimited! ✨</blockquote>`,
        { parse_mode: 'HTML' }
      );
    }

    // Ambil teks dari reply atau argumen
    let inputText = '';
    if (ctx.message.reply_to_message?.text) {
      inputText = ctx.message.reply_to_message.text;
    } else if (ctx.message.reply_to_message?.caption) {
      inputText = ctx.message.reply_to_message.caption;
    } else {
      inputText = ctx.message.text.split(' ').slice(1).join(' ').trim();
    }

    if (!inputText) {
      return ctx.reply(
        `<blockquote>✨ <b>Kanjud AI — Edit Teks</b>\n\n` +
        `Cara pakai:\n` +
        `• Reply teks/caption lalu ketik <code>/ai</code>\n` +
        `• Atau <code>/ai [teks langsung]</code>\n\n` +
        `Format tersedia: Quote, Mono, Bold, Italic, atau biarkan AI pilih!\n\n` +
        `Sisa hari ini: <b>${aiUsageLeft(userId, isPremium)}x</b></blockquote>`,
        { parse_mode: 'HTML' }
      );
    }

    if (inputText.length > 3000) {
      return ctx.reply('❌ Teks terlalu panjang. Maksimal 3000 karakter.');
    }

    if (aiSessions.has(userId)) aiSessions.delete(userId);

    const systemPrompt = {
      role: 'system',
      content:
        'Kamu adalah Kanjud AI, asisten pengedit teks yang ramah dan siap membantu siapapun yang ingin mengedit teks atau file. ' +
        'Kamu akan diberikan sebuah teks oleh user. ' +
        'Tugasmu: tanya kepada user apa yang ingin diubah/diperbaiki dari teks tersebut, ' +
        'lalu edit sesuai permintaan mereka. ' +
        'Setelah mengirim hasil editan, tanya apakah ada yang perlu direvisi lagi. ' +
        'Selalu jawab dalam Bahasa Indonesia dengan gaya yang friendly dan semangat. ' +
        'Saat mengirim hasil editan, tulis HANYA teks hasil editan tanpa label atau penjelasan tambahan.'
    };

    const firstUserMsg = {
      role: 'user',
      content: `Ini teks yang ingin saya edit:\n\n${inputText}`
    };

    const history = [systemPrompt, firstUserMsg];
    const loadingMsg = await ctx.reply('✨ <b>Kanjud AI sedang membaca teks...</b>', { parse_mode: 'HTML' });

    try {
      const reply = await callGroq(config.GROQ_API_KEY, history);
      if (!reply) throw new Error('Respons AI kosong');

      history.push({ role: 'assistant', content: reply });
      aiSessions.set(userId, { originalText: inputText, lastResult: null, history, waitingReply: true });

      await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
      await ctx.reply(
        `<blockquote>✨ <b>Kanjud AI</b>\nKetik <code>/done</code> atau <code>/batal</code> untuk selesai.</blockquote>\n\n` +
        `${reply}`,
        { parse_mode: 'HTML' }
      );

    } catch (err) {
      await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
      console.error('Groq error:', err.message);
      if (err.response?.status === 429) return ctx.reply('⏳ AI sedang sibuk. Coba lagi sebentar.');
      if (err.response?.status === 401) return ctx.reply('❌ API key Groq tidak valid. Hubungi owner.');
      ctx.reply('❌ AI gagal merespons. Coba lagi nanti.');
    }
  });

  // Handler pesan biasa — lanjutkan sesi
  bot.on('text', async (ctx, next) => {
    const userId = ctx.from.id;
    const session = aiSessions.get(userId);

    if (!session || !session.waitingReply) return next();
    if (ctx.message.text.startsWith('/')) return next();

    const userMsg = ctx.message.text.trim();
    session.history.push({ role: 'user', content: userMsg });

    const loadingMsg = await ctx.reply('✨ <b>Kanjud AI sedang memproses...</b>', { parse_mode: 'HTML' });

    try {
      const reply = await callGroq(config.GROQ_API_KEY, session.history);
      if (!reply) throw new Error('Respons AI kosong');

      session.history.push({ role: 'assistant', content: reply });
      session.lastResult = reply;
      incrementAiUsage(userId);
      const left = aiUsageLeft(userId, isPremium);

      await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});

      // Kirim hasil + tombol format
      await ctx.reply(
        `${escapeHtml(reply)}\n\n` +
        `<blockquote><i>Sisa hari ini: <b>${left}x</b> | Pilih format atau lanjut chat</i></blockquote>`,
        { parse_mode: 'HTML', ...formatKeyboard(userId) }
      );

    } catch (err) {
      await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
      console.error('Groq error:', err.message);
      if (err.response?.status === 429) return ctx.reply('⏳ AI sedang sibuk. Coba lagi sebentar.');
      ctx.reply('❌ AI gagal merespons. Coba lagi nanti.');
    }
  });

};
