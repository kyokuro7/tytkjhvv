// === download.js ===
// /dl — TikTok (video + audio) & GitHub
// Khusus Premium, Admin, Owner

const fs   = require('fs');
const path = require('path');
const axios = require('axios');

const TEMP_DIR = './temp/';
const ensureTemp = () => { if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true }); };
const cleanTemp  = (f) => { try { if (f && fs.existsSync(f)) fs.unlinkSync(f); } catch {} };

// Cache untuk format picker
const urlCache = new Map();
let urlCacheCounter = 0;
const saveUrl = (data) => {
  const id = (++urlCacheCounter).toString();
  urlCache.set(id, data);
  if (urlCache.size > 100) urlCache.delete(urlCache.keys().next().value);
  return id;
};

// ─────────────────────────────────────────
// Ambil URL dari pesan Telegram
// ─────────────────────────────────────────
const extractUrl = (ctx) => {
  const msg  = ctx.message;
  const text = msg.text || '';
  for (const ent of (msg.entities || [])) {
    if (ent.type === 'url') {
      const raw = text.slice(ent.offset, ent.offset + ent.length);
      if (raw && !raw.startsWith('/')) return raw.trim();
    }
    if (ent.type === 'text_link' && ent.url) return ent.url.trim();
  }
  const parts = text.trim().split(/\s+/);
  return parts.slice(1).join('').replace(/[\u200B-\u200D\uFEFF\u00A0<>]/g, '').trim() || null;
};

// ─────────────────────────────────────────
// Deteksi platform
// ─────────────────────────────────────────
const detectPlatform = (url) => {
  if (!url) return null;
  const lower = url.toLowerCase();
  if (lower.includes('tiktok.com') || lower.includes('vm.tiktok') || lower.includes('vt.tiktok'))
    return { platform: 'tiktok', url };
  if (lower.includes('github.com/'))
    return { platform: 'github', url };
  return null;
};

// ─────────────────────────────────────────
// Kirim video — coba URL langsung dulu, fallback download
// ─────────────────────────────────────────
const sendVideoSmart = async (ctx, fileUrl, caption, filename) => {
  try {
    await ctx.replyWithVideo(fileUrl, { caption, parse_mode: 'HTML', supports_streaming: true });
    return;
  } catch (e) {
    console.log('[send] direct failed, downloading...', e.message);
  }
  ensureTemp();
  const tmp = path.join(TEMP_DIR, `dl_${Date.now()}_${filename}`);
  try {
    const resp = await axios.get(fileUrl, {
      responseType: 'arraybuffer', timeout: 90000,
      maxContentLength: 47 * 1024 * 1024,
      headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://www.tiktok.com/' },
    });
    const buf = Buffer.from(resp.data);
    if (buf.length > 45 * 1024 * 1024) {
      return ctx.reply(`<blockquote>⚠️ File terlalu besar (${(buf.length/1024/1024).toFixed(1)}MB)\n\n🔗 <code>${fileUrl.slice(0,200)}</code></blockquote>`, { parse_mode: 'HTML' });
    }
    fs.writeFileSync(tmp, buf);
    await ctx.replyWithVideo({ source: fs.createReadStream(tmp), filename }, { caption, parse_mode: 'HTML', supports_streaming: true });
  } finally { cleanTemp(tmp); }
};

const sendAudioSmart = async (ctx, fileUrl, caption, filename) => {
  try {
    await ctx.replyWithAudio(fileUrl, { caption, parse_mode: 'HTML', title: filename });
    return;
  } catch (e) {
    console.log('[send] direct audio failed, downloading...', e.message);
  }
  ensureTemp();
  const tmp = path.join(TEMP_DIR, `dl_${Date.now()}_${filename}`);
  try {
    const resp = await axios.get(fileUrl, {
      responseType: 'arraybuffer', timeout: 60000,
      maxContentLength: 47 * 1024 * 1024,
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    const buf = Buffer.from(resp.data);
    if (buf.length > 45 * 1024 * 1024) {
      return ctx.reply(`<blockquote>⚠️ File terlalu besar.\n🔗 <code>${fileUrl.slice(0,200)}</code></blockquote>`, { parse_mode: 'HTML' });
    }
    fs.writeFileSync(tmp, buf);
    await ctx.replyWithAudio({ source: fs.createReadStream(tmp), filename }, { caption, parse_mode: 'HTML' });
  } finally { cleanTemp(tmp); }
};

const sendDocSmart = async (ctx, fileUrl, caption, filename) => {
  try {
    await ctx.replyWithDocument(fileUrl, { caption, parse_mode: 'HTML' });
    return;
  } catch (e) {
    console.log('[send] direct doc failed, downloading...', e.message);
  }
  ensureTemp();
  const tmp = path.join(TEMP_DIR, `dl_${Date.now()}_${filename}`);
  try {
    const resp = await axios.get(fileUrl, {
      responseType: 'arraybuffer', timeout: 90000,
      maxContentLength: 47 * 1024 * 1024,
      headers: { 'User-Agent': 'Mozilla/5.0' },
    });
    const buf = Buffer.from(resp.data);
    if (buf.length > 45 * 1024 * 1024) {
      return ctx.reply(`<blockquote>⚠️ File terlalu besar.\n🔗 <code>${fileUrl.slice(0,200)}</code></blockquote>`, { parse_mode: 'HTML' });
    }
    fs.writeFileSync(tmp, buf);
    await ctx.replyWithDocument({ source: fs.createReadStream(tmp), filename }, { caption, parse_mode: 'HTML' });
  } finally { cleanTemp(tmp); }
};

// ─────────────────────────────────────────
// TIKTOK — tikwm.com
// ─────────────────────────────────────────
const getTiktokInfo = async (url) => {
  // Resolve + bersihkan URL
  let finalUrl = url;
  if (!url.includes('/video/')) {
    try {
      const r = await axios.get(url, {
        maxRedirects: 10, timeout: 10000,
        headers: { 'User-Agent': 'Mozilla/5.0' },
        validateStatus: () => true,
      });
      const resolved = r.request?.res?.responseUrl || r.config?.url || url;
      finalUrl = resolved.split('?')[0];
    } catch { finalUrl = url.split('?')[0]; }
  } else {
    finalUrl = url.split('?')[0];
  }
  console.log('[tiktok] clean url:', finalUrl);

  const resp = await axios.post(
    'https://www.tikwm.com/api/',
    new URLSearchParams({ url: finalUrl, count: 1, cursor: 0, web: 1, hd: 1 }),
    {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'Referer': 'https://www.tikwm.com/',
      },
      timeout: 20000,
    }
  );

  const d = resp.data;
  if (!d || d.code !== 0) throw new Error(d?.msg || 'TikTok API error');
  const data = d.data;

  // play = muxed (video+audio), hdplay = video only
  const rawVideo = data.play || data.wmplay || data.hdplay;
  const videoUrl = rawVideo?.startsWith('http') ? rawVideo : `https://www.tikwm.com${rawVideo}`;

  // music URL
  const rawMusic = data.music || null;
  const musicUrl = rawMusic ? (rawMusic.startsWith('http') ? rawMusic : `https://www.tikwm.com${rawMusic}`) : null;

  console.log('[tiktok] video:', videoUrl?.slice(0, 80));
  console.log('[tiktok] music:', musicUrl?.slice(0, 80));

  return {
    videoUrl, musicUrl,
    title: data.title || 'TikTok Video',
    author: data.author?.nickname || '',
    musicTitle: data.music_info?.title || data.title || 'TikTok Audio',
    musicAuthor: data.music_info?.author || data.author?.nickname || '',
  };
};

// ─────────────────────────────────────────
// GITHUB
// ─────────────────────────────────────────
const getGithubZip = async (url) => {
  const match = url.match(/github\.com\/([^/]+)\/([^/\s?#]+)(?:\/tree\/([^/\s?#]+))?/i);
  if (!match) throw new Error('URL GitHub tidak valid');
  const user = match[1];
  const repo = match[2].replace(/\.git$/, '');
  let branch = match[3] || null;
  if (!branch) {
    try {
      const api = await axios.get(`https://api.github.com/repos/${user}/${repo}`, { timeout: 10000 });
      branch = api.data.default_branch || 'main';
    } catch { branch = 'main'; }
  }
  return {
    url: `https://github.com/${user}/${repo}/archive/refs/heads/${branch}.zip`,
    filename: `${repo}-${branch}.zip`,
    user, repo, branch,
  };
};

// ─────────────────────────────────────────
// Handler /dl
// ─────────────────────────────────────────
const handleDl = async (ctx, isPremium) => {
  if (!isPremium(ctx.from.id)) {
    return ctx.reply(
      `<blockquote>⛔ <b>ᴀᴋsᴇs ᴅɪᴛᴏʟᴀᴋ</b>\n\nFitur /dl hanya untuk:\n💎 Premium | 🛠️ Admin | 👑 Owner</blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  const url = extractUrl(ctx);
  if (!url) {
    return ctx.reply(
      `<blockquote>📥 <b>/dl</b> — ᴅᴏᴡɴʟᴏᴀᴅᴇʀ\n\n<b>ᴄᴀʀᴀ ᴘᴀᴋᴀɪ:</b>\n<code>/dl [url]</code>\n\n<b>ᴅɪᴅᴜᴋᴜɴɢ:</b>\n🎵 TikTok — video / audio mp3\n🐙 GitHub — repo .zip</blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  console.log(`[/dl] user=${ctx.from.id} url=${url}`);

  const detected = detectPlatform(url);
  if (!detected) {
    return ctx.reply(
      `<blockquote>❌ <b>ᴜʀʟ ᴛɪᴅᴀᴋ ᴅɪᴋᴇɴᴀʟɪ</b>\n\nYang didukung: TikTok, GitHub\n\n<code>${url.slice(0, 150)}</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  const { platform, url: cleanUrl } = detected;

  const loading = await ctx.reply(
    `<blockquote>⏳ ${platform === 'tiktok' ? '🎵 TikTok' : '🐙 GitHub'}\n\nMengambil info...</blockquote>`,
    { parse_mode: 'HTML' }
  );
  const del = () => ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});

  try {
    if (platform === 'tiktok') {
      const info = await getTiktokInfo(cleanUrl);
      await del();

      const cacheId = saveUrl(JSON.stringify({
        videoUrl: info.videoUrl,
        musicUrl: info.musicUrl,
        title: info.title,
        author: info.author,
        musicTitle: info.musicTitle,
        musicAuthor: info.musicAuthor,
      }));

      await ctx.reply(
        `<blockquote>🎵 <b>TikTok</b>\n\n📝 ${info.title.slice(0, 150)}\n👤 ${info.author}\n\nPilih format:</blockquote>`,
        {
          parse_mode: 'HTML',
          reply_markup: {
            inline_keyboard: [[
              { text: '🎬 Video', callback_data: `tt_video_${cacheId}` },
              { text: '🎵 Audio', callback_data: `tt_audio_${cacheId}` },
            ]],
          },
        }
      );
    }

    else if (platform === 'github') {
      const info = await getGithubZip(cleanUrl);
      await del();
      await ctx.reply(
        `<blockquote>🐙 <b>GitHub</b>\n\n📦 <code>${info.user}/${info.repo}</code>\n🌿 <code>${info.branch}</code>\n\n⏳ Mengirim ZIP...</blockquote>`,
        { parse_mode: 'HTML' }
      );
      try {
        await sendDocSmart(ctx, info.url,
          `<blockquote>🐙 <b>${info.repo}</b> (${info.branch})</blockquote>`, info.filename);
      } catch {
        ctx.reply(`<blockquote>⚠️ Repo terlalu besar.\n<code>${info.url}</code></blockquote>`, { parse_mode: 'HTML' });
      }
    }

  } catch (err) {
    await del();
    console.error(`[download:${platform}]`, err.message);
    ctx.reply(
      `<blockquote>❌ <b>ɢᴀɢᴀʟ</b>\n\n${err.message?.slice(0, 150)}</blockquote>`,
      { parse_mode: 'HTML' }
    );
  }
};

// ─────────────────────────────────────────
// Handler TikTok format picker
// ─────────────────────────────────────────
const handleTtFormat = async (ctx, isPremium) => {
  if (!isPremium(ctx.from.id)) return ctx.answerCbQuery('⛔ Khusus Premium!', { show_alert: true });
  await ctx.answerCbQuery().catch(() => {});

  const data  = ctx.callbackQuery.data;
  const match = data.match(/^tt_(video|audio)_(\d+)$/);
  if (!match) return;

  const fmt    = match[1];
  const cached = urlCache.get(match[2]);
  if (!cached) return ctx.reply('<blockquote>❌ Sesi expired. Kirim ulang /dl link TikTok.</blockquote>', { parse_mode: 'HTML' });

  let info;
  try { info = JSON.parse(cached); } catch { return; }

  const fmtLabel = fmt === 'audio' ? '🎵 Audio' : '🎬 Video';
  await ctx.editMessageText(
    `<blockquote>⏳ <b>TikTok</b> — ${fmtLabel}\n\nSedang mengunduh...</blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});

  try {
    if (fmt === 'audio') {
      if (!info.musicUrl) throw new Error('Audio tidak tersedia untuk video ini.');
      const cap = `<blockquote>🎵 <b>TikTok Audio</b>\n\n📝 ${(info.musicTitle || info.title).slice(0, 150)}\n👤 ${info.musicAuthor || info.author}</blockquote>`;
      await sendAudioSmart(ctx, info.musicUrl, cap, `tiktok_audio_${Date.now()}.mp3`);
    } else {
      const cap = `<blockquote>🎵 <b>TikTok</b>\n\n📝 ${info.title.slice(0, 150)}\n👤 ${info.author}</blockquote>`;
      await sendVideoSmart(ctx, info.videoUrl, cap, `tiktok_${Date.now()}.mp4`);
    }
  } catch (err) {
    console.error('[tt format]', err.message);
    ctx.reply(`<blockquote>❌ <b>Gagal</b>\n\n${err.message?.slice(0, 150)}</blockquote>`, { parse_mode: 'HTML' });
  }
};

// ─────────────────────────────────────────
// Setup
// ─────────────────────────────────────────
module.exports = (bot, isPremium) => {
  bot.command('dl', (ctx) => handleDl(ctx, isPremium));
  bot.action(/^tt_(video|audio)_/, (ctx) => handleTtFormat(ctx, isPremium));
};
