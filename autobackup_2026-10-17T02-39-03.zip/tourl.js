// === tourl.js — Konversi foto/file ke URL (Catbox.moe) ===
// Dipanggil dari index.js: const setupToUrl = require('./tourl');
// Lalu: setupToUrl(bot, config);
//
// Cara pakai:
//   - Kirim foto lalu /tourl (reply)
//   - Atau kirim foto dengan caption /tourl

const axios = require('axios');
const FormData = require('form-data');

const CATBOX_URL = 'https://catbox.moe/user/api.php';

// Upload buffer ke catbox
const uploadToCatbox = async (fileBuffer, fileName) => {
  const form = new FormData();
  form.append('reqtype', 'fileupload');
  form.append('fileToUpload', fileBuffer, { filename: fileName });

  const response = await axios.post(CATBOX_URL, form, {
    headers: form.getHeaders(),
    timeout: 30000
  });

  // Catbox mengembalikan URL langsung sebagai plain text
  const url = response.data?.trim();
  if (!url || !url.startsWith('https://')) throw new Error('Upload gagal');
  return url;
};

module.exports = (bot, config) => {

  // Handler: foto dikirim dengan caption /tourl
  bot.on('photo', async (ctx, next) => {
    const caption = ctx.message.caption?.trim() || '';
    if (caption !== '/tourl' && !caption.startsWith('/tourl')) return next();

    await handleToUrl(ctx, 'photo');
  });

  // Handler: reply foto dengan /tourl
  bot.command('tourl', async (ctx) => {
    const replied = ctx.message.reply_to_message;

    if (!replied) {
      return ctx.reply(
        `<blockquote>🔗 <b>Foto ke URL</b>\n\n` +
        `Cara pakai:\n` +
        `• Kirim foto dengan caption <code>/tourl</code>\n` +
        `• Reply foto lalu ketik <code>/tourl</code></blockquote>`,
        { parse_mode: 'HTML' }
      );
    }

    if (replied.photo) {
      await handleToUrl(ctx, 'photo', replied);
    } else if (replied.document) {
      await handleToUrl(ctx, 'document', replied);
    } else {
      ctx.reply('❌ Hanya foto dan file yang bisa dikonversi ke URL.');
    }
  });

  // Fungsi utama upload
  const handleToUrl = async (ctx, type, sourceMsg = null) => {
    const msg = sourceMsg || ctx.message;
    const loadingMsg = await ctx.reply('⏳ <b>Mengupload ke Catbox...</b>', { parse_mode: 'HTML' });

    try {
      let fileId, fileName;

      if (type === 'photo') {
        const photos = msg.photo;
        fileId = photos[photos.length - 1].file_id; // ambil resolusi tertinggi
        fileName = `photo_${Date.now()}.jpg`;
      } else {
        fileId = msg.document.file_id;
        fileName = msg.document.file_name || `file_${Date.now()}`;
      }

      // Dapatkan URL file dari Telegram
      const fileLink = await ctx.telegram.getFileLink(fileId);
      const fileResp = await axios.get(fileLink.href, { responseType: 'arraybuffer', timeout: 30000 });
      const fileBuffer = Buffer.from(fileResp.data);

      // Upload ke Catbox
      const url = await uploadToCatbox(fileBuffer, fileName);

      await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});

      await ctx.reply(
        `<blockquote>✅ <b>Upload Berhasil!</b>\n\n` +
        `🔗 URL:\n<code>${url}</code>\n\n` +
        `📁 File: <b>${fileName}</b>\n` +
        `🌐 Host: <b>Catbox.moe</b></blockquote>`,
        { parse_mode: 'HTML' }
      );

    } catch (err) {
      await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
      console.error('ToUrl error:', err.message);

      if (err.message.includes('file is too big') || err.response?.status === 413) {
        return ctx.reply('❌ File terlalu besar. Maksimal 200MB di Catbox.');
      }
      ctx.reply('❌ Gagal upload. Coba lagi nanti.');
    }
  };

};
