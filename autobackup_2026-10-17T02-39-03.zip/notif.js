// notif.js — Notifikasi ke Channel
// Semua notif ke CHANNEL_ID dikelola di sini

const { loadWithExpiry, formatExpiry, isOwner: _isOwner } = (() => {
  // Helper ekspor dari index tidak bisa, jadi duplikat mini helper
  const fs = require('fs');
  const formatExpiry = (expiredAt) => {
    if (!expiredAt) return '♾️ Permanen';
    const diff = expiredAt - Date.now();
    if (diff <= 0) return '⛔ Expired';
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff % 86400000) / 3600000);
    if (d > 30)  return `${Math.floor(d/30)} bulan lagi`;
    if (d > 0)   return `${d} hari ${h} jam lagi`;
    return `${h} jam lagi`;
  };
  const loadWithExpiry = (file) => {
    try {
      if (!fs.existsSync(file)) return {};
      return JSON.parse(fs.readFileSync(file));
    } catch { return {}; }
  };
  return { loadWithExpiry, formatExpiry };
})();

const fs     = require('fs');
const ADMIN_FILE = './admins.json';

// Helper ambil sisa waktu pelaku
const getSisaWaktuPelaku = (pelakuId, ownerIdConf) => {
  if (String(pelakuId) === String(ownerIdConf)) return '♾️ Owner (permanen)';
  const adminData = loadWithExpiry(ADMIN_FILE);
  const entry     = adminData[pelakuId];
  if (!entry) return '♾️ Permanen';
  if (!entry.expiredAt) return '♾️ Permanen';
  return formatExpiry(entry.expiredAt);
};

const fmtPelaku = (from) =>
  `${from.first_name}${from.username ? ` (@${from.username})` : ''}`;

const now = () =>
  new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

// ─── Kirim notif ke channel + owner ─────────────────────────
const send = (bot, config, text) => {
  // Ke channel
  bot.telegram.sendMessage(config.CHANNEL_ID, text, { parse_mode: 'HTML' })
    .catch(e => console.error('[notif] ❌ channel:', e.message));
  // Ke owner
  bot.telegram.sendMessage(Number(config.OWNER_ID), text, { parse_mode: 'HTML' })
    .catch(e => console.error('[notif] ❌ owner:', e.message));
};

// ─── NOTIF ADDADMIN ──────────────────────────────────────────
const notifAddAdmin = (bot, config, ctx, targetId, expiryLabel, isNew) => {
  const pelaku = fmtPelaku(ctx.from);
  send(bot, config,
    `<blockquote>⚙️ <b>/addadmin telah digunakan</b>\n\n` +
    `👤 Pelaku  : <b>${pelaku}</b> (<code>${ctx.from.id}</code>)\n` +
    `🎯 Target  : <code>${targetId}</code>\n` +
    `🆕 Status  : <b>${isNew ? 'Baru ditambahkan' : 'Diperpanjang'}</b>\n` +
    `⏳ Berlaku : <b>${expiryLabel}</b>\n` +
    `📅 Waktu   : ${now()}</blockquote>`
  );
};

// ─── NOTIF DELADMIN ──────────────────────────────────────────
const notifDelAdmin = (bot, config, ctx, targetId) => {
  const pelaku = fmtPelaku(ctx.from);
  send(bot, config,
    `<blockquote>🗑️ <b>/deladmin telah digunakan</b>\n\n` +
    `👤 Pelaku  : <b>${pelaku}</b> (<code>${ctx.from.id}</code>)\n` +
    `🎯 Target  : <code>${targetId}</code>\n` +
    `❌ Status  : <b>Akses Admin dicabut</b>\n` +
    `📅 Waktu   : ${now()}</blockquote>`
  );
};

// ─── NOTIF ADDPREM ───────────────────────────────────────────
const notifAddPrem = (bot, config, ctx, targetId, expiryLabel, isNew) => {
  const pelaku   = fmtPelaku(ctx.from);
  const sisaPelaku = getSisaWaktuPelaku(ctx.from.id, config.OWNER_ID);
  send(bot, config,
    `<blockquote>📋 <b>/addprem telah digunakan</b>\n\n` +
    `👤 Pelaku  : <b>${pelaku}</b> (<code>${ctx.from.id}</code>)\n` +
    `🎯 Target  : <code>${targetId}</code>\n` +
    `🆕 Status  : <b>${isNew ? 'Baru ditambahkan' : 'Diperpanjang'}</b>\n` +
    `⏳ Waktu prem : <b>${expiryLabel}</b>\n` +
    `🕐 Batas waktu pelaku : <b>${sisaPelaku}</b>\n` +
    `📅 Waktu   : ${now()}</blockquote>`
  );
};

// ─── NOTIF DELPREM ───────────────────────────────────────────
const notifDelPrem = (bot, config, ctx, targetId) => {
  const pelaku   = fmtPelaku(ctx.from);
  const sisaPelaku = getSisaWaktuPelaku(ctx.from.id, config.OWNER_ID);
  send(bot, config,
    `<blockquote>🗑️ <b>/delprem telah digunakan</b>\n\n` +
    `👤 Pelaku  : <b>${pelaku}</b> (<code>${ctx.from.id}</code>)\n` +
    `🎯 Target  : <code>${targetId}</code>\n` +
    `❌ Status  : <b>Premium dicabut</b>\n` +
    `🕐 Batas waktu pelaku : <b>${sisaPelaku}</b>\n` +
    `📅 Waktu   : ${now()}</blockquote>`
  );
};

// ─── NOTIF PEMBAYARAN MASUK ──────────────────────────────────
const notifPayment = (bot, config, userId, typeLabel, label, amount, metode) => {
  send(bot, config,
    `<blockquote>💰 <b>PEMBAYARAN MASUK</b>\n\n` +
    `👤 User  : <code>${userId}</code>\n` +
    `📦 Paket : <b>${typeLabel} — ${label}</b>\n` +
    `💵 Harga : <b>Rp${amount.toLocaleString('id-ID')}</b>\n` +
    `⚙️ Metode: <b>${metode}</b>\n` +
    `📅 Waktu : ${now()}</blockquote>`
  );
};


module.exports = {
  notifAddAdmin,
  notifDelAdmin,
  notifAddPrem,
  notifDelPrem,
  notifPayment,
};
