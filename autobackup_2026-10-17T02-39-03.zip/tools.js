// === tools.js — Kumpulan Tools Ringan ===
// /sticker — foto → stiker webp (via ffmpeg)
// /qr      — buat QR code dari teks/link
// /short   — perpendek URL via TinyURL
// /info    — info meta dari sebuah link
// /cuaca   — cek cuaca kota (via wttr.in)
//
// Tidak ada package tambahan selain axios yang sudah ada

const fs   = require('fs');
const path = require('path');
const axios = require('axios');
const { execSync } = require('child_process');

const TEMP_DIR = './temp/';
const ensureTemp = () => { if (!fs.existsSync(TEMP_DIR)) fs.mkdirSync(TEMP_DIR, { recursive: true }); };
const cleanTemp  = (f) => { try { if (fs.existsSync(f)) fs.unlinkSync(f); } catch {} };

// ─────────────────────────────────────────
// /sticker — konversi foto → stiker .webp
// ─────────────────────────────────────────
const handleSticker = async (ctx, bot) => {
  const msg = ctx.message;
  const replied = msg.reply_to_message;

  // Ambil foto dari pesan atau reply
  let fileId = null;
  if (msg.photo)            fileId = msg.photo[msg.photo.length - 1].file_id;
  else if (replied?.photo)  fileId = replied.photo[replied.photo.length - 1].file_id;

  if (!fileId) {
    return ctx.reply(
      `<blockquote>🎨 <b>/sticker</b>\n\nKirim foto dengan caption <code>/sticker</code>\natau reply foto lalu ketik <code>/sticker</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  // Cek ffmpeg tersedia
  try { execSync('ffmpeg -version', { stdio: 'ignore' }); }
  catch {
    return ctx.reply('❌ <code>ffmpeg</code> tidak tersedia di server ini.', { parse_mode: 'HTML' });
  }

  const loading = await ctx.reply('🎨 <b>Mengonversi ke stiker...</b>', { parse_mode: 'HTML' });
  ensureTemp();

  const tmpIn  = path.join(TEMP_DIR, `sticker_in_${Date.now()}.jpg`);
  const tmpOut = path.join(TEMP_DIR, `sticker_out_${Date.now()}.webp`);

  try {
    const fileLink = await bot.telegram.getFileLink(fileId);
    const resp = await axios.get(fileLink.href, { responseType: 'arraybuffer', timeout: 15000 });
    fs.writeFileSync(tmpIn, Buffer.from(resp.data));

    // Convert ke webp 512x512 (ukuran stiker Telegram)
    execSync(`ffmpeg -y -i "${tmpIn}" -vf "scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:white@0" "${tmpOut}"`, { stdio: 'ignore' });

    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
    await ctx.replyWithSticker({ source: fs.createReadStream(tmpOut) });
  } finally {
    cleanTemp(tmpIn);
    cleanTemp(tmpOut);
  }
};

// ─────────────────────────────────────────
// /qr — buat QR code dari teks/link
// ─────────────────────────────────────────
const handleQr = async (ctx) => {
  const text = ctx.message.text.split(' ').slice(1).join(' ').trim();

  if (!text) {
    return ctx.reply(
      `<blockquote>📷 <b>/qr</b>\n\nCara pakai:\n<code>/qr [teks atau link]</code>\n\nContoh:\n<code>/qr https://google.com</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  if (text.length > 500) return ctx.reply('❌ Teks terlalu panjang. Maksimal 500 karakter.');

  const loading = await ctx.reply('📷 <b>Membuat QR code...</b>', { parse_mode: 'HTML' });

  try {
    const encoded = encodeURIComponent(text);
    const qrUrl   = `https://api.qrserver.com/v1/create-qr-code/?data=${encoded}&size=400x400&margin=10&color=000000&bgcolor=ffffff`;
    const resp    = await axios.get(qrUrl, { responseType: 'arraybuffer', timeout: 15000 });

    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
    await ctx.replyWithPhoto(
      { source: Buffer.from(resp.data), filename: 'qrcode.png' },
      {
        caption:
          `<blockquote>📷 <b>QR Code</b>\n\n` +
          `📝 Teks: <code>${text.length > 80 ? text.slice(0, 80) + '…' : text}</code></blockquote>`,
        parse_mode: 'HTML'
      }
    );
  } catch {
    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
    ctx.reply('❌ Gagal membuat QR code. Coba lagi nanti.');
  }
};

// ─────────────────────────────────────────
// /short — perpendek URL via TinyURL
// ─────────────────────────────────────────
const handleShort = async (ctx) => {
  const url = ctx.message.text.split(' ').slice(1).join(' ').trim();

  if (!url) {
    return ctx.reply(
      `<blockquote>🔗 <b>/short</b>\n\nCara pakai:\n<code>/short [URL panjang]</code>\n\nContoh:\n<code>/short https://google.com/very/long/url</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    return ctx.reply('❌ URL harus diawali dengan <code>http://</code> atau <code>https://</code>', { parse_mode: 'HTML' });
  }

  const loading = await ctx.reply('🔗 <b>Memperpendek URL...</b>', { parse_mode: 'HTML' });

  try {
    const resp = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(url)}`, { timeout: 10000 });
    const short = resp.data?.trim();

    if (!short || !short.startsWith('http')) throw new Error('Gagal');

    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
    await ctx.reply(
      `<blockquote>🔗 <b>URL Diperpendek</b>\n\n` +
      `📎 Pendek : <code>${short}</code>\n` +
      `📄 Asli   : <code>${url.length > 80 ? url.slice(0, 80) + '…' : url}</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  } catch {
    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
    ctx.reply('❌ Gagal memperpendek URL. Pastikan URL valid.');
  }
};

// ─────────────────────────────────────────
// /info — info meta dari sebuah link
// ─────────────────────────────────────────
const getMeta = (html, property) => {
  const patterns = [
    new RegExp(`<meta[^>]+property=["']${property}["'][^>]+content=["']([^"']+)["']`, 'i'),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+property=["']${property}["']`, 'i'),
    new RegExp(`<meta[^>]+name=["']${property}["'][^>]+content=["']([^"']+)["']`, 'i'),
    new RegExp(`<meta[^>]+content=["']([^"']+)["'][^>]+name=["']${property}["']`, 'i'),
  ];
  for (const p of patterns) {
    const m = html.match(p);
    if (m?.[1]) return m[1].trim().replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
  }
  return null;
};

const handleInfo = async (ctx) => {
  const url = ctx.message.text.split(' ').slice(1).join(' ').trim();

  if (!url) {
    return ctx.reply(
      `<blockquote>🌐 <b>/info</b>\n\nCara pakai:\n<code>/info [URL]</code>\n\nContoh:\n<code>/info https://google.com</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  if (!url.startsWith('http://') && !url.startsWith('https://')) {
    return ctx.reply('❌ URL harus diawali dengan <code>http://</code> atau <code>https://</code>', { parse_mode: 'HTML' });
  }

  const loading = await ctx.reply('🌐 <b>Mengambil info link...</b>', { parse_mode: 'HTML' });

  try {
    const resp = await axios.get(url, {
      timeout: 10000,
      maxContentLength: 500000, // max 500KB
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; TelegramBot/1.0)' }
    });

    const html = resp.data?.toString() || '';

    // Ambil meta tags
    const title  = getMeta(html, 'og:title')       || html.match(/<title[^>]*>([^<]+)<\/title>/i)?.[1]?.trim() || '-';
    const desc   = getMeta(html, 'og:description') || getMeta(html, 'description') || '-';
    const image  = getMeta(html, 'og:image')       || null;
    const site   = getMeta(html, 'og:site_name')   || new URL(url).hostname;
    const type   = getMeta(html, 'og:type')        || '-';

    const escT = (s) => s?.slice(0, 200).replace(/</g,'&lt;').replace(/>/g,'&gt;') || '-';

    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});

    const caption =
      `<blockquote>🌐 <b>Info Link</b>\n\n` +
      `📌 <b>Judul</b>  : ${escT(title)}\n` +
      `🏠 <b>Situs</b>  : ${escT(site)}\n` +
      `📝 <b>Deskripsi</b>:\n${escT(desc)}\n\n` +
      `🔗 <b>URL</b>: <code>${url.slice(0, 100)}</code></blockquote>`;

    if (image && image.startsWith('http')) {
      await ctx.replyWithPhoto(image, { caption, parse_mode: 'HTML' }).catch(() =>
        ctx.reply(caption, { parse_mode: 'HTML' })
      );
    } else {
      await ctx.reply(caption, { parse_mode: 'HTML' });
    }

  } catch (err) {
    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
    if (err.code === 'ECONNREFUSED' || err.code === 'ENOTFOUND') {
      return ctx.reply('❌ URL tidak dapat diakses.');
    }
    ctx.reply('❌ Gagal mengambil info link. Pastikan URL valid dan dapat diakses.');
  }
};

// ─────────────────────────────────────────
// /cuaca — cek cuaca kota (via wttr.in)
// ─────────────────────────────────────────
const weatherIcon = (code) => {
  if (code <= 113) return '☀️';
  if (code <= 116) return '⛅';
  if (code <= 119) return '☁️';
  if (code <= 143) return '🌫️';
  if (code <= 176) return '🌦️';
  if (code <= 260) return '🌧️';
  if (code <= 299) return '⛈️';
  if (code <= 377) return '🌨️';
  return '🌩️';
};

const handleCuaca = async (ctx) => {
  const kota = ctx.message.text.split(' ').slice(1).join(' ').trim();

  if (!kota) {
    return ctx.reply(
      `<blockquote>🌤️ <b>/cuaca</b>\n\nCara pakai:\n<code>/cuaca [nama kota]</code>\n\nContoh:\n<code>/cuaca Jakarta</code>\n<code>/cuaca Surabaya</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  const loading = await ctx.reply('🌤️ <b>Mengambil data cuaca...</b>', { parse_mode: 'HTML' });

  try {
    const resp = await axios.get(
      `https://wttr.in/${encodeURIComponent(kota)}?format=j1`,
      { timeout: 10000, headers: { 'Accept-Language': 'id' } }
    );

    const data    = resp.data;
    const current = data.current_condition?.[0];
    const nearest = data.nearest_area?.[0];

    if (!current) throw new Error('Data cuaca tidak tersedia');

    const cityName  = nearest?.areaName?.[0]?.value || kota;
    const country   = nearest?.country?.[0]?.value  || '';
    const temp      = current.temp_C;
    const feels     = current.FeelsLikeC;
    const humidity  = current.humidity;
    const wind      = current.windspeedKmph;
    const windDir   = current.winddir16Point;
    const desc      = current.weatherDesc?.[0]?.value || '-';
    const wCode     = parseInt(current.weatherCode);
    const icon      = weatherIcon(wCode);
    const vis       = current.visibility;
    const uv        = current.uvIndex;

    // Forecast hari ini
    const today     = data.weather?.[0];
    const maxTemp   = today?.maxtempC || '-';
    const minTemp   = today?.mintempC || '-';

    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
    await ctx.reply(
      `<blockquote>${icon} <b>Cuaca ${cityName}${country ? ', ' + country : ''}</b>\n\n` +
      `🌡️ <b>Suhu</b>       : ${temp}°C (terasa ${feels}°C)\n` +
      `📊 <b>Min/Max</b>    : ${minTemp}°C / ${maxTemp}°C\n` +
      `💧 <b>Kelembaban</b> : ${humidity}%\n` +
      `💨 <b>Angin</b>      : ${wind} km/h ${windDir}\n` +
      `👁️ <b>Jarak Pandang</b>: ${vis} km\n` +
      `☀️ <b>Indeks UV</b>  : ${uv}\n` +
      `📝 <b>Kondisi</b>    : ${desc}</blockquote>`,
      { parse_mode: 'HTML' }
    );

  } catch (err) {
    await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
    if (err.response?.status === 404 || err.message?.includes('Unknown')) {
      return ctx.reply(`❌ Kota <b>${kota}</b> tidak ditemukan. Coba nama kota lain.`, { parse_mode: 'HTML' });
    }
    ctx.reply('❌ Gagal mengambil data cuaca. Coba lagi nanti.');
  }
};

// ─────────────────────────────────────────
// /calc — kalkulator aritmatika cepat
// ─────────────────────────────────────────
const handleCalc = async (ctx) => {
  const expr = ctx.message.text.split(' ').slice(1).join(' ').trim();

  if (!expr) {
    return ctx.reply(
      `<blockquote>🧮 <b>/calc</b>\n\nCara pakai:\n<code>/calc [persamaan]</code>\n\nContoh:\n<code>/calc 12 * (3 + 5) / 2</code>\n<code>/calc 10^2 + 5</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  try {
    const cleaned = expr
      .replace(/×/g, '*')
      .replace(/÷/g, '/')
      .replace(/\^/g, '**')
      .replace(/\bpi\b/gi, 'PI')
      .replace(/\be\b/gi, 'E')
      .trim();

    if (!/^[0-9+\-*/%().,\sPIE]+$/.test(cleaned)) {
      throw new Error('Ekspresi tidak valid');
    }

    if (/\b(?:constructor|prototype|__proto__)\b/i.test(cleaned)) {
      throw new Error('Ekspresi tidak valid');
    }

    const fn = new Function(
      'Math',
      `const { PI, E, abs, round, floor, ceil, max, min, sqrt, pow } = Math; return (${cleaned});`
    );

    const result = fn(Math);
    if (!Number.isFinite(result)) {
      throw new Error('Hasil tidak valid');
    }

    const display = Number.isInteger(result) ? result.toString() : Number(result.toFixed(8)).toString();
    await ctx.reply(
      `<blockquote>🧮 <b>Hasil</b>\n\n<code>${expr}</code>\n= <b>${display}</b></blockquote>`,
      { parse_mode: 'HTML' }
    );
  } catch {
    await ctx.reply('❌ Ekspresi tidak valid. Gunakan angka dan operator matematika sederhana seperti <code>+, -, *, /, %, (), ^</code>.', { parse_mode: 'HTML' });
  }
};

// ─────────────────────────────────────────
// Setup semua tools
// ─────────────────────────────────────────
module.exports = (bot) => {

  // /sticker — kirim foto dengan caption atau reply foto
  bot.command('sticker', (ctx) => handleSticker(ctx, bot));
  bot.on('photo', async (ctx, next) => {
    const caption = ctx.message.caption?.trim() || '';
    if (caption === '/sticker' || caption.startsWith('/sticker@')) {
      return handleSticker(ctx, bot);
    }
    return next();
  });

  bot.command('qr',     handleQr);
  bot.command('short',  handleShort);
  bot.command('info',   handleInfo);
  bot.command('cuaca',  handleCuaca);
  bot.command('calc',   handleCalc);

};
