module.exports = {
  BOT_TOKEN: "8968413789:AAHwM_wujJovpI6BvVvAxNB4BqhgHERYmNM",
  OWNER_ID: 5602036403,
  OWNER_USERNAME: "@axcelforlife",
  BOT_NAME: "BOT JASHER FREE",
  GROQ_API_KEY: 'YOUR_GROQ_APIKEY',
  NOTIFY_ID: -1003885306422, 

  DELAY_ANTAR_GRUP: {
    OWNER: 2000,
    ADMIN: 3000,
    PREMIUM: 4500,
    GROUP_PREMIUM: 5000,
    FREE: 10000
  },

  AUTO_SHARE_INTERVAL: {
    OWNER: 60000,    // 1 menit
    ADMIN: 120000,   // 2 menit
    PREMIUM: 300000, // 5 menit
    GROUP_PREMIUM: 300000, // 5 menit
    FREE: 0
  },

  MAX_SHARE_FREE: 2,
  DELAY_FREE: 60,      // dalam menit
  MAX_RETRY: 3,

  REQUIRED_JOINS: [
    { text: "GB PUBLIC", url: "https://t.me/roompublicaxcell", id: "@roompublicaxcell" },
    { text: "INFPRMATION", url: "https://t.me/informationbotaxcell", id: "@informationbotaxcell" },
    { text: "CH UTAMA", url: "https://t.me/limakoshongenam", id: "@limakoshongenam" }
  ],
  CHANNEL_ID: -1003885306422,   //
  OWNER_NAME: "@axcelforlife",

  CONTACT_URL: "https://t.me/axcelforlife",
  THUMBNAIL: "https://files.catbox.moe/or6p4i.jpg",
  QRIS_MANUAL: "https://files.catbox.moe/a4h2hq.jpg",
  PAYMENT_INFO: "\n• Dana: 089657450909\n• GoPay: 083157450973",

  PRICE_PREMIUM: 10000,
  PRICE_ADMIN: 50000,
  PAKASIR_API_KEY: 'mfUgVtyiGHUHUypyWHu9cZtGWrO29zH4',
  PAKASIR_PROJECT: 'telegrambotz',
}