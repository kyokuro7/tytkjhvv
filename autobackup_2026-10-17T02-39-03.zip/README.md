# regege

Bot Telegram multifungsi dengan fitur utama seperti share premium, AI edit teks, tool QR, URL shortener, info link, cuaca, dan kalkulator cepat.

Fitur baru:
- /calc — hitung ekspresi matematika sederhana seperti `12 * (3 + 5) / 2` atau `10^2 + 5`

Cara penggunaan:
- `/calc 25 * 4`
- `/calc (120 / 8) + 3`
