const { Telegraf, Markup } = require('telegraf');
const fs = require('fs');
const axios = require('axios');
const config = require("./config");
const setupAi = require('./ai');
const setupToUrl = require('./tourl');
const setupCekId = require('./cekid');
const setupTools = require('./tools');
const setupDownload = require('./download');
const notifCh       = require('./notif');
const { version: BOT_VERSION } = require('./package.json');

const bot = new Telegraf(config.BOT_TOKEN);

// === Path File JSON ===
const BACKUP_INTERVAL_FILE = './backup_interval.json'; // simpan setting interval
const USERS_FILE = './users.json';
const GROUPS_FILE = './group_ids.json';
const PREMIUM_FILE = './premium.json';
const ADMIN_FILE = './admins.json';
const DELAY_FILE = './share_delay.json';
const TOKENS_FILE = './user_tokens.json';
const GROUP_PREMIUM_FILE = './group_premium.json'; // Premium gratis dari milestone grup
const KICK_TRACK_FILE   = './kick_track.json';     // Lacak jumlah grup yg user keluarkan bot
const BACKUP_DIR = './backups/';
const STATS_FILE = './stats.json';
const SCHEDULER_FILE = './scheduler.json';
const WELCOME_FILE = './welcome.json';
const AUTOTAG_FILE = './autotag.json';
const SCRIPTS_FILE   = './scripts.json';
const BLACKLIST_FILE = './blacklist_groups.json';

// Load/save blacklist
const loadBlacklist = () => {
  try {
    if (!fs.existsSync(BLACKLIST_FILE)) return {};
    return JSON.parse(fs.readFileSync(BLACKLIST_FILE));
  } catch { return {}; }
};
const saveBlacklist = (data) => {
  try { fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(data, null, 2)); } catch {}
};

// Catat kegagalan grup — auto blacklist kalau >= 3x gagal
const recordGroupFail = (gid, reason) => {
  const bl = loadBlacklist();
  if (bl[gid]?.permanent) return; // sudah di-blacklist manual
  if (!bl[gid]) bl[gid] = { fails: 0, reasons: [], autoAt: null };
  bl[gid].fails++;
  bl[gid].reasons = [...(bl[gid].reasons || []).slice(-4), reason?.substring(0, 80)];
  if (bl[gid].fails >= 3) {
    bl[gid].autoAt = new Date().toISOString();
    console.log(`[blacklist] Auto-blacklist grup ${gid} (${bl[gid].fails}x gagal)`);
  }
  saveBlacklist(bl);
};

const isBlacklisted = (gid) => {
  const bl = loadBlacklist();
  if (!bl[gid]) return false;
  return bl[gid].fails >= 3 || bl[gid].permanent;
};

// === PRICE LIST ===
const PRICE_LIST = {
  PREM: {
    '1w':  { label: '1 Minggu',  price: 1000,  expiry: '7d'  },
    '1m':  { label: '1 Bulan',   price: 2000,  expiry: '1m'  },
    '3m':  { label: '3 Bulan',   price: 3500,  expiry: '3m'  },
    '1y':  { label: '1 Tahun',   price: 6500,  expiry: '12m' },
  },
  ADM: {
    '1w':  { label: '1 Minggu',  price: 2500,  expiry: '7d'  },
    '1m':  { label: '1 Bulan',   price: 5000,  expiry: '1m'  },
    '3m':  { label: '3 Bulan',   price: 7500,  expiry: '3m'  },
    '1y':  { label: '1 Tahun',   price: 10000, expiry: '12m' },
  }
};

// === PAKASIR PAYMENT ===
// Simpan data transaksi pending: orderId → { userId, type, dur, amount, label }
const pendingTransactions = new Map();

// Mode QRIS: 'auto' = otomatis (Pakasir), 'manual' = manual (owner konfirmasi)
let qrisMode = 'auto';

// Buat transaksi QRIS ke Pakasir
async function createPakasirInvoice(orderId, amount) {
  const res = await axios.post(
    'https://app.pakasir.com/api/transactioncreate/qris',
    {
      project:  config.PAKASIR_PROJECT,
      order_id: orderId,
      amount:   amount,
      api_key:  config.PAKASIR_API_KEY
    },
    { headers: { 'Content-Type': 'application/json' }, timeout: 15000 }
  );
  return res.data; // berisi qr_string / data QR
}

// Cek status transaksi dari Pakasir
async function checkPakasirStatus(orderId, amount) {
  const res = await axios.get(
    `https://app.pakasir.com/api/transactiondetail`,
    {
      params: {
        project:  config.PAKASIR_PROJECT,
        order_id: orderId,
        amount:   amount,
        api_key:  config.PAKASIR_API_KEY
      },
      timeout: 10000
    }
  );
  return res.data?.payment || res.data?.transaction || res.data;
}

// Generate URL gambar QR dari QR string (pakai API online, tanpa install library)
function generateQRUrl(qrString) {
  const encoded = encodeURIComponent(qrString);
  return `https://api.qrserver.com/v1/create-qr-code/?size=400x400&margin=10&data=${encoded}`;
}

// Generate unique order ID
function generateOrderId(userId) {
  return `INV${Date.now()}-${userId}`;
}

// === HELPER: Convert Telegram message entities ke HTML ===
const entitiesToHtml = (text, entities) => {
  if (!entities || entities.length === 0) return text;

  // Konversi ke array karakter unicode (handle emoji multi-byte)
  const chars = [...text];
  let result = '';
  let i = 0;

  // Sort entities by offset
  const sorted = [...entities].sort((a, b) => a.offset - b.offset);

  // Build open/close tags per char index
  const opens = {};
  const closes = {};
  for (const e of sorted) {
    const start = e.offset;
    const end = e.offset + e.length;
    let open = '', close = '';
    if (e.type === 'bold')          { open = '<b>';  close = '</b>'; }
    else if (e.type === 'italic')   { open = '<i>';  close = '</i>'; }
    else if (e.type === 'underline'){ open = '<u>';  close = '</u>'; }
    else if (e.type === 'strikethrough') { open = '<s>'; close = '</s>'; }
    else if (e.type === 'code')     { open = '<code>'; close = '</code>'; }
    else if (e.type === 'pre')      { open = '<pre>'; close = '</pre>'; }
    else if (e.type === 'spoiler')  { open = '<tg-spoiler>'; close = '</tg-spoiler>'; }
    else if (e.type === 'blockquote') { open = '<blockquote>'; close = '</blockquote>'; }
    else if (e.type === 'text_link') { open = `<a href="${e.url}">`; close = '</a>'; }
    else if (e.type === 'text_mention') { open = `<a href="tg://user?id=${e.user.id}">`; close = '</a>'; }
    else continue;

    opens[start] = (opens[start] || '') + open;
    closes[end] = close + (closes[end] || '');
  }

  // Escape HTML special chars lalu sisipkan tag
  const escapeChar = (c) => c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : c;

  for (let idx = 0; idx <= chars.length; idx++) {
    if (closes[idx]) result += closes[idx];
    if (opens[idx])  result += opens[idx];
    if (idx < chars.length) result += escapeChar(chars[idx]);
  }

  return result;
};

// === Status Maintenance ===
let maintenanceMode = false;
const MAINTENANCE_FILE = './maintenance.json';

// Load status maintenance dari file
const loadMaintenanceStatus = () => {
  try {
    if (fs.existsSync(MAINTENANCE_FILE)) {
      const data = JSON.parse(fs.readFileSync(MAINTENANCE_FILE));
      maintenanceMode = data.status || false;
      console.log(`🛠️ Maintenance mode: ${maintenanceMode ? 'ON' : 'OFF'}`);
    }
  } catch (error) {
    console.error('Error load maintenance status:', error);
  }
};

// Save status maintenance ke file
const saveMaintenanceStatus = (status) => {
  try {
    maintenanceMode = status;
    fs.writeFileSync(MAINTENANCE_FILE, JSON.stringify({ status, updatedAt: new Date().toISOString() }, null, 2));
    console.log(`🛠️ Maintenance mode saved: ${status ? 'ON' : 'OFF'}`);
  } catch (error) {
    console.error('Error save maintenance status:', error);
  }
};

// Panggil saat bot start
loadMaintenanceStatus();

// === STATS FUNCTIONS ===
const loadStats = () => {
  try {
    if (!fs.existsSync(STATS_FILE)) {
      const init = { totalShare: 0, totalShareSuccess: 0, totalShareFailed: 0, dailyStats: {}, userStats: {} };
      fs.writeFileSync(STATS_FILE, JSON.stringify(init, null, 2));
      return init;
    }
    return JSON.parse(fs.readFileSync(STATS_FILE));
  } catch { return { totalShare: 0, totalShareSuccess: 0, totalShareFailed: 0, dailyStats: {}, userStats: {} }; }
};

const saveStats = (data) => {
  try { fs.writeFileSync(STATS_FILE, JSON.stringify(data, null, 2)); } catch (e) { console.error('Error save stats:', e); }
};

const recordShareStats = (userId, success, failed) => {
  const stats = loadStats();
  const today = new Date().toISOString().slice(0, 10);

  stats.totalShare = (stats.totalShare || 0) + 1;
  stats.totalShareSuccess = (stats.totalShareSuccess || 0) + success;
  stats.totalShareFailed = (stats.totalShareFailed || 0) + failed;

  if (!stats.dailyStats[today]) stats.dailyStats[today] = { share: 0, success: 0, failed: 0, users: [] };
  stats.dailyStats[today].share++;
  stats.dailyStats[today].success += success;
  stats.dailyStats[today].failed += failed;
  if (!stats.dailyStats[today].users.includes(userId)) stats.dailyStats[today].users.push(userId);

  if (!stats.userStats[userId]) stats.userStats[userId] = { share: 0, success: 0, failed: 0, lastShare: null, daily: {} };
  stats.userStats[userId].share++;
  stats.userStats[userId].success += success;
  stats.userStats[userId].failed += failed;
  stats.userStats[userId].lastShare = new Date().toISOString();
  // Simpan per-hari untuk analytics
  if (!stats.userStats[userId].daily) stats.userStats[userId].daily = {};
  if (!stats.userStats[userId].daily[today]) stats.userStats[userId].daily[today] = { success: 0, failed: 0 };
  stats.userStats[userId].daily[today].success += success;
  stats.userStats[userId].daily[today].failed  += failed;

  // Bersihkan data lebih dari 30 hari
  const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - 30);
  for (const d of Object.keys(stats.dailyStats)) {
    if (new Date(d) < cutoff) delete stats.dailyStats[d];
  }

  saveStats(stats);
};

// === SCHEDULER FUNCTIONS ===
const loadScheduler = () => {
  try {
    if (!fs.existsSync(SCHEDULER_FILE)) {
      fs.writeFileSync(SCHEDULER_FILE, JSON.stringify({}, null, 2));
      return {};
    }
    return JSON.parse(fs.readFileSync(SCHEDULER_FILE));
  } catch { return {}; }
};

const saveScheduler = (data) => {
  try { fs.writeFileSync(SCHEDULER_FILE, JSON.stringify(data, null, 2)); } catch (e) { console.error('Error save scheduler:', e); }
};

const schedulerTimers = new Map(); // userId -> array of timer IDs

const parseTimeHHMM = (timeStr) => {
  const match = timeStr.match(/^(\d{1,2}):(\d{2})$/);
  if (!match) return null;
  const h = parseInt(match[1]), m = parseInt(match[2]);
  if (h < 0 || h > 23 || m < 0 || m > 59) return null;
  return { h, m };
};

const msUntilNextTime = (h, m) => {
  // Gunakan WIB (UTC+7)
  const nowUTC = Date.now();
  const nowWIB = new Date(nowUTC + 7 * 60 * 60 * 1000);

  const targetWIB = new Date(nowWIB);
  targetWIB.setUTCHours(h, m, 0, 0);

  // Kalau sudah lewat hari ini (WIB), jadwalkan besok
  if (targetWIB <= nowWIB) {
    targetWIB.setUTCDate(targetWIB.getUTCDate() + 1);
  }

  const diff = targetWIB.getTime() - nowWIB.getTime();
  console.log(`⏰ Jadwal jam ${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')} WIB dalam ${Math.round(diff/1000/60)} menit`);
  return diff;
};

const startUserScheduler = (userId) => {
  const schedulers = loadScheduler();
  const userSched = schedulers[userId];
  if (!userSched || !userSched.active || !userSched.times || userSched.times.length === 0) return;

  stopUserScheduler(userId);

  const timers = [];
  for (const timeStr of userSched.times) {
    const t = parseTimeHHMM(timeStr);
    if (!t) continue;

    const scheduleNext = () => {
      const delay = msUntilNextTime(t.h, t.m);
      console.log(`📅 Scheduler user ${userId} jam ${timeStr} dalam ${Math.round(delay/1000/60)} menit`);

      const timer = setTimeout(async () => {
        const freshSched = loadScheduler();
        if (!freshSched[userId]?.active) return;

        // Cek pesan yang disimpan di scheduler
        const msgId = freshSched[userId]?.savedMsgId;
        const chatId = userId;

        if (!msgId) {
          try {
            await bot.telegram.sendMessage(userId,
              `⚠️ <b>Jadwal ${timeStr} gagal!</b>\n\nBelum ada pesan yang di-set.\nGunakan /setpesan dulu lalu aktifkan ulang jadwal.`,
              { parse_mode: 'HTML' }
            );
          } catch {}
          scheduleNext();
          return;
        }

        const groups = loadData(GROUPS_FILE);
        const groupIds = Object.keys(groups);
        const role = getRole(userId);
        const shareDelay = getDelayByRole(userId);
        const totalDb = groupIds.length;

        if (totalDb === 0) {
          try { await bot.telegram.sendMessage(userId, `⚠️ Jadwal ${timeStr}: Tidak ada grup terdaftar.`, { parse_mode: 'HTML' }); } catch {}
          scheduleNext();
          return;
        }

        // Kirim notif mulai
        let progressMsgId = null;
        try {
          const sentMsg = await bot.telegram.sendMessage(userId,
            `<blockquote>⏰ <b>JADWAL ${timeStr} DIMULAI</b>\n\n` +
            `👤 Role    : <b>${role}</b>\n` +
            `📦 Grup    : <b>${totalDb}</b> target\n` +
            `⏱️ Delay   : <b>${shareDelay/1000} detik</b>/grup\n` +
            `🕐 Estimasi: <b>~${Math.ceil(totalDb * shareDelay / 1000 / 60)} menit</b>\n\n` +
            `⏳ Memulai pengiriman...</blockquote>`,
            { parse_mode: 'HTML' }
          );
          progressMsgId = sentMsg.message_id;
        } catch {}

        // Jalankan broadcast scheduler secara non-blocking
        // agar event loop tidak tertahan dan bot tetap bisa respon user lain
        (async () => {
          let success = 0, failed = 0;
          const startTime = Date.now();

          for (const gid of groupIds) {
            // Skip hanya blacklist manual (permanent), bukan auto-blacklist 3x fail
            if (loadBlacklist()[gid]?.permanent) continue;
            try {
              await bot.telegram.copyMessage(gid, userId, msgId);
              success++;
            } catch (e) {
              failed++;
              recordGroupFail(gid, e.message);
              console.log(`❌ Scheduler ${userId} gagal ke ${gid}: ${e.message}`);
            }

            // Update progress setiap 5 grup
            if (progressMsgId && ((success + failed) % 5 === 0 || (success + failed) === totalDb)) {
              const pct = Math.floor(((success + failed) / totalDb) * 100);
              const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
              try {
                await bot.telegram.editMessageText(userId, progressMsgId, null,
                  `<blockquote>⏰ <b>JADWAL ${timeStr} BERJALAN</b>\n\n` +
                  `📊 Progress: [${bar}] ${pct}%\n` +
                  `✅ Berhasil: <b>${success}</b>  ❌ Gagal: <b>${failed}</b>\n` +
                  `📦 Terkirim: <b>${success + failed}/${totalDb}</b></blockquote>`,
                  { parse_mode: 'HTML' }
                );
              } catch {}
            }

            // Yield ke event loop setiap iterasi agar bot tetap responsif
            await new Promise(r => setTimeout(r, shareDelay));
          }

          const totalTime = Math.floor((Date.now() - startTime) / 1000);
          recordShareStats(userId, success, failed);

          // Kirim hasil akhir
          try {
            if (progressMsgId) {
              await bot.telegram.editMessageText(userId, progressMsgId, null,
                `<blockquote>⏰ <b>JADWAL ${timeStr} SELESAI ✅</b>\n\n` +
                `📊 Progress: [██████████] 100%\n` +
                `✅ Berhasil: <b>${success}</b>  ❌ Gagal: <b>${failed}</b>\n` +
                `📦 Total   : <b>${totalDb} grup</b>\n` +
                `⏱️ Durasi  : <b>${Math.floor(totalTime/60)}m ${totalTime%60}s</b></blockquote>`,
                { parse_mode: 'HTML' }
              );
            }
          } catch {}

          scheduleNext();
        })();
      }, delay);

      timers.push(timer);
    };
    scheduleNext();
  }
  schedulerTimers.set(userId, timers);
};

const stopUserScheduler = (userId) => {
  const timers = schedulerTimers.get(userId) || [];
  timers.forEach(t => clearTimeout(t));
  schedulerTimers.delete(userId);
};

// Restore scheduler saat bot start
const restoreAllSchedulers = () => {
  const schedulers = loadScheduler();
  console.log(`📅 Restoring ${Object.keys(schedulers).length} schedulers...`);
  for (const userId of Object.keys(schedulers)) {
    if (schedulers[userId]?.active) {
      startUserScheduler(parseInt(userId));
    }
  }
};

// === WELCOME FUNCTIONS ===
const loadWelcome = () => {
  try {
    if (!fs.existsSync(WELCOME_FILE)) {
      const init = { active: false, text: null, photo: null, buttonText: null, buttonUrl: null };
      fs.writeFileSync(WELCOME_FILE, JSON.stringify(init, null, 2));
      return init;
    }
    return JSON.parse(fs.readFileSync(WELCOME_FILE));
  } catch { return { active: false, text: null, photo: null, buttonText: null, buttonUrl: null }; }
};

const saveWelcome = (data) => {
  try { fs.writeFileSync(WELCOME_FILE, JSON.stringify(data, null, 2)); } catch (e) { console.error('Error save welcome:', e); }
};

// State sementara untuk setup welcome
const welcomeSetupState = new Map(); // userId -> step

// === AUTOTAG FUNCTIONS ===
const loadAutotag = () => {
  try {
    if (!fs.existsSync(AUTOTAG_FILE)) {
      const init = { active: false, text: null, mode: 'sender' }; // mode: sender | all | both
      fs.writeFileSync(AUTOTAG_FILE, JSON.stringify(init, null, 2));
      return init;
    }
    return JSON.parse(fs.readFileSync(AUTOTAG_FILE));
  } catch { return { active: false, text: null, mode: 'sender' }; }
};

const saveAutotag = (data) => {
  try { fs.writeFileSync(AUTOTAG_FILE, JSON.stringify(data, null, 2)); } catch (e) { console.error('Error save autotag:', e); }
};

// === SCRIPTS STORE ===
// Format: { id: { name, price, fileId, description, addedAt } }
const loadScripts = () => {
  try {
    if (!fs.existsSync(SCRIPTS_FILE)) return {};
    return JSON.parse(fs.readFileSync(SCRIPTS_FILE));
  } catch { return {}; }
};
const saveScripts = (data) => {
  try { fs.writeFileSync(SCRIPTS_FILE, JSON.stringify(data, null, 2)); } catch (e) { console.error('Error save scripts:', e); }
};
const pendingScriptPayments = new Map(); // orderId -> { userId, scriptId, amount }

// Buat string hidetag invisible dari list userIds
const buildHideTag = (userIds) => {
  // Karakter invisible unicode zero-width
  return userIds.map(id => `<a href="tg://user?id=${id}">&#8203;</a>`).join('');
};

const autotagSetupState = new Map(); // userId -> step

const waitingForProof = new Map();
const autoShareStatus = new Map();
const autoShareTime = new Map();
const userMessages = new Map();
const autoShareMessageId = new Map();
const lastMenuMsgId = new Map();
const lastShareMsgId = new Map(); // Simpan message ID progress share terakhir per user
const BOT_START_TIME = Date.now(); // Untuk uptime
const cooldownMap  = new Map(); // userId -> last command timestamp
const floodMap     = new Map(); // userId -> { count, firstAt, blockedUntil }

const COOLDOWN_MS  = 3000;  // cooldown normal antar command
const FLOOD_LIMIT  = 5;     // max command dalam 10 detik
const FLOOD_WINDOW = 10000; // window deteksi flood (ms)
const FLOOD_BAN_MS = 30000; // durasi cooldown kalau flood (ms)

const checkCooldown = (userId) => {
  const now = Date.now();

  // Cek apakah sedang dalam flood ban
  const flood = floodMap.get(userId);
  if (flood?.blockedUntil && now < flood.blockedUntil) {
    return Math.ceil((flood.blockedUntil - now) / 1000);
  }

  // Hitung command dalam window
  if (flood && now - flood.firstAt < FLOOD_WINDOW) {
    flood.count++;
    if (flood.count >= FLOOD_LIMIT) {
      flood.blockedUntil = now + FLOOD_BAN_MS;
      floodMap.set(userId, flood);
      console.log(`[flood] user ${userId} kena flood ban ${FLOOD_BAN_MS/1000}s`);
      return Math.ceil(FLOOD_BAN_MS / 1000);
    }
  } else {
    // Reset window
    floodMap.set(userId, { count: 1, firstAt: now, blockedUntil: null });
  }

  // Cooldown normal
  const last = cooldownMap.get(userId) || 0;
  if (now - last < COOLDOWN_MS) {
    return Math.ceil((COOLDOWN_MS - (now - last)) / 1000);
  }
  cooldownMap.set(userId, now);
  return 0;
};

// === Helper Load & Save JSON ===
const loadData = (file) => {
  try {
    if (!fs.existsSync(file)) {
      const initialData = file.includes('group_ids') || file.includes('delay') || file.includes('tokens') ? {} : [];
      fs.writeFileSync(file, JSON.stringify(initialData, null, 2));
      return initialData;
    }
    return JSON.parse(fs.readFileSync(file));
  } catch (error) {
    console.error(`Error loading ${file}:`, error);
    return file.includes('group_ids') || file.includes('delay') || file.includes('tokens') ? {} : [];
  }
};

// === FUNGSI BACKUP DATA ===
const backupData = (file, data) => {
  try {
    if (!fs.existsSync(BACKUP_DIR)) {
      fs.mkdirSync(BACKUP_DIR, { recursive: true });
    }
    
    const fileName = file.split('/').pop();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const backupPath = `${BACKUP_DIR}${fileName}.${timestamp}.json`;
    
    fs.writeFileSync(backupPath, JSON.stringify(data, null, 2));
    console.log(`✅ Backup created: ${backupPath}`);
    
    cleanupOldBackups(fileName, 10);
    return true;
  } catch (error) {
    console.error(`❌ Gagal backup ${file}:`, error.message);
    return false;
  }
};

const cleanupOldBackups = (fileName, keepCount = 10) => {
  try {
    if (!fs.existsSync(BACKUP_DIR)) return;
    
    const files = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith(fileName))
      .map(f => ({
        name: f,
        time: fs.statSync(`${BACKUP_DIR}${f}`).mtime.getTime()
      }))
      .sort((a, b) => b.time - a.time);
    
    if (files.length > keepCount) {
      const toDelete = files.slice(keepCount);
      toDelete.forEach(f => {
        fs.unlinkSync(`${BACKUP_DIR}${f.name}`);
        console.log(`🗑️ Hapus backup lama: ${f.name}`);
      });
    }
  } catch (error) {
    console.error('Error cleanup backups:', error.message);
  }
};

const sendBackupToTelegram = async (ctx, filePath, fileName) => {
  try {
    if (!fs.existsSync(filePath)) {
      return { success: false, message: 'File tidak ditemukan' };
    }
    
    await ctx.replyWithDocument(
      { source: filePath, filename: fileName },
      { caption: `📦 <b>File Backup: ${fileName}</b>\n🕐 ${new Date().toLocaleString('id-ID')}`, parse_mode: 'HTML' }
    );
    
    return { success: true };
  } catch (error) {
    console.error('Error sending backup:', error);
    return { success: false, message: error.message };
  }
};

const restoreFromBackup = (fileName, backupFileName) => {
  try {
    const backupPath = `${BACKUP_DIR}${backupFileName}`;
    if (!fs.existsSync(backupPath)) {
      return { success: false, message: 'File backup tidak ditemukan' };
    }
    
    const data = JSON.parse(fs.readFileSync(backupPath));
    const targetFile = `./${fileName}`;
    saveData(targetFile, data);
    
    return { success: true, message: `Berhasil restore ${fileName} dari ${backupFileName}` };
  } catch (error) {
    return { success: false, message: error.message };
  }
};

// === AUTO BACKUP ===
const loadBackupInterval = () => {
  try {
    if (!fs.existsSync(BACKUP_INTERVAL_FILE)) return 24; // default 24 jam
    return JSON.parse(fs.readFileSync(BACKUP_INTERVAL_FILE)).hours || 24;
  } catch { return 24; }
};

const saveBackupInterval = (hours) => {
  try { fs.writeFileSync(BACKUP_INTERVAL_FILE, JSON.stringify({ hours, updatedAt: new Date().toISOString() }, null, 2)); } catch {}
};

let autoBackupTimer = null;

const runAutoBackup = async () => {
  try {
    if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const zipName   = `autobackup_${timestamp}.zip`;
    const zipPath   = `${BACKUP_DIR}${zipName}`;

    const EXCLUDE  = ['node_modules', 'backups', '.git'];
    const allFiles = fs.readdirSync('./').filter(f => {
      if (EXCLUDE.includes(f)) return false;
      try { return fs.statSync(f).isFile(); } catch { return false; }
    }).map(f => `./${f}`);

    if (allFiles.length === 0) return;

    const { execSync } = require('child_process');
    try {
      execSync(`zip -j "${zipPath}" ${allFiles.join(' ')}`);
    } catch {
      execSync(`tar -czf "${zipPath.replace('.zip','.tar.gz')}" ${allFiles.join(' ')}`);
    }

    const finalPath = fs.existsSync(zipPath) ? zipPath : zipPath.replace('.zip', '.tar.gz');
    const zipSize   = (fs.statSync(finalPath).size / 1024).toFixed(2);
    const hours     = loadBackupInterval();

    // Kirim ke owner
    await bot.telegram.sendDocument(
      config.OWNER_ID,
      { source: finalPath, filename: finalPath.split('/').pop() },
      {
        caption:
          `<blockquote>🔄 <b>AUTO BACKUP</b>\n\n` +
          `📦 File : <code>${finalPath.split('/').pop()}</code>\n` +
          `📁 Isi  : ${allFiles.length} file\n` +
          `💾 Size : ${zipSize} KB\n` +
          `⏱️ Interval: setiap ${hours} jam\n` +
          `🕐 ${new Date().toLocaleString('id-ID')}</blockquote>`,
        parse_mode: 'HTML'
      }
    ).catch(() => {});

    // Bersihkan autobackup lama (simpan 5)
    const oldZips = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('autobackup_'))
      .map(f => ({ name: f, time: fs.statSync(`${BACKUP_DIR}${f}`).mtime.getTime() }))
      .sort((a, b) => b.time - a.time);
    oldZips.slice(5).forEach(f => { try { fs.unlinkSync(`${BACKUP_DIR}${f.name}`); } catch {} });

    console.log(`[autobackup] ✅ Backup berhasil: ${finalPath.split('/').pop()}`);
  } catch (e) {
    console.error('[autobackup] ❌', e.message);
  }
};

const startAutoBackup = () => {
  if (autoBackupTimer) clearInterval(autoBackupTimer);
  const hours = loadBackupInterval();
  if (hours <= 0) {
    console.log('[autobackup] Dinonaktifkan (interval = 0)');
    return;
  }
  console.log(`[autobackup] ✅ Aktif — setiap ${hours} jam`);
  autoBackupTimer = setInterval(runAutoBackup, hours * 60 * 60 * 1000);
};

// === NOTIF OTOMATIS EXPIRED H-3 ===
const checkExpiryNotif = async () => {
  const now        = Date.now();
  const H3         = 3 * 24 * 60 * 60 * 1000; // 3 hari dalam ms
  const adminData  = loadWithExpiry(ADMIN_FILE);
  const premData   = loadWithExpiry(PREMIUM_FILE);

  const notify = async (userId, type, expiredAt) => {
    const sisa = Math.ceil((expiredAt - now) / 86400000);
    if (sisa > 3 || sisa < 0) return; // skip kalau lebih 3 hari atau sudah expired
    try {
      await bot.telegram.sendMessage(userId,
        `<blockquote>⚠️ <b>AKSES HAMPIR HABIS</b>\n\n` +
        `Akses <b>${type}</b> kamu akan expired dalam <b>${sisa} hari</b>.\n\n` +
        `Segera perpanjang agar tidak terputus!\n` +
        `Ketik /start → <b>Buy Akses</b></blockquote>`,
        { parse_mode: 'HTML' }
      );
      console.log(`[expiry notif] ✅ Notif terkirim ke ${userId} (${type}, ${sisa} hari)`);
    } catch (e) {
      console.log(`[expiry notif] ❌ Gagal kirim ke ${userId}: ${e.message}`);
    }
  };

  for (const [uid, data] of Object.entries(adminData)) {
    if (data.expiredAt) await notify(uid, 'Admin', data.expiredAt);
  }
  for (const [uid, data] of Object.entries(premData)) {
    if (data.expiredAt) await notify(uid, 'Premium', data.expiredAt);
  }
};

// Jalankan cek expiry tiap 12 jam
setInterval(checkExpiryNotif, 12 * 60 * 60 * 1000);

// === FUNGSI SAVE DATA (DENGAN BACKUP) ===
const saveData = (file, data) => {
  try {
    backupData(file, data);
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
    console.log(`Saved ${file}:`, Object.keys(data).length || data.length);
  } catch (error) {
    console.error(`Error saving ${file}:`, error);
  }
};

// === Helper Expiry ===
const parseExpiry = (str) => {
  // Format: 1d, 7d, 30d, 1h, 1m (month), permanent/selamanya
  if (!str) return null;
  const s = str.toLowerCase().trim();
  if (s === 'permanent' || s === 'selamanya' || s === 'p') return null; // null = permanent
  const match = s.match(/^(\d+)(d|h|m)$/);
  if (!match) return false; // invalid
  const val = parseInt(match[1]);
  const unit = match[2];
  const ms = unit === 'h' ? val * 60 * 60 * 1000
            : unit === 'm' ? val * 30 * 24 * 60 * 60 * 1000
            : val * 24 * 60 * 60 * 1000;
  return Date.now() + ms;
};

const formatExpiry = (expiredAt) => {
  if (!expiredAt) return '♾️ Permanen';
  const diff = expiredAt - Date.now();
  if (diff <= 0) return '⛔ Expired';
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  if (d > 0) return `${d} hari ${h} jam`;
  if (h > 0) return `${h} jam ${m} menit`;
  return `${m} menit`;
};

const isExpired = (expiredAt) => expiredAt && Date.now() > expiredAt;

// Load dengan cek expiry (support array lama & object baru)
const loadWithExpiry = (file) => {
  try {
    if (!fs.existsSync(file)) return {};
    const raw = JSON.parse(fs.readFileSync(file));
    // Migrasi dari array ke object — expiredAt null HANYA jika memang tidak ada data expiry
    if (Array.isArray(raw)) {
      const obj = {};
      raw.forEach(id => { obj[id] = { expiredAt: null, addedAt: Date.now(), migratedFrom: 'array' }; });
      fs.writeFileSync(file, JSON.stringify(obj, null, 2));
      return obj;
    }
    // Pastikan setiap entry punya struktur yang benar
    const result = {};
    for (const [id, val] of Object.entries(raw)) {
      if (typeof val === 'object' && val !== null) {
        result[id] = val;
      } else {
        // Entry rusak/null — anggap permanen (legacy)
        result[id] = { expiredAt: null, addedAt: Date.now(), migratedFrom: 'invalid' };
      }
    }
    return result;
  } catch { return {}; }
};

const saveWithExpiry = (file, data) => {
  try {
    // Validasi semua expiredAt sebelum disimpan
    const clean = {};
    for (const [id, val] of Object.entries(data)) {
      clean[id] = {
        ...val,
        expiredAt: (val.expiredAt === null || typeof val.expiredAt === 'number')
          ? val.expiredAt
          : null // kalau rusak, fallback ke permanen
      };
    }
    fs.writeFileSync(file, JSON.stringify(clean, null, 2));
  } catch {}
};

// Extend expiry dari waktu yang sudah ada (bukan dari now)
const extendExpiry = (currentExpiredAt, str) => {
  const base = (currentExpiredAt && currentExpiredAt > Date.now()) ? currentExpiredAt : Date.now();
  const s = str.toLowerCase().trim();
  if (s === 'permanent' || s === 'selamanya' || s === 'p') return null;
  const match = s.match(/^(\d+)(d|h|m)$/);
  if (!match) return false;
  const val = parseInt(match[1]);
  const unit = match[2];
  const ms = unit === 'h' ? val * 3600000
            : unit === 'm' ? val * 30 * 86400000
            : val * 86400000;
  return base + ms;
};

// === Helper: Edit pesan (caption atau text, otomatis fallback) ===
const safeEdit = async (ctx, text, extra = {}) => {
  await ctx.editMessageCaption(text, extra)
    .catch(() => ctx.editMessageText(text, extra)
    .catch(() => {}));
};

// === Helper Role ===
const isOwner = (id) => id === config.OWNER_ID;

const isReseller = (id) => {
  if (isOwner(id)) return true;
  const data = loadWithExpiry('./resellers.json');
  const entry = data[id];
  if (!entry) return false;
  if (entry.expiredAt && Date.now() > entry.expiredAt) return false;
  return true;
};

const isAdmin = (id) => {
  if (isOwner(id)) return true;
  const data = loadWithExpiry(ADMIN_FILE);
  const entry = data[id];
  if (!entry) return false;
  if (isExpired(entry.expiredAt)) return false;
  return true;
};

const isPremium = (id) => {
  if (isAdmin(id)) return true;
  const data = loadWithExpiry(PREMIUM_FILE);
  const entry = data[id];
  if (entry && !isExpired(entry.expiredAt)) return true;
  // Group premium (gratis dari milestone grup)
  if (hasGroupPremium(id)) return true;
  return false;
};

// Cek apakah premium BERBAYAR (dari payment atau addprem manual oleh owner/admin)
// Group premium TIDAK termasuk kategori ini
const isPaidPremium = (id) => {
  if (isAdmin(id)) return true;
  const data = loadWithExpiry(PREMIUM_FILE);
  const entry = data[id];
  if (!entry) return false;
  if (isExpired(entry.expiredAt)) return false;
  return true;
};


// === GROUP PREMIUM (otomatis dari milestone 3 grup) ===
// Struktur: { userId: { expiredAt, milestone } }
const loadGroupPremium = () => {
  try {
    if (!fs.existsSync(GROUP_PREMIUM_FILE)) return {};
    return JSON.parse(fs.readFileSync(GROUP_PREMIUM_FILE, 'utf8'));
  } catch { return {}; }
};

const saveGroupPremium = (data) => {
  try { fs.writeFileSync(GROUP_PREMIUM_FILE, JSON.stringify(data, null, 2)); } catch {}
};

// Cek apakah user punya group premium aktif (belum expire)
const hasGroupPremium = (userId) => {
  const data = loadGroupPremium();
  const entry = data[String(userId)];
  if (!entry) return false;
  if (!entry.expiredAt) return false;
  return Date.now() < entry.expiredAt;
};

// Extend/set group premium +2 hari dari sekarang (atau dari sisa waktu)
const extendGroupPremium = (userId, groupCount) => {
  const data = loadGroupPremium();
  const uid = String(userId);
  const now = Date.now();
  const TWO_DAYS = 2 * 24 * 60 * 60 * 1000;

  // Mulai dari sisa waktu kalau masih aktif, atau dari sekarang
  const base = (data[uid]?.expiredAt && data[uid].expiredAt > now) ? data[uid].expiredAt : now;
  data[uid] = {
    expiredAt: base + TWO_DAYS,
    milestone: groupCount,
    lastExtended: now
  };
  saveGroupPremium(data);
  return data[uid].expiredAt;
};

// === KICK TRACKING ===
// Struktur: { userId: { kickCount: N, kickedGroups: [chatId, ...] } }
const loadKickTrack = () => {
  try {
    if (!fs.existsSync(KICK_TRACK_FILE)) return {};
    return JSON.parse(fs.readFileSync(KICK_TRACK_FILE, 'utf8'));
  } catch { return {}; }
};

const saveKickTrack = (data) => {
  try { fs.writeFileSync(KICK_TRACK_FILE, JSON.stringify(data, null, 2)); } catch {}
};

// Tambah 1 kick count untuk user, return total kickCount setelah tambah
const addKickCount = (userId, chatId) => {
  const data = loadKickTrack();
  const uid = String(userId);
  if (!data[uid]) data[uid] = { kickCount: 0, kickedGroups: [] };
  // Hindari double count kalau grup sama dikick 2x
  if (!data[uid].kickedGroups.includes(String(chatId))) {
    data[uid].kickCount += 1;
    data[uid].kickedGroups.push(String(chatId));
  }
  saveKickTrack(data);
  return data[uid].kickCount;
};

// Reset kick count (misal user re-add bot ke grup baru & dapat premium lagi)
const resetKickCount = (userId) => {
  const data = loadKickTrack();
  const uid = String(userId);
  if (data[uid]) {
    data[uid].kickCount = 0;
    data[uid].kickedGroups = [];
    saveKickTrack(data);
  }
};

const getKickCount = (userId) => {
  const data = loadKickTrack();
  return data[String(userId)]?.kickCount || 0;
};

// Cabut group premium user (set expiredAt ke masa lalu)
const revokeGroupPremium = (userId) => {
  const data = loadGroupPremium();
  const uid = String(userId);
  if (data[uid]) {
    data[uid].expiredAt = Date.now() - 1; // langsung expired
    data[uid].revokedAt = Date.now();
    data[uid].revokeReason = 'kick_3_groups';
    saveGroupPremium(data);
  }
};

// === FUNGSI ROLE & DELAY ===
const getRole = (userId) => {
    if (isOwner(userId)) return 'OWNER';
    if (isAdmin(userId)) return 'ADMIN';
    if (isPaidPremium(userId)) return 'PREMIUM';
    if (hasGroupPremium(userId)) return 'GROUP_PREMIUM';
    return 'FREE';
};

const getDelayByRole = (userId) => {
    const role = getRole(userId);
    return config.DELAY_ANTAR_GRUP[role] || 5000;
};

const getAutoShareInterval = (userId) => {
    const role = getRole(userId);
    return config.AUTO_SHARE_INTERVAL[role] || 0;
};

const canAutoShare = (userId) => {
    return isOwner(userId) || isAdmin(userId) || isPaidPremium(userId);
};

// === CEK JUMLAH SHARE FREE HARI INI ===
const getTodayFreeShares = (userId) => {
    const delays = loadData(DELAY_FILE);
    const today = new Date().toDateString();
    const userData = delays[userId] || {};
    
    if (userData.date !== today) {
        return 0;
    }
    return userData.count || 0;
};

const incrementFreeShareCount = (userId) => {
    const delays = loadData(DELAY_FILE);
    const today = new Date().toDateString();
    
    if (!delays[userId]) {
        delays[userId] = { date: today, count: 1 };
    } else if (delays[userId].date !== today) {
        delays[userId] = { date: today, count: 1 };
    } else {
        delays[userId].count = (delays[userId].count || 0) + 1;
    }
    
    saveData(DELAY_FILE, delays);
};

// === CEK GRUP USER ===
const getUserGroups = (userId) => {
  const groups = loadData(GROUPS_FILE);
  return Object.entries(groups)
    .filter(([_, addedBy]) => addedBy == userId)
    .map(([groupId]) => groupId);
};

// === FUNGSI UNTUK HANDLE RATE LIMIT ===
const sendWithRetry = async (ctx, targetChatId, fromChatId, messageId, retryCount = 0) => {
  try {
    await ctx.telegram.copyMessage(targetChatId, fromChatId, messageId);
    return { success: true, error: null };
  } catch (error) {
    if (error.description && error.description.includes('flood')) {
      const waitTime = 30000;
      console.log(`⚠️ Kena flood, tunggu ${waitTime/1000} detik...`);
      await new Promise(r => setTimeout(r, waitTime));
      
      const maxRetry = config.MAX_RETRY || 3;
      
      if (retryCount < maxRetry) {
        console.log(`🔄 Retry ke-${retryCount + 1}...`);
        return sendWithRetry(ctx, targetChatId, fromChatId, messageId, retryCount + 1);
      }
    }
    return { success: false, error: error.description };
  }
};

// === FUNGSI CEK VERIFIKASI DENGAN CHANNEL ID NUMERIC ===
const checkRequirement = async (userId) => {
  // Cek semua channel wajib untuk semua user (kecuali owner)
  if (!isOwner(userId)) {
    for (const ch of config.REQUIRED_JOINS) {
      try {
        const chatMember = await bot.telegram.getChatMember(ch.id, userId);
        const statuses = ['member', 'administrator', 'creator'];
        if (!statuses.includes(chatMember.status)) return false;
      } catch (error) {
        console.log('Error cek channel:', error.message);
        return false;
      }
    }
  }

  // Semua user yang sudah join semua channel langsung bisa akses bot
  // Syarat 3 grup hanya dicek saat user mau share
  return true;
};

// === Logika Token Harian ===
const getDailyToken = (userId) => {
  if (isPremium(userId)) return 999;
  let tokens = loadData(TOKENS_FILE);
  const today = new Date().toDateString();

  if (!tokens[userId] || tokens[userId].date !== today) {
    const gacha = Math.floor(Math.random() * (5 - 2 + 1)) + 2;
    tokens[userId] = { count: gacha, date: today };
    saveData(TOKENS_FILE, tokens);
  }
  return tokens[userId].count;
};

const reduceToken = (userId) => {
  if (isPremium(userId)) return;
  let tokens = loadData(TOKENS_FILE);
  if (tokens[userId] && tokens[userId].count > 0) {
    tokens[userId].count -= 1;
    saveData(TOKENS_FILE, tokens);
  }
};

// === LOGIKA ANTRIAN ===
const getRealTimeQueue = () => {
    let active = [];

    // User yang sedang aktif share sekarang (bisa lebih dari 1 karena paralel)
    for (const uid of currentlySharing) {
        active.push({ uid, power: isOwner(uid) ? 3 : isAdmin(uid) ? 2 : 1, current: true });
    }

    // User auto share aktif yang sedang menunggu interval berikutnya
    for (let [uid, status] of autoShareStatus.entries()) {
        if (status === 'on' && !active.some(a => a.uid === uid)) {
            active.push({ uid, power: isOwner(uid) ? 3 : isAdmin(uid) ? 2 : 1, current: false });
        }
    }

    active.sort((a, b) => b.power - a.power);

    if (active.length === 0) return "\n<i>(Kosong)</i>";

    return active.map((u, i) => {
        let label = isOwner(u.uid) ? "👑 OWNER" : (isAdmin(u.uid) ? "🛠️ ADMIN" : "💎 PREMIUM");
        let tag = u.current ? ' ▶️' : ' ⏸️';
        return `\n${i+1}. ${label}${tag}`;
    }).join('');
};

// === GLOBAL SHARE — DELAY START BERDASARKAN ROLE ===
// Owner: langsung, Admin: +3 detik, Premium: +6 detik
const roleStartDelay = (uid) => {
  if (isOwner(uid)) return 0;
  if (isAdmin(uid)) return 3000;
  return 6000; // Premium & Free
};

const currentlySharing = new Set(); // userId yang sedang aktif share

const enqueueShare = (ctx, mode, loopCount = 1, forceMsgId = null) => {
  const userId = ctx.from.id;

  // Cegah double share dari user yang sama
  if (currentlySharing.has(userId)) {
    ctx.reply('⏳ Kamu sudah sedang share. Tunggu selesai dulu.');
    return; // langsung return, tidak await apapun
  }

  // Jalankan async tapi TIDAK di-await — bot tetap bisa handle request lain
  (async () => {
    const delay = roleStartDelay(userId);
    if (delay > 0) {
      await new Promise(r => setTimeout(r, delay));
    }
    currentlySharing.add(userId);
    try {
      await _runShare(ctx, mode, loopCount, forceMsgId);
    } catch (e) {
      console.error(`Share error for ${userId}:`, e.message);
    }
    currentlySharing.delete(userId);
  })();
};

// === LOGIKA SHARE DENGAN DELAY BERDASARKAN ROLE ===
const _runShare = async (ctx, mode, loopCount = 1, forceMsgId = null) => {
    const userId = ctx.from.id;
    const tokens = getDailyToken(userId);
    const role = getRole(userId);

    console.log(`🚀 runShare dipanggil: mode=${mode}, userId=${userId}, role=${role}, loop=${loopCount}`);

    // CEK AKSES BERDASARKAN MODE
    if (mode === 'free') {
        // Semua user (selain FREE) bisa /share
        if (role === 'FREE') {
            return ctx.reply(
                '⛔ <b>Akses ditolak!</b>\n\nTambahkan bot ke minimal 3 grup untuk mendapatkan akses premium gratis 2 hari.\n\nAtau beli akses premium melalui menu /start → Buy Akses.',
                { parse_mode: 'HTML' }
            );
        }
    } else if (mode === 'vip') {
        // /sharevip: semua premium (berbayar maupun group premium) bisa
        if (role === 'FREE') {
            return ctx.reply(
                '⛔ <b>Akses ditolak!</b>\n\nTambahkan bot ke minimal 3 grup untuk mendapatkan akses premium gratis 2 hari.\n\nAtau beli akses premium melalui menu /start → Buy Akses.',
                { parse_mode: 'HTML' }
            );
        }
        // Cek jika auto share sedang aktif — tolak agar tidak konflik
        if (autoShareStatus.get(userId) === 'on') {
            return ctx.reply(
                "⚠️ <b>Auto share sedang aktif!</b>\n\nMatikan dulu dengan <code>auto off</code> sebelum menggunakan /sharevip.",
                { parse_mode: 'HTML' }
            );
        }
    } else if (mode === 'autoshare') {
        // Auto share: semua premium bisa
        if (role === 'FREE') {
            return ctx.reply(
                '⛔ <b>Akses ditolak!</b>\n\nTambahkan bot ke minimal 3 grup untuk mendapatkan akses premium gratis 2 hari.',
                { parse_mode: 'HTML' }
            );
        }
        if (autoShareStatus.get(userId) === 'off') {
            console.log(`🛑 Auto share untuk user ${userId} dimatikan`);
            autoShareTime.delete(userId);
            return;
        }
    }

    let currentMsgId = forceMsgId;
    let chatId = ctx.chat.id;
    
    if (!currentMsgId) {
        if (ctx.message.reply_to_message) {
            currentMsgId = ctx.message.reply_to_message.message_id;
        } else if (mode !== 'autoshare') {
            const text = ctx.message.text.split(' ').slice(1).join(' ');
            if (!text) {
                return ctx.reply("⚠️ Gunakan: /share teks anda atau reply pesan");
            }
            
            const sentMsg = await ctx.reply(text, { parse_mode: 'HTML' });
            currentMsgId = sentMsg.message_id;
        }
    }
    
    if (mode === 'autoshare') {
        currentMsgId = autoShareMessageId.get(userId) || userMessages.get(userId);
        if (!currentMsgId) {
            return ctx.reply("⚠️ Untuk auto share, wajib /setpesan dulu!");
        }
        autoShareMessageId.set(userId, currentMsgId);
    }
    
    if (!currentMsgId) {
        return ctx.reply("⚠️ Tidak ada pesan yang dishare!");
    }

    const groupsData = loadData(GROUPS_FILE);
    const groupIds = Object.keys(groupsData);
    
    if (groupIds.length === 0) {
        return ctx.reply("❌ Belum ada grup terdaftar.");
    }
    
    const totalDb = groupIds.length;
    const antrianText = getRealTimeQueue();
    const startTime = Date.now();
    
    // Dapatkan delay berdasarkan role
    const shareDelay = getDelayByRole(userId);
    const autoInterval = getAutoShareInterval(userId);

    console.log(`📊 Data: totalDb=${totalDb}, shareDelay=${shareDelay}, autoInterval=${autoInterval}`);

    // Hapus pesan progress/standby putaran sebelumnya
    const lastShareMsg = lastShareMsgId.get(userId);
    if (lastShareMsg) {
      await ctx.telegram.deleteMessage(ctx.chat.id, lastShareMsg).catch(() => {});
      lastShareMsgId.delete(userId);
    }

    const progressMsg = await ctx.reply(
        `<blockquote>` +
        `${mode === 'autoshare' ? '🤖 AUTO SHARE' : mode === 'vip' ? '⚡ SHARE VIP' : '📤 SHARE'} — PUTARAN ${loopCount}\n\n` +
        `👤 Role    : <b>${role}</b>\n` +
        `📦 Grup    : <b>${totalDb}</b> target\n` +
        `⏱️ Delay   : <b>${shareDelay/1000} detik</b>/grup\n` +
        `🕐 Estimasi: <b>~${Math.ceil(totalDb * shareDelay / 1000 / 60)} menit</b>\n\n` +
        `⏳ Memulai pengiriman...` +
        `</blockquote>`,
        { parse_mode: 'HTML' }
    );

    // Simpan ID progress pesan ini
    lastShareMsgId.set(userId, progressMsg.message_id);
    
    let success = 0;
    let failed = 0;
    let failedGroups = [];
    
    for (let gid of groupIds) {
        if (mode === 'autoshare' && autoShareStatus.get(userId) === 'off') break;

        // Skip grup yang di-blacklist MANUAL saja (bukan auto-blacklist result 3x fail)
        // Biar auto-share tetap mencoba semua grup, termasuk yang pernah gagal
        const blEntry = loadBlacklist()[gid];
        if (blEntry?.permanent) {
            console.log(`[blacklist-manual] Skip grup ${gid}`);
            continue;
        }
        
        const result = await sendWithRetry(ctx, gid, chatId, currentMsgId);
        
        if (result.success) {
            success++;
            console.log(`✅ [${role}] ${userId} -> grup ${gid}`);
        } else {
            failed++;
            failedGroups.push({ id: gid, error: result.error });
            console.log(`❌ [${role}] ${userId} gagal ke ${gid}: ${result.error}`);
            // Catat kegagalan untuk auto-blacklist
            recordGroupFail(gid, result.error);
        }
        
        if ((success + failed) % 5 === 0 || (success + failed) === totalDb) {
            const elapsed = Math.floor((Date.now() - startTime) / 1000);
            const remaining = Math.ceil((totalDb - (success + failed)) * shareDelay / 1000);
            const pct = Math.floor(((success + failed) / totalDb) * 100);
            const filled = Math.floor(pct / 10);
            const bar = '█'.repeat(filled) + '░'.repeat(10 - filled);
            
            await ctx.telegram.editMessageText(
                ctx.chat.id, 
                progressMsg.message_id, 
                null, 
                `<blockquote>` +
                `${mode === 'autoshare' ? '🤖 AUTO SHARE' : mode === 'vip' ? '⚡ SHARE VIP' : '📤 SHARE'} — PUTARAN ${loopCount}\n\n` +
                `👤 Role    : <b>${role}</b>\n` +
                `📊 Progress: [${bar}] ${pct}%\n` +
                `✅ Berhasil: <b>${success}</b>  ❌ Gagal: <b>${failed}</b>\n` +
                `📦 Terkirim: <b>${success + failed}/${totalDb}</b>\n` +
                `⏱️ Berjalan: <b>${Math.floor(elapsed/60)}m ${elapsed%60}s</b>\n` +
                `⏳ Sisa est.: <b>~${Math.floor(remaining/60)}m ${remaining%60}s</b>\n` +
                `👥 Antrian:${antrianText}` +
                `</blockquote>`,
                { parse_mode: 'HTML' }
            ).catch(() => {});
        }
        
        await new Promise(r => setTimeout(r, shareDelay));
    }

    const totalTime = Math.floor((Date.now() - startTime) / 1000);
    
    // Catat statistik
    recordShareStats(userId, success, failed);

    let failedReport = '';
    if (failed > 0 && failedGroups.length > 0) {
        failedReport = '\n\n❌ <b>Grup Gagal:</b>\n';
        failedGroups.slice(0, 5).forEach((g, i) => {
            failedReport += `${i+1}. <code>${g.id}</code>: ${g.error?.substring(0, 50)}...\n`;
        });
        if (failedGroups.length > 5) {
            failedReport += `   ... dan ${failedGroups.length - 5} grup lainnya\n`;
        }
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id, 
        progressMsg.message_id, 
        null, 
        `<blockquote>` +
        `${mode === 'autoshare' ? '🤖 AUTO SHARE' : mode === 'vip' ? '⚡ SHARE VIP' : '📤 SHARE'} — SELESAI ✅\n\n` +
        `👤 Role    : <b>${role}</b>\n` +
        `🔁 Putaran : <b>${loopCount}</b>\n` +
        `📊 Progress: [██████████] 100%\n` +
        `✅ Berhasil: <b>${success}</b>  ❌ Gagal: <b>${failed}</b>\n` +
        `📦 Total   : <b>${totalDb} grup</b>\n` +
        `⏱️ Durasi  : <b>${Math.floor(totalTime/60)}m ${totalTime%60}s</b>\n` +
        `🎟️ Sisa token: <b>${getDailyToken(userId)}</b>` +
        `${failedReport}` +
        `</blockquote>`,
        { parse_mode: 'HTML' }
    );

    // Simpan ID pesan SELESAI agar bisa dihapus di putaran berikutnya
    lastShareMsgId.set(userId, progressMsg.message_id);

    if (!ctx.message.reply_to_message && mode !== 'autoshare' && currentMsgId) {
        try {
            await ctx.telegram.deleteMessage(chatId, currentMsgId);
        } catch {}
    }

    // UNTUK AUTO SHARE: LOOP DENGAN INTERVAL SESUAI ROLE
if (mode === 'autoshare' && autoShareStatus.get(userId) === 'on') {
    console.log(`🔄 Auto share: next run in ${autoInterval/1000}s, interval=${autoInterval}`);
    
    if (autoInterval > 0) {
        // Kirim notifikasi tanpa fitur delete
        try {
            const nextRun = new Date(Date.now() + autoInterval).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });

            // Hapus pesan SELESAI sebelum kirim standby
            const selesaiMsgId = lastShareMsgId.get(userId);
            if (selesaiMsgId) {
              await ctx.telegram.deleteMessage(ctx.chat.id, selesaiMsgId).catch(() => {});
            }

            const standbyMsg = await ctx.reply(
                `<blockquote>` +
                `🤖 AUTO SHARE — STANDBY\n\n` +
                `✅ Putaran <b>${loopCount}</b> selesai!\n\n` +
                `📊 Hasil  : <b>${success}</b> berhasil / <b>${failed}</b> gagal\n` +
                `👥 Target : <b>${totalDb} grup</b>\n` +
                `⏰ Putaran ${loopCount + 1} jam: <b>${nextRun} WIB</b>\n` +
                `⏳ Jeda   : <b>${autoInterval / 1000 / 60} menit</b>\n\n` +
                `<i>Ketik "auto off" untuk menghentikan.</i>` +
                `</blockquote>`,
                { parse_mode: 'HTML' }
            );
            // Simpan ID standby agar bisa dihapus di putaran berikutnya
            lastShareMsgId.set(userId, standbyMsg.message_id);
        } catch (notifError) {
            console.log('Gagal kirim notifikasi:', notifError.message);
        }
        
        autoShareMessageId.set(userId, currentMsgId);
        
        console.log(`⏱️ Auto share [${role}] ${userId}: next run in ${autoInterval/1000}s`);
        
        setTimeout(() => {
            if (autoShareStatus.get(userId) === 'on') {
                console.log(`🔄 Running auto share putaran ${loopCount + 1} untuk [${role}] ${userId}`);
                enqueueShare(ctx, 'autoshare', loopCount + 1, autoShareMessageId.get(userId));
            } else {
                console.log(`🛑 Auto share untuk ${userId} dimatikan saat timeout.`);
            }
        }, autoInterval);
    } else {
        console.log(`❌ autoInterval tidak valid (${autoInterval}), auto share tidak dilanjutkan`);
    }
}
};

// === START Command ===
bot.start(async (ctx) => {
  waitingForProof.delete(ctx.from.id);
  
  let users = loadData(USERS_FILE);
  const isNewUser = !users.includes(ctx.from.id);
  if (isNewUser) { 
    users.push(ctx.from.id); 
    saveData(USERS_FILE, users);

    // Notif ke owner + broadcast ke channel utama
    const u = ctx.from;
    const fullName = [u.first_name, u.last_name].filter(Boolean).join(' ');
    const username = u.username ? `@${u.username}` : '<i>tidak ada</i>';
    const notifText =
      `🔔 <b>USER BARU DAFTAR!</b>\n\n` +
      `👤 Nama: <b>${fullName}</b>\n` +
      `🆔 ID: <code>${u.id}</code>\n` +
      `📛 Username: ${username}\n` +
      `👥 Total user: <b>${users.length}</b>\n` +
      `🕐 Waktu: ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })} WIB`;
    try {
      // Notif ke owner
      await bot.telegram.sendMessage(config.OWNER_ID, notifText, { parse_mode: 'HTML' });
    } catch {}
    try {
      // Broadcast ke channel utama + link bot
      const botUsername = ctx.botInfo?.username || '';
      const channelExtra = {
        parse_mode: 'HTML',
        ...(botUsername ? Markup.inlineKeyboard([[Markup.button.url('🤖 Masuk ke Bot', `https://t.me/${botUsername}`)]]) : {})
      };
      await bot.telegram.sendMessage(config.CHANNEL_ID, notifText, channelExtra);
    } catch {}
  }

  const isVerified = await checkRequirement(ctx.from.id);
  
  if (isVerified) {
    return sendStartMenu(ctx);
  }

  const userGroups = getUserGroups(ctx.from.id);
  const userGroupCount = userGroups.length;

  // Cek semua channel wajib (REQUIRED_JOINS)
  const joinResults = await Promise.all(
    config.REQUIRED_JOINS.map(async (ch) => {
      try {
        const cm = await bot.telegram.getChatMember(ch.id, ctx.from.id);
        return ['member', 'administrator', 'creator'].includes(cm.status);
      } catch { return false; }
    })
  );
  const hasJoinedAll = joinResults.every(Boolean);

  // Syarat minimal buy akses: sudah join semua channel + minimal 1 grup
  const canBuy = hasJoinedAll && userGroupCount >= 1;

  const u2 = ctx.from;
  const usernameDisplay2 = u2.username ? `@${u2.username}` : `<b>${[u2.first_name, u2.last_name].filter(Boolean).join(' ')}</b>`;

  const progressLines = config.REQUIRED_JOINS.map((ch, i) =>
    `• ${ch.text} : ${joinResults[i] ? '✅ Sudah join' : '❌ Belum join'}`
  ).join('\n');

  const caption =
    `<blockquote>( ${hasJoinedAll ? '✅' : '❌'} ) —初め𝗢𝗟𝗔𝗔  ${usernameDisplay2}</blockquote>\n\n` +
    `Anda belum memenuhi syarat:\n` +
    `• Join ${config.REQUIRED_JOINS.length} channel/grup\n\n` +
    `📊 <b>PROGRES ANDA:</b>\n` +
    `${progressLines}\n\n` +
    `<i>💡 Join semua channel/grup untuk memasuki bot</i>`;

  const buttons = [
    ...config.REQUIRED_JOINS.map(ch => [Markup.button.url(`📢 JOIN ${ch.text}`, ch.url)]),
    [Markup.button.callback('✅ VERIFIKASI', 'verify_user')]
  ];

  await ctx.reply(caption, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard(buttons)
  });
});

// === ACTION VERIFY ===
bot.action('verify_user', async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  
  const isVerified = await checkRequirement(ctx.from.id);
  const userGroups = getUserGroups(ctx.from.id);
  const userGroupCount = userGroups.length;
  
  if (!isVerified) {
    const joinResults = await Promise.all(
      config.REQUIRED_JOINS.map(async (ch) => {
        try {
          const cm = await ctx.telegram.getChatMember(ch.id, ctx.from.id);
          return ['member', 'administrator', 'creator'].includes(cm.status);
        } catch { return false; }
      })
    );

    const uv = ctx.from;
    const unameV = uv.username ? `@${uv.username}` : `<b>${[uv.first_name, uv.last_name].filter(Boolean).join(' ')}</b>`;

    const progressLines = config.REQUIRED_JOINS.map((ch, i) =>
      `• ${ch.text} : ${joinResults[i] ? '✅ Sudah join' : '❌ Belum join'}`
    ).join('\n');

    const reason =
      `<blockquote>( ❌ ) —初め𝗢𝗟𝗔𝗔  ${unameV}</blockquote>\n\n` +
      `Anda belum memenuhi syarat:\n` +
      `• Join ${config.REQUIRED_JOINS.length} channel/grup\n\n` +
      `📊 <b>PROGRES ANDA:</b>\n` +
      `${progressLines}\n\n` +
      `<i>💡 Join semua channel/grup untuk memasuki bot</i>`;

    return ctx.reply(reason, {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        ...config.REQUIRED_JOINS.map(ch => [Markup.button.url(`📢 JOIN ${ch.text}`, ch.url)]),
        [Markup.button.callback('🔄 CEK LAGI', 'verify_user')]
      ])
    });
  }
  
  await ctx.reply("✅ <b>VERIFIKASI BERHASIL!</b>\nSelamat, Anda sekarang bisa menggunakan bot!", { parse_mode: 'HTML' });
  sendStartMenu(ctx);
});

// === MIDDLEWARE 0: BLOKIR PENGGUNAAN DI GRUP ===
bot.use(async (ctx, next) => {
  const chatType = ctx.chat?.type;

  if (chatType === 'group' || chatType === 'supergroup') {
    // Owner boleh pakai di grup
    if (isOwner(ctx.from?.id)) return next();

    // Hanya blokir command, semua pesan biasa tetap jalan (untuk autotag dll)
    if (ctx.message?.text?.startsWith('/')) {
      await ctx.deleteMessage().catch(() => {});
      return; // Diam saja
    }

    return next();
  }

  return next();
});

// === MIDDLEWARE 1: CEK MAINTENANCE ===
bot.use(async (ctx, next) => {
  if (maintenanceMode) {
    if (isOwner(ctx.from?.id) || (ctx.message?.text && ctx.message.text.startsWith('/mtc'))) {
      return next();
    }
    
    if (ctx.message && ctx.message.text && ctx.message.text.startsWith('/')) {
      return ctx.reply(
        `<b>🔧 BOT SEDANG MAINTENANCE</b>\n\n` +
        `Maaf, bot sedang dalam perbaikan.\n` +
        `Silakan coba lagi nanti.\n\n` +
        `🕐 Mulai: ${new Date().toLocaleString('id-ID')}`,
        { parse_mode: 'HTML' }
      );
    }
    
    if (ctx.callbackQuery) {
      await ctx.answerCbQuery('🔧 Bot sedang maintenance', { show_alert: true });
      return;
    }
  }
  
  return next();
});

// === MIDDLEWARE 2: ANTI SPAM COOLDOWN ===
bot.use(async (ctx, next) => {
  if (!ctx.message || !ctx.message.text || !ctx.message.text.startsWith('/')) {
    return next();
  }

  const userId = ctx.from?.id;
  if (!userId || isOwner(userId)) return next(); // Owner bebas cooldown

  const sisa = checkCooldown(userId);
  if (sisa > 0) {
    return ctx.reply(
      `⏳ <b>Terlalu cepat!</b>\n\nTunggu <b>${sisa} detik</b> lagi sebelum kirim perintah berikutnya.`,
      { parse_mode: 'HTML' }
    );
  }

  return next();
});

// === MIDDLEWARE 3: CEK VERIFIKASI ===
bot.use(async (ctx, next) => {
  if (!ctx.message || !ctx.message.text || !ctx.message.text.startsWith('/')) {
    return next();
  }

  const cmd = ctx.message.text.split(' ')[0].toLowerCase();
  const publicCommands = ['/start', '/help', '/cek', '/mtc'];
  
  if (publicCommands.includes(cmd)) {
    return next();
  }

  const isVerified = await checkRequirement(ctx.from.id);
  
  if (!isVerified) {
    const userGroups = getUserGroups(ctx.from.id);
    const userGroupCount = userGroups.length;
    
    return ctx.reply(
      `<b>⛔ AKSES DITOLAK!</b>\n\n` +
      `Anda harus verifikasi dulu di /start\n` +
      `Progres: ${userGroupCount}/3 grup`,
      { 
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('🔄 CEK VERIFIKASI', 'verify_user')],
          [Markup.button.url('💎 BELI PREMIUM', config.CONTACT_URL)]
        ])
      }
    );
  }
  
  return next();
});

// === EVENT BOT DITAMBAHKAN KE GRUP ===
bot.on('my_chat_member', async (ctx) => {
  if (!['group', 'supergroup'].includes(ctx.chat.type)) return;
  
  const newStatus = ctx.myChatMember.new_chat_member.status;
  const userId = ctx.from.id;
  
  if (['member', 'administrator'].includes(newStatus)) {
    let groups = loadData(GROUPS_FILE);
    groups[ctx.chat.id] = userId;
    saveData(GROUPS_FILE, groups);

    // === NOTIF KE CHANNEL (NOTIFY_ID) ===
    if (config.NOTIFY_ID) {
      try {
        const userName = ctx.from.first_name + (ctx.from.last_name ? ` ${ctx.from.last_name}` : '');
        const groupId = ctx.chat.id;
        const groupName = ctx.chat.title || 'Unknown';
        let memberCount = '?';
        try {
          memberCount = await bot.telegram.getChatMembersCount(groupId);
        } catch (_) {}

        await bot.telegram.sendMessage(
          config.NOTIFY_ID,
          `<blockquote>🎉 <b>PREMIUM AKTIF</b> 🎉\n\n` +
          `👤 Pengguna      : <b>${userName}</b>\n` +
          `🆔 ID Pengguna   : <code>${userId}</code>\n` +
          `🏡 Group         : <b>${groupName}</b>\n` +
          `🔗 Id Group      : <code>${groupId}</code>\n` +
          `📊 Member Group  : <b>${memberCount}</b></blockquote>`,
          { parse_mode: 'HTML' }
        );
      } catch (e) {
        console.log('[notif-channel] Gagal kirim notif:', e.message);
      }
    }
    
    const userGroups = getUserGroups(userId);
    const groupCount = userGroups.length;

    // Cek kelipatan 3 grup -> extend group premium 2 hari
    const gpData = loadGroupPremium();
    const lastMilestone = gpData[String(userId)]?.milestone || 0;
    const newMilestone = Math.floor(groupCount / 3) * 3;

    let premiumMsg = '';
    if (newMilestone >= 3 && newMilestone > lastMilestone) {
      const expiredAt = extendGroupPremium(userId, newMilestone);
      const expDate = new Date(expiredAt).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
      premiumMsg = `\n\n🎉 <b>Selamat! Kamu dapat Premium Gratis!</b>\n` +
        `📅 Aktif sampai: <b>${expDate} WIB</b>\n` +
        `✅ Akses: /share, /sharevip, auto on/off`;
      // Reset kick count saat user berhasil dapat premium baru
      resetKickCount(userId);
    }

    const keyboard = [];
    if (groupCount < 3) {
      keyboard.push([Markup.button.url('➕ ADD GROUP LAGI', `https://t.me/${ctx.botInfo.username}?startgroup=true`)]);
    }
    keyboard.push([Markup.button.callback('💳 BUY AKSES', 'menu_buy')]);

    const progressBar = groupCount >= 3 ? '█'.repeat(3) : '█'.repeat(groupCount) + '░'.repeat(3 - groupCount);
    bot.telegram.sendMessage(
      userId,
      `<blockquote>✅ <b>GRUP TERDAFTAR!</b>\n\n` +
      `🏘️ Nama  : <b>${ctx.chat.title}</b>\n` +
      `📊 Progres: [${progressBar}] ${Math.min(groupCount, 3)}/3` +
      (groupCount < 3 ? `\n⚠️ Kurang ${3 - groupCount} grup lagi untuk premium gratis!` : '') +
      `${premiumMsg}</blockquote>`,
      { parse_mode: 'HTML', ...Markup.inlineKeyboard(keyboard) }
    ).catch(() => {});
  }
  
  if (['left', 'kicked'].includes(newStatus)) {
    let groups = loadData(GROUPS_FILE);
    if (groups[ctx.chat.id]) {
      const addedBy = groups[ctx.chat.id];
      delete groups[ctx.chat.id];
      saveData(GROUPS_FILE, groups);

      // Lacak jumlah kick oleh user ini
      const totalKicks = addKickCount(addedBy, ctx.chat.id);
      const KICK_LIMIT = 3;

      const userGroups = getUserGroups(addedBy);
      const hadGroupPremium = hasGroupPremium(addedBy);

      // === REVOKE PREMIUM jika sudah kick >= 3 grup ===
      let premiumRevoked = false;
      if (totalKicks >= KICK_LIMIT && hadGroupPremium && !isPaidPremium(addedBy)) {
        revokeGroupPremium(addedBy);
        premiumRevoked = true;

        // Matikan auto share otomatis kalau masih aktif
        if (autoShareStatus.get(addedBy) === 'on') {
          autoShareStatus.set(addedBy, 'off');
          autoShareTime.delete(addedBy);
          autoShareMessageId.delete(addedBy);
          // Kirim notif bahwa auto share dimatikan paksa
          bot.telegram.sendMessage(
            addedBy,
            `🛑 <b>AUTO SHARE DIMATIKAN OTOMATIS!</b>\n\nPremium gratis kamu dicabut karena bot dikeluarkan dari ${totalKicks} grup.`,
            { parse_mode: 'HTML' }
          ).catch(() => {});
        }
      }

      // === KIRIM NOTIFIKASI ===
      try {
        let notifMsg =
          `<blockquote>⚠️ <b>BOT DIKELUARKAN DARI GRUP!</b>\n\n` +
          `🏘️ Grup  : <b>${ctx.chat.title}</b>\n` +
          `🆔 ID    : <code>${ctx.chat.id}</code>\n` +
          `📊 Sisa  : <b>${userGroups.length} grup</b> terdaftar\n` +
          `🚫 Total kick bot: <b>${totalKicks}x</b>`;

        if (premiumRevoked) {
          notifMsg +=
            `\n\n🔴 <b>PREMIUM GRATIS DICABUT!</b>\n` +
            `Kamu telah mengeluarkan bot dari <b>${totalKicks} grup berbeda</b>.\n` +
            `Premium gratis & auto share kamu otomatis <b>dimatikan</b>.\n\n` +
            `💡 Tambahkan bot ke <b>3 grup baru</b> melalui /start untuk mendapatkan premium gratis lagi.`;
        } else if (!isPaidPremium(addedBy) && hadGroupPremium && totalKicks === KICK_LIMIT - 1) {
          notifMsg +=
            `\n\n⚠️ <b>PERINGATAN TERAKHIR!</b>\n` +
            `Kamu sudah kick bot dari <b>${totalKicks}x grup</b>.\n` +
            `Jika mengeluarkan bot dari <b>1 grup lagi</b>, premium gratis kamu akan <b>dicabut otomatis</b>!`;
        } else {
          notifMsg += `\n\n${userGroups.length < 3 && !isPremium(addedBy) ? '❗ Grup kamu kurang dari 3, segera tambah grup baru agar bisa share!' : '✅ Kamu masih bisa share.'}`;
        }

        notifMsg += `</blockquote>`;
        await bot.telegram.sendMessage(addedBy, notifMsg, { parse_mode: 'HTML' });
      } catch {}
    }
  }
});

// === HELPER UPTIME ===
const getUptime = () => {
  const ms = Date.now() - BOT_START_TIME;
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (d > 0) return `${d} hari ${h % 24} jam ${m % 60} menit`;
  if (h > 0) return `${h} jam ${m % 60} menit ${s % 60} detik`;
  if (m > 0) return `${m} menit ${s % 60} detik`;
  return `${s} detik`;
};

// === HELPER: Reply Keyboard utama ===
const getMainKeyboard = () => {
  return Markup.keyboard([
    ['🚀 Menu Jasher'],
    ['👤 Owner', '💎 Buy Akses'],
    ['🧰 Tools', '📊 Stats'],
    ['📋 Status'],
  ]).resize();
};

// === HELPER: Reply Keyboard menu share ===
const getShareKeyboard = () => {
  return Markup.keyboard([
    ['⚙️ Auto ON', '⚙️ Auto OFF'],
    ['📋 Status Auto', '📝 Set Pesan'],
    ['🕐 Set Delay'],
    ['📢 Broadcast', '🖼️ Broadcast Image'],
    ['🎬 Broadcast Media'],
    ['👤 Broadcast Users'],
    ['🔙 Main Menu'],
  ]).resize();
};

// === MENU UTAMA ===
const sendStartMenu = async (ctx) => {
  const role = getRole(ctx.from.id);
  const users = loadData(USERS_FILE);
  const groups = loadData(GROUPS_FILE);

  const u = ctx.from;
  const fullName = [u.first_name, u.last_name].filter(Boolean).join(' ');
  const usernameDisplay = u.username ? `@${u.username}` : `<i>tidak ada</i>`;

  const roleLabel =
    role === 'OWNER' ? '<b>Owner 👑</b>' :
    role === 'ADMIN' ? '<b>Admin ⭐</b>' :
    role === 'PREMIUM' ? '<b>Premium 💎</b>' :
    role === 'GROUP_PREMIUM' ? '<b>Premium Gratis 🎁</b>' :
    '<b>User</b>';

  const caption =
    `<blockquote>( 🍁 ) —初め𝗢𝗟𝗔𝗔  ${usernameDisplay}</blockquote>\n` +
    `<blockquote>𝖶𝖾𝗅𝖼𝗈𝗆𝖾 𝖳𝗈 ${ctx.botInfo?.first_name || 'Jasher'} 𝖳𝗁𝗂𝗌 𝗂𝗌 𝖡𝗈𝗍 𝖿𝗈𝗋 𝖲𝗁𝖺𝗋𝗂𝗇𝗀 𝖸𝗈𝗎𝗋 𝗍𝖾𝗑𝗍 𝖳𝗈 𝖠𝗅𝗅 𝖦𝗋𝗈𝗎𝗉\n` +
    `━━━━━━━━━━━━━━━━━━━━━\n` +
    `— ✪ 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 𝗕𝗢𝗧 ✪ —\n` +
    `  └ 𝗗𝗲𝘃 𝗡𝗮𝗺𝗲 : <b>${config.OWNER_NAME}</b>\n` +
    `  └ 𝗕𝗼𝘁 𝗡𝗮𝗺𝗲 : <code>${ctx.botInfo?.first_name || 'ZeteSher'}</code>\n` +
    `  └ 𝗣𝗿𝗲𝗳𝗶𝘅 : /\n` +
    `  └ 𝗕𝗼𝘁 𝗩𝗲𝗿𝘀𝗶𝗼𝗻 : <code>${BOT_VERSION}</code>\n` +
    `\n` +
    `— ꕥ 𝗦𝗧𝗔𝗧𝗜𝗦𝗧𝗜𝗖 𝗕𝗢𝗧 ꕥ —\n` +
    `   └ 𝗨𝗽𝘁𝗶𝗺𝗲 𝗕𝗼𝘁 : <code>${getUptime()}</code>\n` +
    `   └ 𝗚𝗿𝗼𝘂𝗽 : <code>${Object.keys(groups).length} Group</code>\n` +
    `   └ 𝗨𝘀𝗲𝗿𝘀 : <code>${users.length} User</code>\n` +
    `\n` +
    `— 𖨆 𝗨𝗦𝗘𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗧𝗜𝗢𝗡 𖨆 —\n` +
    `   └ 𝗡𝗮𝗺𝗲  : <b>${fullName}</b>\n` +
    `   └ 𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${usernameDisplay}\n` +
    `   └ 𝗜𝗗 : <code>${u.id}</code>\n` +
    `   └ 𝗥𝗼𝗹𝗲 : ${roleLabel}</blockquote>\n` +
    `𝘊𝘭𝘪𝘤𝘬 𝘛𝘩𝘪𝘴 𝘉𝘶𝘵𝘵𝘰𝘯 𝘧𝘰𝘳 𝘜𝘴𝘦`;

  // Hapus pesan /start user
  await ctx.deleteMessage().catch(() => {});

  await ctx.replyWithPhoto(config.THUMBNAIL, {
    caption,
    parse_mode: 'HTML',
    ...getMainKeyboard()
  });
};

// === CALLBACK HANDLERS ===
// === HEARS: Tombol-tombol Reply Keyboard Menu Utama ===

// 🚀 Menu Jasher
bot.hears('🚀 Menu Jasher', async (ctx) => {
  const userId = ctx.from.id;
  const role = getRole(userId);
  const userGroupCount = getUserGroups(userId).length;
  const autoStatus = autoShareStatus.get(userId) || 'off';
  const autoStatusLabel = autoStatus === 'on' ? '🟢 ON' : '🔴 OFF';

  if (!isOwner(userId) && !isAdmin(userId) && !isPaidPremium(userId) && userGroupCount < 3) {
    return ctx.reply(
      `<blockquote>⛔ <b>AKSES DITOLAK!</b>\n\n` +
      `Untuk mengakses menu share, kamu harus\nmenambahkan bot ke minimal <b>3 grup</b> terlebih dahulu.\n\n` +
      `📊 Grup terdaftar: <code>${userGroupCount}/3</code>\n` +
      `⚠️ Kurang <b>${3 - userGroupCount} grup</b> lagi!</blockquote>`,
      {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([
          [Markup.button.url('➕ ADD TO GROUP', `https://t.me/${ctx.botInfo.username}?startgroup=true`)],
        ])
      }
    );
  }

  const shareDelay = getDelayByRole(userId);
  const autoInterval = getAutoShareInterval(userId);

  await ctx.reply(
    `<blockquote>( 📨 ) ❍ 𝗝𝗔𝗦𝗛𝗘𝗥 𝗗𝗔𝗦𝗕𝗢𝗔𝗥𝗗</blockquote>\n` +
    `<blockquote>👤 ʀᴏʟᴇ    : <code>${role}</code>\n` +
    `📊 ᴀᴜᴛᴏ    : <b>${autoStatusLabel}</b>\n` +
    `⏱️ ᴅᴇʟᴀʏ   : <b>${shareDelay/1000} ᴅᴇᴛɪᴋ</b>/ɢʀᴜᴘ\n` +
    `🔁 ɪɴᴛᴇʀᴠᴀʟ: <b>${autoInterval/1000/60 || 0} ᴍᴇɴɪᴛ</b>\n\n` +
    `ᴘɪʟɪʜ ᴀᴋsɪ ᴅɪ ʙᴀᴡᴀʜ:</blockquote>`,
    { parse_mode: 'HTML', ...getShareKeyboard() }
  );
});

// 👤 Owner
bot.hears('👤 Owner', async (ctx) => {
  const userId = ctx.from.id;
  const isAdminUser = isAdmin(userId);
  const isOwnerUser = isOwner(userId);

  if (!isAdminUser) {
    return ctx.reply(
      `<blockquote><b>👤 𝗕𝗶𝗼𝗱𝗮𝘁𝗮 𝗗𝗲𝘃</b>\nɴᴀᴍᴀ : ${config.OWNER_NAME}\nɪᴅ : <code>${config.OWNER_ID}</code></blockquote>`,
      {
        parse_mode: 'HTML',
        ...Markup.inlineKeyboard([[Markup.button.url('⚠︎ Hubungi Owner', config.CONTACT_URL)]])
      }
    );
  }

  const mtcStatus = maintenanceMode ? '🟢 ON' : '🔴 OFF';
  const buttons = [];
  if (isOwnerUser) buttons.push([Markup.button.callback('👑 CMD Owner', 'panel_owner')]);
  buttons.push([Markup.button.callback('🛠️ CMD Admin', 'panel_admin')]);
  buttons.push([Markup.button.url('📞 Hub Owner', config.CONTACT_URL)]);

  return ctx.reply(
    `<blockquote><b>✪ 𝗣𝗮𝗻𝗲𝗹 𝗖𝗼𝗻𝘁𝗿𝗼𝗹</b>\n\n` +
    `♕︎ 𝗢𝘄𝗻𝗲𝗿      : ${config.OWNER_NAME}\n` +
    `✍︎ ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ: ${mtcStatus}\n\n` +
    `ᴘɪʟɪʜ ᴘᴀɴᴇʟ ᴄᴏᴍᴍᴀɴᴅ ᴅɪ ʙᴀᴡᴀʜ:</blockquote>`,
    { parse_mode: 'HTML', ...Markup.inlineKeyboard(buttons) }
  );
});

// 💎 Buy Akses
bot.hears('💎 Buy Akses', async (ctx) => {
  const txt =
    `<blockquote>💳 <b>ʙᴇʟɪ ᴀᴋsᴇs</b>\n\nᴘɪʟɪʜ ᴘᴀᴋᴇᴛ ʏᴀɴɢ ɪɴɢɪɴ ᴅɪʙᴇʟɪ:</blockquote>\n` +
    `<blockquote>ᴄʀᴇᴀᴛᴇᴅ ʙʏ ${config.OWNER_NAME}</blockquote>`;
  return ctx.reply(txt, {
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('💎 Premium', 'buy_PREM'), Markup.button.callback('🛠️ Admin', 'buy_ADM')],
    ])
  });
});

// 🧰 Tools
bot.hears('🧰 Tools', async (ctx) => {
  return ctx.reply(
    `<blockquote> ✯ 𝗧𝗢𝗢𝗟𝗦 𝗠𝗘𝗡𝗨</blockquote>\n` +
    `<blockquote>🎨 /sticker — ᴋᴏɴᴠᴇʀsɪ ꜰᴏᴛᴏ ᴊᴀᴅɪ sᴛɪᴋᴇʀ\n` +
    `📷 /qr [teks] — ʙᴜᴀᴛ ǫʀ ᴄᴏᴅᴇ\n` +
    `🔗 /short [url] — ᴘᴇʀᴘᴇɴᴅᴇᴋ ᴜʀʟ\n` +
    `🌐 /info [url] — ɪɴꜰᴏ ʟɪɴᴋ\n` +
    `🌤️ /cuaca [kota] — ᴄᴇᴋ ᴄᴜᴀᴄᴀ\n` +
    `🔗 /tourl — ꜰᴏᴛᴏ ᴋᴇ ᴜʀʟ\n` +
    `🪪 /cekid — ɪᴅ ᴄᴀʀᴅ\n` +
    `✨ /ai — ᴀɪ ᴇᴅɪᴛ ᴛᴇᴋs</blockquote>\n` +
    `<blockquote>⬇️ <b>ᴅᴏᴡɴʟᴏᴀᴅᴇʀ</b> <i>(Premium+)</i>\n` +
    `🎵 /dl [url] — TikTok ᴠɪᴅᴇᴏ / ᴀᴜᴅɪᴏ ᴍᴘ3\n` +
    `🐙 /dl [url] — GitHub ʀᴇᴘᴏ .zip</blockquote>\n` +
    `<blockquote>ᴄʀᴇᴀᴛᴇᴅ ʙʏ ${config.OWNER_NAME}</blockquote>`,
    { parse_mode: 'HTML' }
  );
});

// 📊 Stats
bot.hears('📊 Stats', async (ctx) => {
  const users = loadData(USERS_FILE).length;
  const groups = Object.keys(loadData(GROUPS_FILE)).length;
  const stats = loadStats();
  const today = new Date().toISOString().slice(0, 10);
  const todayData = stats.dailyStats[today] || { share: 0, success: 0, users: [] };
  const txt =
    `<blockquote>📊 <b>sᴛᴀᴛɪsᴛɪᴋ ʙᴏᴛ</b>\n\n` +
    `👥 ᴜsᴇʀs       : <b>${users}</b>\n` +
    `🏘️ ɢʀᴏᴜᴘs      : <b>${groups}</b>\n` +
    `📤 ᴛᴏᴛᴀʟ sʜᴀʀᴇ : <b>${stats.totalShare || 0}x</b>\n` +
    `✅ ᴛᴏᴛᴀʟ ʙᴇʀʜᴀsɪʟ: <b>${stats.totalShareSuccess || 0}</b>\n\n` +
    `<b>ʜᴀʀɪ ɪɴɪ:</b>\n` +
    `📤 sʜᴀʀᴇ: <b>${todayData.share}x</b> | ✅ ʙᴇʀʜᴀsɪʟ: <b>${todayData.success}</b>\n` +
    `👤 ᴜsᴇʀ ᴀᴋᴛɪꜰ  : <b>${todayData.users.length}</b>\n\n` +
    `⚡ sʏsᴛᴇᴍ: ᴏɴʟɪɴᴇ</blockquote>`;
  return ctx.reply(txt, { parse_mode: 'HTML' });
});

// 📋 Status
bot.hears('📋 Status', async (ctx) => {
  const userId = ctx.from.id;
  const token = getDailyToken(userId);
  const role = getRole(userId);

  let expiryLine = '';
  if (isAdmin(userId) && !isOwner(userId)) {
    const adminData = loadWithExpiry(ADMIN_FILE);
    const entry = adminData[userId];
    expiryLine = entry?.expiredAt
      ? `⏳ Admin s/d : <b>${formatExpiry(entry.expiredAt)}</b>\n`
      : entry ? `⏳ Admin s/d : <b>♾️ Permanen</b>\n` : '';
  } else if (isPremium(userId) && !isOwner(userId)) {
    const premData = loadWithExpiry(PREMIUM_FILE);
    const entry = premData[userId];
    expiryLine = entry?.expiredAt
      ? `⏳ Premium s/d: <b>${formatExpiry(entry.expiredAt)}</b>\n`
      : entry ? `⏳ Premium s/d: <b>♾️ Permanen</b>\n` : '';
  }

  const autoStatus = autoShareStatus.get(userId) || 'off';
  const autoInterval = getAutoShareInterval(userId);
  const nextRunTime = autoShareTime.get(userId);
  let autoLine = '';
  if (autoStatus === 'on') {
    const nextStr = nextRunTime
      ? new Date(nextRunTime).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' })
      : '-';
    autoLine = `\n🤖 <b>ᴀᴜᴛᴏ sʜᴀʀᴇ</b>\n• sᴛᴀᴛᴜs   : <b>🟢 ON</b>\n• ɪɴᴛᴇʀᴠᴀʟ : <b>${autoInterval/1000/60} ᴍᴇɴɪᴛ</b>\n• ɴᴇxᴛ ʀᴜɴ : <b>${nextStr} ᴡɪʙ</b>`;
  } else {
    autoLine = `\n<b>━❍ᴀᴜᴛᴏ sʜᴀʀᴇ</b>\n• 𝗦𝘁𝗮𝘁𝘂𝘀 : <b>🔴 OFF</b>`;
  }

  const txt =
    `<blockquote>( 🔍 ) 𝗗𝗲𝘁𝗮𝗶𝗹 𝗦𝘁𝗮𝘁𝘂𝘀</blockquote>\n` +
    `✰ 𝗜𝗗     : <code>${userId}</code>\n` +
    `✰ 𝗥𝗢𝗟𝗘   : <code>${role}</code>\n` +
    `${expiryLine}` +
    `✰ 𝗧𝗢𝗞𝗘𝗡  : <b>${isPremium(userId) ? 'Unlimited' : token}</b>` +
    `${autoLine}\n` +
    `<blockquote>ᴄʀᴇᴀᴛᴇᴅ ʙʏ ${config.OWNER_NAME}</blockquote>`;

  return ctx.reply(txt, { parse_mode: 'HTML' });
});

// === HEARS: Tombol-tombol Reply Keyboard Menu Share ===

// ⚙️ Auto ON (dari share keyboard)
bot.hears('⚙️ Auto ON', async (ctx) => {
  const userId = ctx.from.id;
  const role = getRole(userId);
  if (!canAutoShare(userId)) {
    const isGroupPrem = hasGroupPremium(userId);
    return ctx.reply(
      isGroupPrem
        ? `⛔ <b>AKSES DITOLAK!</b>\n\nPremium gratis (add grup) hanya bisa pakai:\n🖼️ Broadcast Image\n🎬 Broadcast Media\n\n💡 Beli premium untuk akses Auto Share & Broadcast Teks.`
        : `⛔ Fitur auto share khusus Premium/Admin/Owner!\nKetik /start dan beli premium.`,
      { parse_mode: 'HTML' }
    );
  }
  if (!isOwner(userId) && !isAdmin(userId) && !isPaidPremium(userId) && !hasGroupPremium(userId)) {
    const kicks = getKickCount(userId);
    if (kicks >= 3) {
      return ctx.reply(
        `⛔ <b>AKSES DITOLAK!</b>\n\nPremium gratis kamu dicabut karena bot dikeluarkan dari <b>${kicks} grup</b>.`,
        { parse_mode: 'HTML' }
      );
    }
  }
  if (!userMessages.has(userId)) {
    return ctx.reply('❌ <b>GAGAL!</b>\nAnda harus /setpesan dulu!', { parse_mode: 'HTML' });
  }
  const autoInterval = getAutoShareInterval(userId);
  const shareDelay = getDelayByRole(userId);
  autoShareMessageId.set(userId, userMessages.get(userId));
  autoShareStatus.set(userId, 'on');
  autoShareTime.set(userId, Date.now());
  const u = ctx.from;
  const displayName = u.username ? `@${u.username}` : `${[u.first_name, u.last_name].filter(Boolean).join(' ')}`;
  autoUserCache.set(userId, displayName);
  ctx.reply(
    `🚀 <b>AUTO SHARE AKTIF!</b>\n\n👤 Role: ${role}\n📤 Interval: ${autoInterval/1000/60} menit\n⏱️ Delay antar grup: ${shareDelay/1000} detik`,
    { parse_mode: 'HTML' }
  );
  enqueueShare(ctx, 'autoshare', 1, userMessages.get(userId));
});

// ⚙️ Auto OFF (dari share keyboard)
bot.hears('⚙️ Auto OFF', async (ctx) => {
  const userId = ctx.from.id;
  autoShareStatus.set(userId, 'off');
  autoShareTime.delete(userId);
  autoShareMessageId.delete(userId);
  ctx.reply('🛑 <b>AUTO SHARE DIMATIKAN!</b>', { parse_mode: 'HTML' });
});

// 📋 Status Auto
bot.hears('📋 Status Auto', async (ctx) => {
  const txt = await buildAutoStatusText(ctx.from.id);
  ctx.reply(txt, { parse_mode: 'HTML' });
});

// 📝 Set Pesan
// ============================================================
// === PENDING STATE MAP UNTUK BROADCAST & SET PESAN/DELAY ===
// ============================================================
// State: 'setpesan' | 'broadcast' | 'broadcast_image' | 'broadcast_media' | 'broadcast_users' | 'setdelay_select' | 'setdelay_input'
const userPendingAction = new Map(); // userId -> { action, extra? }

// Helper bersihkan state
const clearPending = (userId) => userPendingAction.delete(userId);

// ============================================================
// === SET PESAN (via button, bot minta pesan)
// ============================================================
bot.hears('📝 Set Pesan', async (ctx) => {
  const userId = ctx.from.id;
  userPendingAction.set(userId, { action: 'setpesan' });
  ctx.reply(
    `<blockquote>📝 <b>SET PESAN</b>\n\nForward atau kirim pesan yang ingin dijadikan target auto share.\n\n<i>Kirim sembarang pesan atau forward dari mana saja.</i></blockquote>`,
    { parse_mode: 'HTML' }
  );
});

// ============================================================
// === SET DELAY (khusus Owner — bisa set delay admin/premium/free)
// ============================================================
bot.hears('🕐 Set Delay', async (ctx) => {
  const userId = ctx.from.id;

  // Non-owner: hanya tampil info delay mereka
  if (!isOwner(userId)) {
    const role = getRole(userId);
    const shareDelay = getDelayByRole(userId);
    const autoInterval = getAutoShareInterval(userId);
    return ctx.reply(
      `<blockquote>🕐 <b>INFO DELAY KAMU</b>\n\n` +
      `👤 Role         : <b>${role}</b>\n` +
      `⏱️ Delay/grup   : <b>${shareDelay/1000} detik</b>\n` +
      `🔁 Auto interval: <b>${autoInterval/1000/60 || 0} menit</b>\n\n` +
      `<i>Delay ditentukan otomatis berdasarkan role kamu.</i></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  // Owner: tampilkan panel set delay
  const d = config.DELAY_ANTAR_GRUP;
  ctx.reply(
    `<blockquote>🕐 <b>SET DELAY — PANEL OWNER</b>\n\n` +
    `Delay saat ini:\n` +
    `👑 Owner  : <b>${(d.OWNER||2000)/1000} detik</b>\n` +
    `🛠️ Admin  : <b>${(d.ADMIN||3000)/1000} detik</b>\n` +
    `💎 Premium: <b>${(d.PREMIUM||4500)/1000} detik</b>\n` +
    `👥 Grup   : <b>${(d.GROUP_PREMIUM||5000)/1000} detik</b>\n` +
    `🆓 Free   : <b>${(d.FREE||10000)/1000} detik</b>\n\n` +
    `Pilih role yang ingin diubah:</blockquote>`,
    {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🛠️ Set Delay Admin', 'sd_ADMIN')],
        [Markup.button.callback('💎 Set Delay Premium', 'sd_PREMIUM')],
        [Markup.button.callback('👥 Set Delay Grup Premium', 'sd_GROUP_PREMIUM')],
        [Markup.button.callback('🆓 Set Delay Free', 'sd_FREE')],
        [Markup.button.callback('❌ Batal', 'sd_cancel')],
      ])
    }
  );
});

bot.action('sd_cancel', async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  clearPending(ctx.from.id);
  ctx.editMessageText('❌ Set delay dibatalkan.').catch(() => {});
});

bot.action(/^sd_(ADMIN|PREMIUM|GROUP_PREMIUM|FREE)$/, async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('⛔ Khusus Owner!', { show_alert: true });
  ctx.answerCbQuery().catch(() => {});
  const role = ctx.match[1];
  const label = role === 'ADMIN' ? '🛠️ Admin' : role === 'PREMIUM' ? '💎 Premium' : role === 'GROUP_PREMIUM' ? '👥 Grup Premium' : '🆓 Free';
  userPendingAction.set(ctx.from.id, { action: 'setdelay_input', role });
  ctx.editMessageText(
    `<blockquote>🕐 <b>SET DELAY ${label}</b>\n\nKirim angka delay dalam <b>detik</b>.\nContoh: <code>5</code> (= 5 detik antar grup)\n\n<i>Min: 1 detik | Max: 120 detik</i></blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});
});

// ============================================================
// === BROADCAST TEKS (semua role yang punya akses share)
// ============================================================
bot.hears('📢 Broadcast', async (ctx) => {
  const userId = ctx.from.id;
  const role = getRole(userId);
  if (!canAutoShare(userId)) {
    const isGroupPrem = hasGroupPremium(userId);
    return ctx.reply(
      isGroupPrem
        ? `⛔ <b>AKSES DITOLAK!</b>\n\nPremium gratis (add grup) hanya bisa pakai:\n🖼️ Broadcast Image\n🎬 Broadcast Media\n\n💡 Beli premium untuk akses Broadcast Teks & Auto Share.`
        : `⛔ <b>Akses ditolak!</b>\n\nTambahkan bot ke minimal 3 grup untuk akses gratis.\nAtau beli premium melalui /start → Buy Akses.`,
      { parse_mode: 'HTML' }
    );
  }
  userPendingAction.set(userId, { action: 'broadcast' });
  ctx.reply(
    `<blockquote>📢 <b>BROADCAST TEKS</b>\n\nKirim atau forward pesan teks yang ingin di-broadcast ke semua grup.\n\n<i>Pesan akan dikirim ke semua grup yang terdaftar.</i></blockquote>`,
    { parse_mode: 'HTML' }
  );
});

// ============================================================
// === BROADCAST IMAGE (semua role kecuali FREE, forward)
// ============================================================
bot.hears('🖼️ Broadcast Image', async (ctx) => {
  const userId = ctx.from.id;
  const role = getRole(userId);
  if (role === 'FREE') {
    return ctx.reply('⛔ <b>Akses ditolak!</b>\n\nTambahkan bot ke minimal 3 grup untuk akses gratis.\nAtau beli premium melalui /start → Buy Akses.', { parse_mode: 'HTML' });
  }
  userPendingAction.set(userId, { action: 'broadcast_image' });
  ctx.reply(
    `<blockquote>🖼️ <b>BROADCAST IMAGE</b>\n\nKirim <b>foto</b> yang ingin di-broadcast ke semua grup.\n\n<i>Foto akan diteruskan (forward) ke semua grup.</i></blockquote>`,
    { parse_mode: 'HTML' }
  );
});

// ============================================================
// === BROADCAST MEDIA (semua role kecuali FREE, forward)
// ============================================================
bot.hears('🎬 Broadcast Media', async (ctx) => {
  const userId = ctx.from.id;
  const role = getRole(userId);
  if (role === 'FREE') {
    return ctx.reply('⛔ <b>Akses ditolak!</b>\n\nTambahkan bot ke minimal 3 grup untuk akses gratis.\nAtau beli premium melalui /start → Buy Akses.', { parse_mode: 'HTML' });
  }
  userPendingAction.set(userId, { action: 'broadcast_media' });
  ctx.reply(
    `<blockquote>🎬 <b>BROADCAST MEDIA</b>\n\nKirim <b>video atau dokumen</b> yang ingin di-broadcast ke semua grup.\n\n<i>Media akan diteruskan (forward) ke semua grup.</i></blockquote>`,
    { parse_mode: 'HTML' }
  );
});

// ============================================================
// === BROADCAST USERS (khusus premium berbayar/admin/owner)
// ============================================================
bot.hears('👤 Broadcast Users', async (ctx) => {
  const userId = ctx.from.id;
  if (!isPaidPremium(userId)) {
    return ctx.reply('⛔ <b>Akses ditolak!</b>\n\nFitur ini hanya untuk Premium berbayar, Admin, dan Owner.', { parse_mode: 'HTML' });
  }
  userPendingAction.set(userId, { action: 'broadcast_users' });
  ctx.reply(
    `<blockquote>👤 <b>BROADCAST USERS</b>\n\nKirim atau forward pesan yang ingin di-broadcast ke semua user bot.\n\n<i>Pesan akan dikirim ke semua user terdaftar.</i></blockquote>`,
    { parse_mode: 'HTML' }
  );
});

// 🔙 Main Menu (dari share keyboard kembali ke menu utama)
bot.hears('🔙 Main Menu', async (ctx) => {
  await ctx.reply('🏠 Kembali ke Menu Utama', { ...getMainKeyboard() });
});

// === PANEL OWNER ===
bot.action('panel_owner', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('⛔ ʟᴜ sɪᴀᴘᴇ ᴍᴘʀᴜʏ?', { show_alert: true });

  await safeEdit(ctx, 
    `<blockquote>( 👑 ) — 𝗖𝗠𝗗 𝗢𝗪𝗡𝗘𝗥—</blockquote>\n` +
    `<blockquote><b>👥 ᴍᴀɴᴀᴊᴇᴍᴇɴ ᴀᴋsᴇs:</b>\n` +
    `• /addadmin [id] [waktu]\n` +
    `• /deladmin [id]\n` +
    `• /addprem [id] [waktu]\n` +
    `• /delprem [id]\n` +
    `• /listadmin — /listprem</blockquote>\n` +
    `<blockquote><b>⚙️ ʙᴏᴛ:</b>\n` +
    `• /mtc — ᴛᴏɢɢʟᴇ ᴍᴀɪɴᴛᴇɴᴀɴᴄᴇ\n` +
    `• /bcbot — ʙʀᴏᴀᴅᴄᴀsᴛ\n` +
    `• /backup — ʙᴀᴄᴋᴜᴘ ᴅᴀᴛᴀ\n` +
    `• /restore — ʀᴇsᴛᴏʀᴇ ᴅᴀᴛᴀ\n` +
    `• /cekdata — sᴛᴀᴛɪsᴛɪᴋ ᴅᴀᴛᴀ\n` +
    `• /up — ᴜʙᴀʜ ᴘᴀʏᴍᴇɴᴛ ǫʀɪs\n` +
    `<i>Note! saat bot di restart, payment akan kembali ke Qris otomatis</i></blockquote>\n` +
    `<blockquote><b>🎉 ᴡᴇʟᴄᴏᴍᴇ & ᴛᴀɢ:</b>\n` +
    `• /setwelcome — /setautotag</blockquote>\n` +
    `<blockquote><b>ꜰᴏʀᴍᴀᴛ ᴡᴀᴋᴛᴜ:</b> <code>7d</code>=7hari <code>1m</code>=1bulan <code>p</code>=permanen</blockquote>\n` +
    `<blockquote>ᴄʀᴇᴀᴛᴇᴅ ʙʏ ${config.OWNER_NAME}</blockquote>`,
    {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🛠️ CMD Admin', 'panel_admin')],
        [Markup.button.callback('🔙 Kembali', 'menu_owner')]
      ])
    }
  );
});

// === PANEL ADMIN ===
bot.action('panel_admin', (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.answerCbQuery('⛔ ᴋʜᴜsᴜs ᴀᴅᴍɪɴ ᴘʀᴜʏ!', { show_alert: true });

  safeEdit(ctx, 
    `<blockquote>( 💻 ) —𝗖𝗠𝗗 𝗔𝗗𝗠𝗜𝗡—</blockquote>\n` +
    `<blockquote><b>💎 ᴍᴀɴᴀᴊᴇᴍᴇɴ ᴘʀᴇᴍɪᴜᴍ:</b>\n` +
    `• /addprem [id] [waktu]\n` +
    `• /delprem [id]\n` +
    `• /listprem\n\n` +
    `<b>📢 ʙʀᴏᴀᴅᴄᴀsᴛ:</b>\n` +
    `• /bcbot\n\n` +
    `<b>📤 sʜᴀʀᴇ:</b>\n` +
    `• /share — /sharevip\n` +
    `• /stats</blockquote>\n` +
    `<blockquote>ᴄʀᴇᴀᴛᴇᴅ ʙʏ ${config.OWNER_NAME}</blockquote>`,
    {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        isOwner(ctx.from.id) ? [Markup.button.callback('👑 CMD Owner', 'panel_owner')] : [],
        [Markup.button.callback('🔙 Kembali', 'menu_owner')]
      ].filter(row => row.length > 0))
    }
  );
});

// === PILIH DURASI ===
bot.action(/^buy_(PREM|ADM)$/, (ctx) => {
  const type = ctx.match[1];
  const prices = PRICE_LIST[type];
  const typeLabel = type === 'PREM' ? '💎 PREMIUM' : '🛠️ ADMIN';

  safeEdit(ctx, 
    `<blockquote>${typeLabel} — <b>ᴘɪʟɪʜ ᴅᴜʀᴀsɪ</b>\n\n` +
    Object.entries(prices).map(([k, v]) =>
      `• ${v.label.padEnd(10)}: <b>Rp${v.price.toLocaleString('id-ID')}</b>`
    ).join('\n') + `</blockquote>`,
    {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('1 ᴍɪɴɢɢᴜ', `dur_${type}_1w`), Markup.button.callback('1 ʙᴜʟᴀɴ', `dur_${type}_1m`)],
        [Markup.button.callback('3 ʙᴜʟᴀɴ', `dur_${type}_3m`), Markup.button.callback('1 ᴛᴀʜᴜɴ', `dur_${type}_1y`)],
        [Markup.button.callback('🔙 Kembali', 'menu_buy')]
      ])
    }
  );
});

// === PILIH METODE BAYAR ===
bot.action(/^dur_(PREM|ADM)_(1w|1m|3m|1y)$/, async (ctx) => {
  const type = ctx.match[1];
  const dur = ctx.match[2];
  const info = PRICE_LIST[type][dur];
  const typeLabel = type === 'PREM' ? '💎 PREMIUM' : '🛠️ ADMIN';

  ctx.answerCbQuery().catch(() => {});

  // Langsung trigger sesuai mode QRIS aktif
  if (qrisMode === 'auto' && config.PAKASIR_API_KEY && config.PAKASIR_PROJECT) {
    // Simulasi klik pay_auto
    ctx.match = [null, type, dur];
    return handlePayAuto(ctx);
  } else {
    // Mode manual
    ctx.match = [null, type, dur, 'manual'];
    return handlePayManual(ctx);
  }
});

bot.action('coming_soon', async (ctx) => {
  await ctx.answerCbQuery('🔧 Fitur ini segera hadir!', { show_alert: true });
});

// === FUNGSI HANDLER PEMBAYARAN ===
const handlePayAuto = async (ctx) => {
  const type = ctx.match[1];
  const dur = ctx.match[2];
  const info = PRICE_LIST[type][dur];
  const typeLabel = type === 'PREM' ? '💎 PREMIUM' : '🛠️ ADMIN';
  const userId = ctx.from.id;

  await ctx.deleteMessage().catch(() => {});
  const loadingMsg = await ctx.reply('⏳ Membuat QRIS, mohon tunggu...');

  try {
    const orderId = generateOrderId(userId);
    const invoiceData = await createPakasirInvoice(orderId, info.price);

    const payment = invoiceData?.payment;
    const qrString = payment?.payment_number;
    const expiredAt = payment?.expired_at
      ? new Date(payment.expired_at).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' })
      : '30 menit';

    if (!qrString) {
      await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
      return ctx.reply(
        `❌ <b>Gagal membuat QRIS</b>\n\nSilakan hubungi owner.`,
        { parse_mode: 'HTML', ...Markup.inlineKeyboard([[Markup.button.callback('🔙 Kembali', 'menu_buy')]]) }
      );
    }

    pendingTransactions.set(orderId, { userId, type, dur, amount: info.price, label: info.label, createdAt: Date.now() });
    const qrImageUrl = generateQRUrl(qrString);
    await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});

    await ctx.replyWithPhoto(qrImageUrl, {
      caption:
        `<blockquote>⚡ <b>QRIS OTOMATIS</b></blockquote>\n\n` +
        `📦 Paket  : <b>${typeLabel} — ${info.label}</b>\n` +
        `💰 Total  : <b>Rp${payment?.total_payment?.toLocaleString('id-ID') || info.price.toLocaleString('id-ID')}</b>\n` +
        `🔖 Order  : <code>${orderId}</code>\n\n` +
        `Scan QR di atas lalu klik <b>Cek Pembayaran</b> setelah bayar.\n` +
        `⏳ Berlaku hingga: <b>${expiredAt} WIB</b>\n\n` +
        `<blockquote>ᴄʀᴇᴀᴛᴇᴅ ʙʏ ${config.OWNER_NAME}</blockquote>`,
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('🔍 Cek Pembayaran', `cekbayar_${orderId}`)],
        [Markup.button.callback('❌ Batal', `cancelbayar_${orderId}`)]
      ])
    });
  } catch (err) {
    console.error('Pakasir error:', err.message);
    await ctx.telegram.deleteMessage(ctx.chat.id, loadingMsg.message_id).catch(() => {});
    ctx.reply(
      `❌ <b>Gagal terhubung ke server pembayaran</b>\n\nCoba lagi nanti.`,
      { parse_mode: 'HTML', ...Markup.inlineKeyboard([[Markup.button.callback('🔙 Kembali', 'menu_buy')]]) }
    );
  }
};

const handlePayManual = async (ctx) => {
  const type = ctx.match[1];
  const dur = ctx.match[2];
  const info = PRICE_LIST[type][dur];
  const typeLabel = type === 'PREM' ? '💎 PREMIUM' : '🛠️ ADMIN';

  waitingForProof.set(ctx.from.id, { type, dur, method: 'manual', price: info.price, label: info.label });

  await ctx.deleteMessage().catch(() => {});
  await ctx.replyWithPhoto(config.QRIS_MANUAL, {
    caption:
      `<blockquote>🖼️ <b>QRIS MANUAL</b>\n\n` +
      `⚠️ <i>QRIS otomatis sedang bermasalah, gunakan QRIS manual ini.</i>\n\n` +
      `📦 Paket  : <b>${typeLabel} — ${info.label}</b>\n` +
      `💰 Total  : <b>Rp${info.price.toLocaleString('id-ID')}</b>\n\n` +
      `Scan QR di atas lalu kirim <b>screenshot bukti pembayaran</b>.</blockquote>\n\n` +
     `<blockquote>ᴄʀᴇᴀᴛᴇᴅ ʙʏ ${config.OWNER_NAME}</blockquote>`,
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard([[Markup.button.callback('❌ BATAL', 'back_start')]])
  });
};

// === PROSES PEMBAYARAN AUTO (PAKASIR QRIS) ===
bot.action(/^pay_(PREM|ADM)_(1w|1m|3m|1y)_auto$/, async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  return handlePayAuto(ctx);
});

// === CEK STATUS PEMBAYARAN (Manual Check) ===
bot.action(/^cekbayar_(.+)$/, async (ctx) => {
  const orderId = ctx.match[1];
  const txData = pendingTransactions.get(orderId);

  if (!txData) {
    return ctx.answerCbQuery('❌ Transaksi tidak ditemukan atau sudah kedaluwarsa.', { show_alert: true });
  }

  if (txData.userId !== ctx.from.id) {
    return ctx.answerCbQuery('❌ Bukan transaksi kamu!', { show_alert: true });
  }

  await ctx.answerCbQuery('🔍 Mengecek status pembayaran...');

  try {
    const status = await checkPakasirStatus(orderId, txData.amount);

    const isPaid = status?.status === 'completed' || status?.payment?.status === 'completed';

    if (isPaid) {
      // Aktifkan akses otomatis
      const file = txData.type === 'PREM' ? PREMIUM_FILE : ADMIN_FILE;
      const typeLabel = txData.type === 'PREM' ? 'PREMIUM' : 'ADMIN';
      const info = PRICE_LIST[txData.type][txData.dur];

      const expiredAt = parseExpiry(info.expiry);
      const data = loadWithExpiry(file);
      data[txData.userId] = { expiredAt, addedAt: Date.now(), addedBy: 'auto_payment' };
      saveWithExpiry(file, data);

      pendingTransactions.delete(orderId);

      // Edit pesan QRIS jadi konfirmasi sukses
      await safeEdit(ctx, 
        `<blockquote>🎉 <b>Pembayaran Berhasil!</b>\n\n` +
        `✅ Akses <b>${typeLabel}</b> kamu sekarang aktif!\n` +
        `📦 Paket  : <b>${info.label}</b>\n` +
        `⏳ Berlaku: <b>${formatExpiry(expiredAt)}</b>\n\n` +
        `Ketik /start untuk mulai menggunakan bot.</blockquote>`,
        { parse_mode: 'HTML' }
      ).catch(() => {});

      // Notif ke owner & channel
      const notifText =
        `<blockquote>💰 <b>PEMBAYARAN MASUK</b>\n\n` +
        `👤 User  : <code>${txData.userId}</code>\n` +
        `📦 Paket : <b>${typeLabel} — ${info.label}</b>\n` +
        `💵 Harga : <b>Rp${txData.amount.toLocaleString('id-ID')}</b>\n` +
        `🔖 Order : <code>${orderId}</code>\n` +
        `⚡ Metode: <b>QRIS Otomatis</b></blockquote>`;

      await bot.telegram.sendMessage(config.OWNER_ID, notifText, { parse_mode: 'HTML' }).catch(() => {});
      notifCh.notifPayment(bot, config, txData.userId, typeLabel, info.label, txData.amount, 'QRIS Otomatis');

    } else {
      const statusText = status?.status || status?.payment?.status || 'pending';
      await ctx.reply(
        `<blockquote>⏳ <b>Pembayaran Belum Diterima</b>\n\nStatus: <b>${statusText}</b>\n\nSelesaikan pembayaran lalu klik tombol di bawah untuk cek ulang.</blockquote>`,
        { parse_mode: 'HTML', ...Markup.inlineKeyboard([
          [Markup.button.callback('🔍 Cek Lagi', `cekbayar_${orderId}`)],
          [Markup.button.callback('❌ Batal', `cancelbayar_${orderId}`)]
        ])}
      );
    }
  } catch (err) {
    console.error('Cek status error:', err.message);
    await ctx.answerCbQuery('❌ Gagal cek status. Coba lagi.', { show_alert: true });
  }
});

// === BATAL TRANSAKSI ===
bot.action(/^cancelbayar_(.+)$/, async (ctx) => {
  const orderId = ctx.match[1];
  const txData = pendingTransactions.get(orderId);

  if (txData?.userId !== ctx.from.id) {
    return ctx.answerCbQuery('❌ Bukan transaksi kamu!', { show_alert: true });
  }

  // Cancel di Pakasir
  try {
    await axios.post('https://app.pakasir.com/api/transactioncancel', {
      project:  config.PAKASIR_PROJECT,
      order_id: orderId,
      amount:   txData.amount,
      api_key:  config.PAKASIR_API_KEY
    }, { timeout: 10000 });
  } catch (e) {
    console.log('Cancel pakasir error (ignored):', e.message);
  }

  pendingTransactions.delete(orderId);
  await ctx.answerCbQuery('✅ Transaksi dibatalkan.');
  await ctx.editMessageCaption('❌ <b>Transaksi dibatalkan.</b>', { parse_mode: 'HTML' }).catch(() => {});
  setTimeout(() => ctx.deleteMessage().catch(() => {}), 3000);
});

// === PROSES PEMBAYARAN MANUAL (QRIS/E-WALLET) ===
// === PROSES PEMBAYARAN MANUAL ===
bot.action(/^pay_(PREM|ADM)_(1w|1m|3m|1y)_manual$/, async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  return handlePayManual(ctx);
});

// ============================================================
// === HANDLER PENDING ACTION: SET PESAN, BROADCAST, SET DELAY
// ============================================================

// Helper: jalankan broadcast grup pakai copyMessage atau forwardMessage
const runShareGroups = async (ctx, fromChatId, msgId, useForward = false) => {
  const userId = ctx.from.id;
  const role = getRole(userId);
  const groupsData = loadData(GROUPS_FILE);
  const groupIds = Object.keys(groupsData);
  if (groupIds.length === 0) return ctx.reply('❌ Belum ada grup terdaftar.');

  const shareDelay = getDelayByRole(userId);
  const total = groupIds.length;

  const progressMsg = await ctx.reply(
    `<blockquote>📤 <b>BROADCAST DIMULAI</b>\n\n` +
    `👤 Role    : <b>${role}</b>\n` +
    `📦 Target  : <b>${total} grup</b>\n` +
    `⏱️ Delay   : <b>${shareDelay/1000} detik</b>/grup\n\n` +
    `⏳ Memulai pengiriman...</blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => null);

  let success = 0, failed = 0;
  const startTime = Date.now();

  for (const gid of groupIds) {
    // Skip hanya blacklist manual (permanent), bukan auto-blacklist 3x fail
    if (loadBlacklist()[gid]?.permanent) continue;
    try {
      if (useForward) {
        // Broadcast image/media: forward (tampil "Forwarded from")
        await ctx.telegram.forwardMessage(gid, fromChatId, msgId);
      } else {
        // Broadcast teks: selalu copyMessage (tidak tampak forward dari siapapun)
        await ctx.telegram.copyMessage(gid, fromChatId, msgId);
      }
      success++;
    } catch (e) {
      failed++;
      recordGroupFail(gid, e.description);
    }

    if (progressMsg && (success + failed) % 5 === 0) {
      const pct = Math.floor(((success + failed) / total) * 100);
      const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
      await ctx.telegram.editMessageText(
        ctx.chat.id, progressMsg.message_id, null,
        `<blockquote>📤 <b>BROADCAST BERJALAN</b>\n\n` +
        `👤 Role    : <b>${role}</b>\n` +
        `📊 Progress: [${bar}] ${pct}%\n` +
        `✅ Berhasil: <b>${success}</b>  ❌ Gagal: <b>${failed}</b>\n` +
        `📦 Terkirim: <b>${success + failed}/${total}</b></blockquote>`,
        { parse_mode: 'HTML' }
      ).catch(() => {});
    }
    await new Promise(r => setTimeout(r, shareDelay));
  }

  const totalTime = Math.floor((Date.now() - startTime) / 1000);
  recordShareStats(userId, success, failed);

  if (progressMsg) {
    await ctx.telegram.editMessageText(
      ctx.chat.id, progressMsg.message_id, null,
      `<blockquote>✅ <b>BROADCAST SELESAI</b>\n\n` +
      `👤 Role    : <b>${role}</b>\n` +
      `✅ Berhasil: <b>${success}</b>  ❌ Gagal: <b>${failed}</b>\n` +
      `📦 Total   : <b>${total} grup</b>\n` +
      `⏱️ Durasi  : <b>${Math.floor(totalTime/60)}m ${totalTime%60}s</b></blockquote>`,
      { parse_mode: 'HTML' }
    ).catch(() => {});
  }
};

// Helper: jalankan broadcast ke semua USER (bcbot)
const runBroadcastUsers = async (ctx, fromChatId, msgId) => {
  const userId = ctx.from.id;
  const users = loadData(USERS_FILE);
  if (users.length === 0) return ctx.reply('❌ Belum ada user terdaftar.');

  if (bcbotQueue.some(e => e.userId === userId) || bcbotCurrentEntry?.userId === userId) {
    return ctx.reply('⏳ Kamu sudah ada di antrian broadcast. Tunggu giliranmu.');
  }

  const username = ctx.from.username || null;
  const power = getBcbotRolePower(userId);
  const broadcastChatId = fromChatId;
  const broadcastMsgId = msgId;

  bcbotQueue.push({ userId, ctx, broadcastMsgId, broadcastChatId, username, power });
  bcbotQueue.sort((a, b) => b.power - a.power);

  if (bcbotRunning) {
    const queueText = buildQueueStatusText(userId);
    const queueMsg = await ctx.reply(queueText, { parse_mode: 'HTML' }).catch(() => null);
    if (queueMsg) {
      bcbotQueueMsgIds.set(userId, { chatId: ctx.chat.id, msgId: queueMsg.message_id });
    }
    await updateAllQueueMessages();
  } else {
    runNextBcbot();
  }
};

// === HANDLER: TEXT (pending actions + existing handler) ===
bot.on('text', async (ctx, next) => {
  const userId = ctx.from.id;
  const pending = userPendingAction.get(userId);

  // ── SETDELAY INPUT (owner ketik angka detik) ──
  if (pending?.action === 'setdelay_input') {
    const text = ctx.message.text.trim();
    if (text.startsWith('/')) { clearPending(userId); return next(); }
    const secs = parseInt(text);
    if (isNaN(secs) || secs < 1 || secs > 120) {
      return ctx.reply('⚠️ Masukkan angka antara <b>1 – 120</b> detik.', { parse_mode: 'HTML' });
    }
    config.DELAY_ANTAR_GRUP[pending.role] = secs * 1000;
    clearPending(userId);
    const label = pending.role === 'ADMIN' ? '🛠️ Admin' : pending.role === 'PREMIUM' ? '💎 Premium' : pending.role === 'GROUP_PREMIUM' ? '👥 Grup Premium' : '🆓 Free';
    return ctx.reply(`✅ <b>Delay ${label} berhasil diubah menjadi ${secs} detik!</b>`, { parse_mode: 'HTML' });
  }

  // ── SETPESAN ──
  if (pending?.action === 'setpesan') {
    if (ctx.message.text.startsWith('/')) { clearPending(userId); return next(); }
    // Simpan message id dari pesan ini (bisa forward atau teks biasa)
    userMessages.set(userId, ctx.message.message_id);
    clearPending(userId);
    return ctx.reply('✅ <b>SET PESAN BERHASIL!</b>\nSekarang bisa gunakan auto on.', { parse_mode: 'HTML' });
  }

  // ── BROADCAST TEKS ──
  if (pending?.action === 'broadcast') {
    if (ctx.message.text.startsWith('/')) { clearPending(userId); return next(); }
    clearPending(userId);
    return runShareGroups(ctx, ctx.chat.id, ctx.message.message_id, false);
  }

  // ── BROADCAST USERS (teks) ──
  if (pending?.action === 'broadcast_users') {
    if (ctx.message.text.startsWith('/')) { clearPending(userId); return next(); }
    clearPending(userId);
    return runBroadcastUsers(ctx, ctx.chat.id, ctx.message.message_id);
  }

  // ── Lanjut ke handler text yang sudah ada ──
  return next();
});

// === HANDLER: PHOTO (pending broadcast_image / welcome setup / dll) ===
bot.on('photo', async (ctx) => {
    const userId = ctx.from.id;
    const pending = userPendingAction.get(userId);

    // ── BROADCAST IMAGE ──
    if (pending?.action === 'broadcast_image') {
      clearPending(userId);
      return runShareGroups(ctx, ctx.chat.id, ctx.message.message_id, true);
    }

    // ── SETPESAN via foto ──
    if (pending?.action === 'setpesan') {
      userMessages.set(userId, ctx.message.message_id);
      clearPending(userId);
      return ctx.reply('✅ <b>SET PESAN BERHASIL!</b>\nSekarang bisa gunakan auto on.', { parse_mode: 'HTML' });
    }

    // Handle welcome photo setup
    if (isOwner(ctx.from.id) && welcomeSetupState.get(ctx.from.id) === 'awaiting_photo') {
      const photoId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
      const welcome = loadWelcome();
      welcome.photo = photoId;
      saveWelcome(welcome);
      welcomeSetupState.delete(ctx.from.id);
      return ctx.reply('✅ <b>Foto welcome berhasil disimpan!</b>', { parse_mode: 'HTML' });
    }

    if (waitingForProof.has(ctx.from.id)) {
        const data = waitingForProof.get(ctx.from.id);
        const photoId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
        const typeLabel = data.type === 'PREM' ? '💎 PREMIUM' : '🛠️ ADMIN';

        await bot.telegram.sendPhoto(config.OWNER_ID, photoId, {
            caption:
              `<blockquote>🔔 <b>𝗕𝗨𝗞𝗧𝗜 𝗣𝗘𝗠𝗕𝗔𝗬𝗔𝗥𝗔𝗡</b></blockquote>\n\n` +
              `👤 User  : <code>${ctx.from.id}</code>\n` +
              `📦 Paket : <b>${typeLabel} — ${data.label}</b>\n` +
              `💰 Harga : <b>Rp${data.price.toLocaleString('id-ID')}</b>\n` +
              `<blockquote>ᴄʀᴇᴀᴛᴇᴅ ʙʏ ${config.OWNER_NAME}</blockquote>`,
            parse_mode: 'HTML',
            ...Markup.inlineKeyboard([
              [Markup.button.callback('✅ APPROVE', `acc_${data.type}_${ctx.from.id}_${data.dur}`)],
              [Markup.button.callback('❌ REJECT', `rej_${ctx.from.id}`)]
            ])
        });

        await ctx.reply('✅ Bukti terkirim! Menunggu konfirmasi owner.');
        waitingForProof.delete(ctx.from.id);
    }

});

// === HANDLER: VIDEO & DOCUMENT (broadcast_media / setpesan) ===
const handleMediaPending = async (ctx) => {
  const userId = ctx.from.id;
  const pending = userPendingAction.get(userId);

  if (pending?.action === 'broadcast_media') {
    clearPending(userId);
    return runShareGroups(ctx, ctx.chat.id, ctx.message.message_id, true);
  }

  if (pending?.action === 'setpesan') {
    userMessages.set(userId, ctx.message.message_id);
    clearPending(userId);
    return ctx.reply('✅ <b>SET PESAN BERHASIL!</b>\nSekarang bisa gunakan auto on.', { parse_mode: 'HTML' });
  }

  if (pending?.action === 'broadcast_users') {
    clearPending(userId);
    return runBroadcastUsers(ctx, ctx.chat.id, ctx.message.message_id);
  }
};

bot.on('video', async (ctx) => { await handleMediaPending(ctx); });
bot.on('document', async (ctx) => { await handleMediaPending(ctx); });

// === APPROVE / REJECT ===
bot.action(/^acc_(PREM|ADM)_(\d+)_(1w|1m|3m|1y)$/, async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });

  const type = ctx.match[1];
  const userId = parseInt(ctx.match[2]);
  const dur = ctx.match[3];
  const info = PRICE_LIST[type][dur];
  const file = type === 'PREM' ? PREMIUM_FILE : ADMIN_FILE;
  const typeLabel = type === 'PREM' ? 'PREMIUM' : 'ADMIN';

  const expiredAt = parseExpiry(info.expiry);
  const data = loadWithExpiry(file);
  data[userId] = { expiredAt, addedAt: Date.now(), addedBy: ctx.from.id };
  saveWithExpiry(file, data);

  await bot.telegram.sendMessage(userId,
    `<blockquote>🎉 <b>Pembayaran Dikonfirmasi!</b>\n\n` +
    `✅ Akses <b>${typeLabel}</b> kamu sekarang aktif!\n` +
    `📦 Paket  : <b>${info.label}</b>\n` +
    `⏳ Berlaku: <b>${formatExpiry(expiredAt)}</b></blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});

  // Notif ke channel
  const channelNotif =
    `<blockquote>💰 <b>PEMBAYARAN MASUK</b>\n\n` +
    `👤 User  : <code>${userId}</code>\n` +
    `📦 Paket : <b>${typeLabel} — ${info.label}</b>\n` +
    `💵 Harga : <b>Rp${info.price.toLocaleString('id-ID')}</b>\n` +
    `⚙️ Metode: <b>Manual (dikonfirmasi owner)</b></blockquote>`;
  notifCh.notifPayment(bot, config, userId, typeLabel, info.label, info.price, 'Manual');

  const approvedText = `✅ <b>Approved</b> — ${typeLabel} ${info.label} untuk <code>${userId}</code>`;
  await safeEdit(ctx, approvedText, { parse_mode: 'HTML' })
    .catch(() => ctx.editMessageText(approvedText, { parse_mode: 'HTML' })
    .catch(() => ctx.reply(approvedText, { parse_mode: 'HTML' })));
});

bot.action(/^rej_(\d+)$/, async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  const userId = parseInt(ctx.match[1]);
  bot.telegram.sendMessage(userId,
    `<blockquote>❌ <b>Pembayaran Ditolak</b>\n\nMaaf, bukti pembayaran kamu ditolak.\nSilakan hubungi owner untuk info lebih lanjut.</blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});
  await safeEdit(ctx, '❌ Rejected.')
    .catch(() => ctx.editMessageText('❌ Rejected.')
    .catch(() => ctx.reply('❌ Rejected.')));
});

// Approve script manual — kirim file ke user

bot.action('back_start', (ctx) => sendStartMenu(ctx));

bot.action('menu_owner', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('⛔ Hanya owner!', { show_alert: true });
  return sendStartMenu(ctx);
});


// === COMMAND: CEK EXPIRED ===
bot.command('cek', async (ctx) => {
  const userId = ctx.from.id;
  const now    = Date.now();

  const adminData = loadWithExpiry(ADMIN_FILE);
  const premData  = loadWithExpiry(PREMIUM_FILE);

  const adminEntry = adminData[userId];
  const premEntry  = premData[userId];

  if (isOwner(userId)) {
    return ctx.reply(
      `<blockquote>👑 <b>STATUS AKSES</b>\n\nKamu adalah <b>Owner</b>.\n♾️ Akses permanen.</blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  if (!adminEntry && !premEntry) {
    return ctx.reply(
      `<blockquote>👤 <b>STATUS AKSES</b>\n\nKamu belum punya akses premium/admin.\n\nBeli akses di menu <b>Buy Akses</b>.</blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  let msg = `<blockquote>📋 <b>STATUS AKSES</b>\n\n`;

  if (adminEntry && !isExpired(adminEntry.expiredAt)) {
    const sisa = adminEntry.expiredAt
      ? Math.ceil((adminEntry.expiredAt - now) / 86400000)
      : null;
    msg += `⚙️ <b>Admin</b>\n`;
    msg += `└ Expired : <b>${formatExpiry(adminEntry.expiredAt)}</b>\n`;
    if (sisa !== null) msg += `└ Sisa    : <b>${sisa} hari</b>\n`;
    msg += `\n`;
  }

  if (premEntry && !isExpired(premEntry.expiredAt)) {
    const sisa = premEntry.expiredAt
      ? Math.ceil((premEntry.expiredAt - now) / 86400000)
      : null;
    msg += `💎 <b>Premium</b>\n`;
    msg += `└ Expired : <b>${formatExpiry(premEntry.expiredAt)}</b>\n`;
    if (sisa !== null) msg += `└ Sisa    : <b>${sisa} hari</b>\n`;
  }

  msg += `</blockquote>`;
  ctx.reply(msg, { parse_mode: 'HTML' });
});

// === COMMAND: BLACKLIST GRUP (OWNER/ADMIN) ===
bot.command('blacklist', async (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('⛔ Khusus Admin/Owner.');
  const args = ctx.message.text.split(' ');
  const sub  = args[1]?.toLowerCase();
  const gid  = args[2];

  if (!sub) {
    const bl      = loadBlacklist();
    const entries = Object.entries(bl).filter(([, v]) => v.fails >= 3 || v.permanent);
    if (!entries.length) return ctx.reply('<blockquote>✅ Tidak ada grup di blacklist.</blockquote>', { parse_mode: 'HTML' });

    const txt = entries.slice(0, 20).map(([id, v], i) =>
      `${i+1}. <code>${id}</code> — ${v.permanent ? '🔒 Manual' : `⚡ Auto (${v.fails}x gagal)`}`
    ).join('\n');

    return ctx.reply(
      `<blockquote>🚫 <b>BLACKLIST GRUP (${entries.length})</b>

${txt}

` +
      `<code>/blacklist add [id]</code> — tambah manual
` +
      `<code>/blacklist del [id]</code> — hapus dari blacklist
` +
      `<code>/blacklist reset</code> — hapus semua</blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  const bl = loadBlacklist();

  if (sub === 'add' && gid) {
    bl[gid] = { ...(bl[gid] || {}), permanent: true, addedAt: new Date().toISOString() };
    saveBlacklist(bl);
    return ctx.reply(`✅ Grup <code>${gid}</code> ditambah ke blacklist.`, { parse_mode: 'HTML' });
  }

  if (sub === 'del' && gid) {
    delete bl[gid];
    saveBlacklist(bl);
    return ctx.reply(`✅ Grup <code>${gid}</code> dihapus dari blacklist.`, { parse_mode: 'HTML' });
  }

  if (sub === 'reset') {
    saveBlacklist({});
    return ctx.reply('✅ Blacklist direset.');
  }

  ctx.reply('❌ Format tidak dikenal.', { parse_mode: 'HTML' });
});

// === COMMAND: ANALYTICS USER (PREMIUM/ADMIN/OWNER) ===
bot.command('analytics', async (ctx) => {
  const userId = ctx.from.id;
  if (!isPremium(userId) && !isAdmin(userId) && !isOwner(userId)) {
    return ctx.reply(
      '<blockquote>⛔ Fitur ini khusus <b>Premium</b> ke atas.\n\nBeli akses di /start → Buy Akses.</blockquote>',
      { parse_mode: 'HTML' }
    );
  }

  const stats     = loadStats();
  const userStat  = stats.userStats?.[userId];
  const daily     = stats.dailyStats || {};

  if (!userStat) {
    return ctx.reply('<blockquote>📊 Belum ada data share kamu.</blockquote>', { parse_mode: 'HTML' });
  }

  // Ambil 7 hari terakhir
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d   = new Date(Date.now() - i * 86400000);
    const key = d.toISOString().slice(0, 10);
    const pad = (n) => String(n).padStart(2, '0');
    const label = `${pad(d.getDate())}/${pad(d.getMonth()+1)}`;
    const data  = daily[key];
    // Cek apakah user ada di list hari itu
    const aktif = data?.users?.includes(userId);
    days.push({ label, aktif, success: aktif ? (data.success || 0) : 0 });
  }

  // Bar chart sederhana pakai unicode
  const maxVal = Math.max(...days.map(d => d.success), 1);
  const chart  = days.map(d => {
    const pct   = Math.round((d.success / maxVal) * 8);
    const bar   = '█'.repeat(pct) + '░'.repeat(8 - pct);
    return `${d.label} [${bar}] ${d.aktif ? d.success : '-'}`;
  }).join('\n');

  const winRate = userStat.share > 0
    ? Math.round((userStat.success / (userStat.success + userStat.failed || 1)) * 100)
    : 0;

  ctx.reply(
    `<blockquote>📊 <b>ANALYTICS — ${ctx.from.first_name}</b>

` +
    `<b>Overall:</b>
` +
    `├ Total sesi  : <b>${userStat.share}</b>
` +
    `├ Total sukses: <b>${userStat.success}</b>
` +
    `├ Total gagal : <b>${userStat.failed}</b>
` +
    `└ Win rate    : <b>${winRate}%</b>

` +
    `<b>7 Hari Terakhir (sukses/sesi):</b>
` +
    `<code>${chart}</code>

` +
    `<i>Terakhir share: ${userStat.lastShare ? new Date(userStat.lastShare).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) : '-'}</i></blockquote>`,
    { parse_mode: 'HTML' }
  );
});

// === COMMAND: SET PESAN ===
bot.command('setpesan', (ctx) => {
    if (!ctx.message.reply_to_message) {
      return ctx.reply("⚠️ Reply pesan yang ingin dijadikan target auto share!");
    }
    
    userMessages.set(ctx.from.id, ctx.message.reply_to_message.message_id);
    ctx.reply("✅ <b>SET PESAN BERHASIL!</b>\nSekarang bisa gunakan auto on.", { parse_mode: 'HTML' });
});

// === REGISTER MODULES ===
setupAi(bot, config, isPremium);
setupToUrl(bot, config);
setupCekId(bot, config, { getRole, loadData, USERS_FILE });
setupTools(bot);
setupDownload(bot, isPremium);

// === HANDLER TEKS UNTUK WELCOME & AUTOTAG SETUP ===
bot.on('text', async (ctx, next) => {
  if (!isOwner(ctx.from.id)) return next();
  const state = welcomeSetupState.get(ctx.from.id) || autotagSetupState.get(ctx.from.id);
  if (!state) return next();

  const text = ctx.message.text;
  if (text.startsWith('/')) return next();

  // Strip semua HTML tag apapun, simpan sebagai plain text
  const plainText = text.replace(/<[^>]*>/g, '');

  // Welcome setup
  const welcome = loadWelcome();
  if (state === 'awaiting_text') {
    welcome.text = plainText;
    saveWelcome(welcome);
    welcomeSetupState.delete(ctx.from.id);
    return ctx.reply('✅ <b>Teks welcome berhasil disimpan!</b>\n\nGunakan /setwelcome untuk preview atau aktifkan.', { parse_mode: 'HTML' });
  }

  if (state === 'awaiting_btn') {
    const parts = text.split('|').map(s => s.trim());
    if (parts.length < 2 || !parts[1].startsWith('http')) {
      return ctx.reply('❌ Format salah. Contoh:\n<code>Join Channel | https://t.me/channel</code>', { parse_mode: 'HTML' });
    }
    welcome.buttonText = parts[0];
    welcome.buttonUrl = parts[1];
    saveWelcome(welcome);
    welcomeSetupState.delete(ctx.from.id);
    return ctx.reply(`✅ <b>Tombol berhasil disimpan!</b>\n\n🔘 <b>${parts[0]}</b> → ${parts[1]}`, { parse_mode: 'HTML' });
  }

  // Autotag setup
  if (state === 'awaiting_autotag_text') {
    const autotag = loadAutotag();
    autotag.text = plainText;
    saveAutotag(autotag);
    autotagSetupState.delete(ctx.from.id);
    return ctx.reply('✅ <b>Teks auto tag berhasil disimpan!</b>\n\nGunakan /setautotag untuk aktifkan.', { parse_mode: 'HTML' });
  }

  return next();
});

// === COMMAND: CEK DATA (ADMIN ONLY) ===
bot.command('cekdata', async (ctx) => {
  if (!isAdmin(ctx.from.id)) {
    return ctx.reply("⛔ Khusus Admin/Owner.");
  }
  
  const users = loadData(USERS_FILE);
  const groups = loadData(GROUPS_FILE);
  const premium = loadData(PREMIUM_FILE);
  const admins = loadData(ADMIN_FILE);
  const tokens = loadData(TOKENS_FILE);
  const delays = loadData(DELAY_FILE);
  
  let message = `<b>📊 DATA STATISTIK</b>\n\n`;
  message += `👥 Users: ${users.length} user\n`;
  message += `👥 Grup: ${Object.keys(groups).length} grup\n`;
  message += `💎 Premium: ${premium.length} user\n`;
  message += `🛠️ Admin: ${admins.length} user\n`;
  message += `🎟️ Token: ${Object.keys(tokens).length} user\n`;
  message += `⏱️ Delay: ${Object.keys(delays).length} user\n`;
  
  ctx.reply(message, { parse_mode: 'HTML' });
});

// === COMMAND: BACKUP MANUAL (ADMIN ONLY) ===
bot.command('backup', async (ctx) => {
  if (!isOwner(ctx.from.id)) {
    return ctx.reply("⛔ Khusus Admin/Owner.");
  }

  const msg = await ctx.reply("🔄 Membuat backup...");

  try {
    if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const zipName = `backup_${timestamp}.zip`;
    const zipPath = `${BACKUP_DIR}${zipName}`;

    // Scan SEMUA file di root folder, kecuali node_modules dan backups
    const EXCLUDE = ['node_modules', 'backups', '.git'];
    const allFiles = fs.readdirSync('./').filter(f => {
      if (EXCLUDE.includes(f)) return false;
      try { return fs.statSync(f).isFile(); } catch { return false; }
    }).map(f => ({ src: `./${f}`, name: f }));

    if (allFiles.length === 0) {
      await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, "⚠️ Tidak ada file untuk dibackup.");
      return;
    }

    // Buat zip dengan perintah shell
    const fileArgs = allFiles.map(f => f.src).join(' ');
    const { execSync } = require('child_process');

    try {
      execSync(`zip -j "${zipPath}" ${fileArgs}`);
    } catch (e) {
      // Fallback: buat arsip manual sederhana kalau zip tidak tersedia
      const archivePath = zipPath.replace('.zip', '.tar.gz');
      execSync(`tar -czf "${archivePath}" ${fileArgs}`);
      const zipPathFinal = archivePath;
      const zipSizeFinal = (fs.statSync(zipPathFinal).size / 1024).toFixed(2);

      await ctx.telegram.editMessageText(
        ctx.chat.id, msg.message_id, null,
        `<blockquote>✅ <b>BACKUP SELESAI</b>\n\n` +
        `📦 File: <code>${zipPathFinal.split('/').pop()}</code>\n` +
        `📁 Isi: ${allFiles.length} file\n` +
        `💾 Size: ${zipSizeFinal} KB\n` +
        `🕐 ${new Date().toLocaleString('id-ID')}</blockquote>`,
        { parse_mode: 'HTML' }
      );

      await ctx.replyWithDocument(
        { source: zipPathFinal, filename: zipPathFinal.split('/').pop() },
        {
          caption:
            `<blockquote>📦 <b>BACKUP LENGKAP</b>\n\n` +
            `🗂️ Isi file:\n` +
            allFiles.map((f, i) => `  ${i+1}. ${f.name}`).join('\n') + '\n\n' +
            `💾 Size: ${zipSizeFinal} KB\n` +
            `🕐 ${new Date().toLocaleString('id-ID')}</blockquote>`,
          parse_mode: 'HTML'
        }
      );
      return;
    }

    const zipSize = (fs.statSync(zipPath).size / 1024).toFixed(2);

    await ctx.telegram.editMessageText(
      ctx.chat.id, msg.message_id, null,
      `<blockquote>✅ <b>BACKUP SELESAI</b>\n\n` +
      `📦 File: <code>${zipName}</code>\n` +
      `📁 Isi: ${allFiles.length} file\n` +
      `💾 Size: ${zipSize} KB\n` +
      `🕐 ${new Date().toLocaleString('id-ID')}</blockquote>`,
      { parse_mode: 'HTML' }
    );

    await ctx.replyWithDocument(
      { source: zipPath, filename: zipName },
      {
        caption:
          `<blockquote>📦 <b>BACKUP LENGKAP</b>\n\n` +
          `🗂️ Isi file:\n` +
          allFiles.map((f, i) => `  ${i+1}. ${f.name}`).join('\n') + '\n\n' +
          `💾 Size: ${zipSize} KB\n` +
          `🕐 ${new Date().toLocaleString('id-ID')}</blockquote>`,
        parse_mode: 'HTML'
      }
    );

    // Bersihkan zip lama (simpan 5 terakhir)
    const oldZips = fs.readdirSync(BACKUP_DIR)
      .filter(f => f.startsWith('backup_') && (f.endsWith('.zip') || f.endsWith('.tar.gz')))
      .map(f => ({ name: f, time: fs.statSync(`${BACKUP_DIR}${f}`).mtime.getTime() }))
      .sort((a, b) => b.time - a.time);
    oldZips.slice(5).forEach(f => {
      try { fs.unlinkSync(`${BACKUP_DIR}${f.name}`); } catch {}
    });

  } catch (error) {
    console.error('Error backup:', error);
    try {
      await ctx.telegram.editMessageText(ctx.chat.id, msg.message_id, null, `❌ Gagal backup: ${error.message}`);
    } catch {}
  }
});

// === COMMAND: RESTORE DATA ===
bot.command('restore', async (ctx) => {
  if (!isOwner(ctx.from.id)) {
    return ctx.reply("⛔ Khusus Owner.");
  }
  
  const args = ctx.message.text.split(' ');
  if (args.length < 2) {
    return ctx.reply("⚠️ Gunakan: /restore <nama_file_backup>");
  }
  
  const backupFile = args[1];
  const msg = await ctx.reply(`🔄 Merestore ${backupFile}...`);
  
  try {
    const backupPath = `${BACKUP_DIR}${backupFile}`;
    if (!fs.existsSync(backupPath)) {
      return ctx.reply("❌ File backup tidak ditemukan.");
    }
    
    let targetFile = '';
    if (backupFile.includes('users.json')) targetFile = USERS_FILE;
    else if (backupFile.includes('group_ids.json')) targetFile = GROUPS_FILE;
    else if (backupFile.includes('premium.json')) targetFile = PREMIUM_FILE;
    else if (backupFile.includes('admins.json')) targetFile = ADMIN_FILE;
    else if (backupFile.includes('user_tokens.json')) targetFile = TOKENS_FILE;
    else if (backupFile.includes('share_delay.json')) targetFile = DELAY_FILE;
    else {
      return ctx.reply("❌ File backup tidak dikenali.");
    }
    
    const data = JSON.parse(fs.readFileSync(backupPath));
    const currentData = loadData(targetFile);
    const tempBackup = `${BACKUP_DIR}pre_restore_${Date.now()}_${backupFile}`;
    fs.writeFileSync(tempBackup, JSON.stringify(currentData, null, 2));
    
    saveData(targetFile, data);
    
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      `<blockquote>✅ <b>RESTORE BERHASIL</b>\n\n` +
      `📄 File: ${backupFile}\n` +
      `🎯 Target: ${targetFile}\n` +
      `📦 Data: ${Object.keys(data).length || data.length} item\n\n` +
      `⚠️ Data sebelumnya telah di-backup ke:\n<code>${tempBackup}</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  } catch (error) {
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      msg.message_id,
      null,
      `❌ Gagal restore: ${error.message}`
    );
  }
});

// === COMMAND: INFO BACKUP ===
bot.command('infobackup', async (ctx) => {
  if (!isOwner(ctx.from.id)) {
    return ctx.reply("⛔ Khusus Owner.");
  }
  
  if (!fs.existsSync(BACKUP_DIR)) {
    return ctx.reply("📁 Belum ada folder backup.");
  }
  
  const files = fs.readdirSync(BACKUP_DIR).filter(f => f.endsWith('.json'));
  
  const groups = {
    'users.json': files.filter(f => f.includes('users.json')),
    'group_ids.json': files.filter(f => f.includes('group_ids.json')),
    'premium.json': files.filter(f => f.includes('premium.json')),
    'admins.json': files.filter(f => f.includes('admins.json')),
    'user_tokens.json': files.filter(f => f.includes('user_tokens.json')),
    'share_delay.json': files.filter(f => f.includes('share_delay.json'))
  };
  
  let totalSize = 0;
  files.forEach(f => {
    const stat = fs.statSync(`${BACKUP_DIR}${f}`);
    totalSize += stat.size;
  });
  
  let message = `<b>📊 INFO BACKUP</b>\n\n`;
  message += `📁 Lokasi: ${BACKUP_DIR}\n`;
  message += `📦 Total file: ${files.length}\n`;
  message += `💾 Total size: ${(totalSize / 1024 / 1024).toFixed(2)} MB\n\n`;
  message += `<b>Rincian per file:</b>\n`;
  
  for (let [key, value] of Object.entries(groups)) {
    if (value.length > 0) {
      message += `• ${key}: ${value.length} backup\n`;
    }
  }
  
  message += `\nGunakan:\n`;
  message += `• /backup - Backup manual\n`;
  message += `• /listbackup - Lihat daftar backup\n`;
  message += `• /restore - Restore data\n`;
  message += `• /cleanbackup - Hapus backup lama`;
  
  ctx.reply(message, { parse_mode: 'HTML' });
});

// === COMMAND: LIST BACKUP LAMA ===
bot.command('oldbackups', async (ctx) => {
  if (!isAdmin(ctx.from.id)) {
    return ctx.reply("⛔ Khusus Admin/Owner.");
  }
  
  if (!fs.existsSync(BACKUP_DIR)) {
    return ctx.reply("📁 Belum ada folder backup.");
  }
  
  const files = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.endsWith('.json'))
    .map(f => {
      const stat = fs.statSync(`${BACKUP_DIR}${f}`);
      return {
        name: f,
        size: (stat.size / 1024).toFixed(2) + ' KB',
        time: stat.mtime,
        path: `${BACKUP_DIR}${f}`
      };
    })
    .sort((a, b) => b.time - a.time)
    .slice(0, 10);
  
  if (files.length === 0) {
    return ctx.reply("📁 Belum ada file backup.");
  }
  
  ctx.session = ctx.session || {};
  ctx.session.oldBackups = files;
  
  let message = `<b>📋 BACKUP TERSEDIA (10 terbaru)</b>\n\n`;
  files.forEach((f, i) => {
    const date = f.time.toLocaleString('id-ID');
    message += `${i+1}. <code>${f.name}</code>\n   📅 ${date} | 📦 ${f.size}\n`;
  });
  
  message += `\nPilih file yang ingin diunduh:`;
  
  let buttons = [];
  files.forEach((f, i) => {
    buttons.push([Markup.button.callback(`📥 File ${i+1}`, `download_old_${i}`)]);
  });
  buttons.push([Markup.button.callback('❌ BATAL', 'cancel_backup')]);
  
  await ctx.reply(message, { 
    parse_mode: 'HTML',
    ...Markup.inlineKeyboard(buttons)
  });
});

// === CALLBACK DOWNLOAD BACKUP LAMA ===
bot.action(/^download_old_(\d+)$/, async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  
  const index = parseInt(ctx.match[1]);
  
  if (!ctx.session || !ctx.session.oldBackups || !ctx.session.oldBackups[index]) {
    return ctx.reply("❌ File tidak ditemukan.");
  }
  
  const file = ctx.session.oldBackups[index];
  
  try {
    await ctx.replyWithDocument(
      { source: file.path, filename: file.name },
      { caption: `📦 <b>File Backup</b>\n📅 ${file.time.toLocaleString('id-ID')}\n📦 ${file.size}`, parse_mode: 'HTML' }
    );
  } catch (error) {
    await ctx.reply(`❌ Gagal mengirim: ${error.message}`);
  }
});

// === CALLBACK BATAL ===
bot.action('cancel_backup', async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  await ctx.deleteMessage();
  await ctx.reply("❌ Pengiriman dibatalkan.");
  delete ctx.session?.lastBackups;
});

// === COMMAND: MAINTENANCE MODE (OWNER ONLY) ===
bot.command('up', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('⛔ Khusus Owner.');
  const current = qrisMode === 'auto' ? '⚡ Otomatis' : '🖼️ Manual';
  ctx.reply(
    `<blockquote>💳 <b>PENGATURAN QRIS</b>\n\nMode aktif saat ini: <b>${current}</b>\n\nPilih mode pembayaran:</blockquote>`,
    {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('⚡ QRIS OTOMATIS', 'up_auto')],
        [Markup.button.callback('🖼️ QRIS MANUAL', 'up_manual')]
      ])
    }
  );
});

bot.action('up_auto', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('⛔ Akses ditolak!', { show_alert: true });
  qrisMode = 'auto';
  await ctx.answerCbQuery('✅ Mode QRIS diubah ke Otomatis', { show_alert: true });
  safeEdit(ctx, `<blockquote>✅ <b>Mode QRIS: OTOMATIS</b>\n\nUser akan menggunakan QRIS Pakasir otomatis.</blockquote>`, { parse_mode: 'HTML' });
});

bot.action('up_manual', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('⛔ Akses ditolak!', { show_alert: true });
  qrisMode = 'manual';
  await ctx.answerCbQuery('✅ Mode QRIS diubah ke Manual', { show_alert: true });
  safeEdit(ctx, `<blockquote>✅ <b>Mode QRIS: MANUAL</b>\n\nUser akan diarahkan ke QRIS manual dan diberi tahu QRIS otomatis sedang bermasalah.</blockquote>`, { parse_mode: 'HTML' });
});

bot.command('mtc', async (ctx) => {
  if (!isOwner(ctx.from.id)) {
    return ctx.reply("⛔ Khusus Owner.");
  }
  
  const keyboard = Markup.inlineKeyboard([
    [
      Markup.button.callback('🔴 OFF', 'mtc_off'),
      Markup.button.callback('🟢 ON', 'mtc_on')
    ],
    [Markup.button.callback('📊 STATUS', 'mtc_status')]
  ]);
  
  const status = maintenanceMode ? '🟢 AKTIF' : '🔴 NONAKTIF';
  
  await ctx.reply(
    `<b>🔧 MAINTENANCE MODE</b>\n\n` +
    `Status saat ini: ${status}\n\n` +
    `Pilih tindakan:`,
    {
      parse_mode: 'HTML',
      ...keyboard
    }
  );
});

// === CALLBACK MAINTENANCE ===
bot.action('mtc_on', async (ctx) => {
  if (!isOwner(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  }
  
  saveMaintenanceStatus(true);
  await ctx.answerCbQuery('✅ Maintenance mode AKTIF');
  await ctx.editMessageText(
    `<b>🔧 MAINTENANCE MODE</b>\n\n` +
    `Status: 🟢 <b>AKTIF</b>\n\n` +
    `Semua user (kecuali owner) tidak bisa menggunakan bot.\n` +
    `Gunakan /mtc untuk mengubah lagi.`,
    { parse_mode: 'HTML' }
  );
  
  await ctx.reply('✅ Bot sekarang dalam mode MAINTENANCE. Hanya owner yang bisa akses.');
});

bot.action('mtc_off', async (ctx) => {
  if (!isOwner(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  }
  
  saveMaintenanceStatus(false);
  await ctx.answerCbQuery('✅ Maintenance mode NONAKTIF');
  await ctx.editMessageText(
    `<b>🔧 MAINTENANCE MODE</b>\n\n` +
    `Status: 🔴 <b>NONAKTIF</b>\n\n` +
    `Bot kembali berjalan normal untuk semua user.`,
    { parse_mode: 'HTML' }
  );
  
  await ctx.reply('✅ Bot kembali NORMAL. Semua user bisa akses.');
});

bot.action('mtc_status', async (ctx) => {
  if (!isOwner(ctx.from.id)) {
    return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  }
  
  const status = maintenanceMode ? '🟢 AKTIF' : '🔴 NONAKTIF';
  await ctx.answerCbQuery(`Maintenance mode: ${status}`, { show_alert: true });
});

// === COMMAND: SHARE MANUAL ===
bot.command('share', (ctx) => enqueueShare(ctx, 'free'));

// === COMMAND: SHARE VIP ===
bot.command('sharevip', (ctx) => enqueueShare(ctx, 'vip'));

// === COMMAND: AUTO SHARE (ON/OFF) - TANPA SLASH ===
// === HELPER: Kirim pesan status auto share (dipakai di 'auto status' & /autostatus) ===
const buildAutoStatusText = async (requesterId) => {
  const role = getRole(requesterId);
  const autoStatus = autoShareStatus.get(requesterId) || 'off';
  const autoInterval = getAutoShareInterval(requesterId);
  const nextRunTime = autoShareTime.get(requesterId);

  let txt = `<blockquote>🤖 <b>STATUS AUTO SHARE</b>\n\n`;
  txt += `👤 Role    : <b>${role}</b>\n`;
  txt += `📡 Status  : <b>${autoStatus === 'on' ? '🟢 ON' : '🔴 OFF'}</b>\n`;

  if (autoStatus === 'on') {
    const nextStr = nextRunTime
      ? new Date(nextRunTime).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Jakarta' })
      : '-';
    const userGroups = getUserGroups(requesterId);
    txt += `⏱️ Interval: <b>${autoInterval / 1000 / 60} menit</b>\n`;
    txt += `🏘️ Grup    : <b>${userGroups.length} grup</b>\n`;
    txt += `🕐 Next run: <b>${nextStr} WIB</b>`;
  } else {
    txt += `\n<i>Ketik "auto on" untuk mengaktifkan.</i>`;
  }

  // Daftar semua user yang sedang auto on (tampil untuk semua role)
  const activeUsers = [...autoShareStatus.entries()].filter(([, s]) => s === 'on');
  const roleOrder = (uid) => isOwner(uid) ? 0 : isAdmin(uid) ? 1 : 2;
  activeUsers.sort((a, b) => roleOrder(a[0]) - roleOrder(b[0]));

  txt += `\n\n👥 <b>User Auto Aktif: ${activeUsers.length}</b>`;

  if (activeUsers.length > 0) {
    for (let i = 0; i < activeUsers.length; i++) {
      const [uid] = activeUsers[i];
      const uidRole = isOwner(uid) ? 'Owner 👑' : isAdmin(uid) ? 'Admin ⭐' : isPaidPremium(uid) ? 'Premium 💎' : 'Premium Gratis 🎁';
      // Ambil info user dari Telegram jika tersedia di cache, fallback ke ID
      let uname = autoUserCache.get(Number(uid));
      if (!uname) uname = `<code>${uid}</code>`;
      txt += `\n${i + 1}. Role: <b>${uidRole}</b>\n    Username: ${uname}`;
    }
  }

  // Posisi antrian sendiri (untuk non-admin)
  if (!isOwner(requesterId) && !isAdmin(requesterId)) {
    const pos = activeUsers.findIndex(([uid]) => uid == requesterId);
    if (pos !== -1) {
      txt += `\n\n📊 Posisi kamu: <b>#${pos + 1} dari ${activeUsers.length}</b>`;
    }
  }

  txt += `</blockquote>`;
  return txt;
};

const sendAutoStatusMsg = async (ctx, userId) => {
  const txt = await buildAutoStatusText(userId);
  return ctx.reply(txt, { parse_mode: 'HTML' });
};

// Cache username user yang pakai auto (diupdate saat auto on)
const autoUserCache = new Map(); // userId (Number) -> "@username atau Nama"

bot.hears(/^auto (on|off|status)$/i, async (ctx) => {
    const args = ctx.match[1].toLowerCase();
    const userId = ctx.from.id;
    const role = getRole(userId);

    if (args === 'status') {
      return sendAutoStatusMsg(ctx, userId);
    }
    
    if (args === 'on') {
        // Cek apakah bisa auto share
        if (!canAutoShare(userId)) {
            const isGroupPrem = hasGroupPremium(userId);
            return ctx.reply(
              isGroupPrem
                ? `⛔ <b>AKSES DITOLAK!</b>\n\nPremium gratis (add grup) hanya bisa pakai:\n🖼️ Broadcast Image\n🎬 Broadcast Media\n\n💡 Beli premium untuk akses Auto Share & Broadcast Teks.`
                : `⛔ Fitur auto share khusus Premium/Admin/Owner!\nKetik /start dan beli premium.`,
              { parse_mode: 'HTML' }
            );
        }

        // Cek jika premium gratis dicabut karena kick >= 3 grup
        if (!isOwner(userId) && !isAdmin(userId) && !isPaidPremium(userId) && !hasGroupPremium(userId)) {
            const kicks = getKickCount(userId);
            if (kicks >= 3) {
                return ctx.reply(
                    `⛔ <b>AKSES DITOLAK!</b>\n\n` +
                    `Premium gratis kamu dicabut karena bot dikeluarkan dari <b>${kicks} grup</b>.\n\n` +
                    `💡 Tambahkan bot ke <b>3 grup baru</b> melalui /start untuk mendapatkan premium gratis lagi.`,
                    { parse_mode: 'HTML' }
                );
            }
        }
        
        if (!userMessages.has(userId)) {
            return ctx.reply("❌ <b>GAGAL!</b>\nAnda harus /setpesan dulu!", { parse_mode: 'HTML' });
        }
        
        const autoInterval = getAutoShareInterval(userId);
        const shareDelay = getDelayByRole(userId);
        
        autoShareMessageId.set(userId, userMessages.get(userId));
        autoShareStatus.set(userId, 'on');
        autoShareTime.set(userId, Date.now());

        // Simpan username ke cache buat ditampilkan di auto status
        const u = ctx.from;
        const displayName = u.username ? `@${u.username}` : `<b>${[u.first_name, u.last_name].filter(Boolean).join(' ')}</b>`;
        autoUserCache.set(userId, displayName);
        
        ctx.reply(
            `🚀 <b>AUTO SHARE AKTIF!</b>\n\n` +
            `👤 Role: ${role}\n` +
            `📤 Interval: ${autoInterval / 1000 / 60} menit\n` +
            `⏱️ Delay antar grup: ${shareDelay / 1000} detik\n` +
            `🔄 Akan loop terus sampai auto off`,
            { parse_mode: 'HTML' }
        );
        
        enqueueShare(ctx, 'autoshare', 1, userMessages.get(userId));
        
    } else if (args === 'off') {
        autoShareStatus.set(userId, 'off');
        autoShareTime.delete(userId);
        autoShareMessageId.delete(userId);
        ctx.reply("🛑 <b>AUTO SHARE DIMATIKAN!</b>", { parse_mode: 'HTML' });
    }
});

// === COMMAND: /autostatus ===
bot.command('autostatus', async (ctx) => {
  return sendAutoStatusMsg(ctx, ctx.from.id);
});

// === COMMAND: CEK STATUS ===
bot.command('cek', async (ctx) => {
  const userId = ctx.from.id;
  const userGroups = getUserGroups(userId);
  const isVerified = await checkRequirement(userId);
  const autoStatus = autoShareStatus.get(userId) || 'off';
  const role = getRole(userId);
  const todayShares = getTodayFreeShares(userId);
  
  let message = `<b>📋 STATUS AKUN</b>\n\n`;
  message += `🆔 User ID: <code>${userId}</code>\n`;
  message += `👤 Role: <b>${role}</b>\n`;
  message += `✅ Verifikasi: ${isVerified ? '✓ LULUS' : '✗ BELUM'}\n`;
  message += `👥 Grup: ${userGroups.length}/3\n`;
  
  if (role === 'FREE') {
      message += `🎟️ Token hari ini: ${getDailyToken(userId)}\n`;
      message += `📊 Share hari ini: ${todayShares}/${config.MAX_SHARE_FREE}\n`;
      message += `⏱️ Delay free: ${config.DELAY_FREE} menit\n`;
  }
  
  message += `🔄 Auto Share: ${autoStatus === 'on' ? '✓ AKTIF' : '✗ MATI'}\n`;
  
  if (autoStatus === 'on' && role !== 'FREE') {
      message += `⏱️ Auto interval: ${getAutoShareInterval(userId)/1000/60} menit\n`;
  }
  
  try {
    const cm1 = await ctx.telegram.getChatMember(config.CHANNEL_ID, userId);
    const cm2 = await ctx.telegram.getChatMember(config.CHANNEL_ID_2, userId);
    const statuses = ['member', 'administrator', 'creator'];
    const ok1 = statuses.includes(cm1.status);
    const ok2 = statuses.includes(cm2.status);
    message += `📢 Channel 1: ${ok1 ? '✓ JOIN' : '✗ BELUM'}\n`;
    message += `📢 Channel 2: ${ok2 ? '✓ JOIN' : '✗ BELUM'}`;
  } catch {
    message += `📢 Channel: ✗ ERROR CEK`;
  }
  
  ctx.reply(message, { parse_mode: 'HTML' });
});

// === COMMAND: CEK AUTO ===
bot.command('cekauto', (ctx) => {
  const userId = ctx.from.id;
  const status = autoShareStatus.get(userId) || 'off';
  const msgId = autoShareMessageId.get(userId) || 'tidak ada';
  const lastTime = autoShareTime.get(userId) || 0;
  
  let message = `<b>📊 STATUS AUTO SHARE</b>\n\n`;
  message += `🔄 Status: ${status === 'on' ? '✅ AKTIF' : '❌ MATI'}\n`;
  message += `🆔 Pesan ID: <code>${msgId}</code>\n`;
  
  if (lastTime > 0) {
    const lastRun = new Date(lastTime).toLocaleString('id-ID');
    message += `⏱️ Terakhir: ${lastRun}\n`;
  }
  
  if (status === 'on') {
    const interval = getAutoShareInterval(userId) / 1000 / 60;
    message += `📤 Interval: ${interval} menit\n`;
  }
  
  ctx.reply(message, { parse_mode: 'HTML' });
});

// === COMMAND: BROADCAST ===
// === SISTEM PRIORITY QUEUE BCBOT ===
// Struktur: { userId, ctx, broadcastMsgId, broadcastChatId, role, username, queueMsgId }
const bcbotQueue = [];
let bcbotRunning = false;
// Map userId -> queueMsgId (pesan status antrian user yang nunggu)
const bcbotQueueMsgIds = new Map();

const getBcbotRolePower = (userId) => {
  if (isOwner(userId)) return 3;
  if (isAdmin(userId)) return 2; // pure admin (bukan owner)
  return 1; // premium
};

const getBcbotRoleLabel = (userId) => {
  if (isOwner(userId)) return '👑 Owner';
  if (isAdmin(userId)) return '⭐ Admin';
  if (isPaidPremium(userId)) return '💎 Premium';
  return '🎁 Premium Gratis';
};

// Buat teks status antrian untuk ditampilkan ke user yang nunggu
const buildQueueStatusText = (waitingUserId) => {
  // Gabungkan yang lagi jalan + yang di antrian
  const allEntries = [];

  // Yang sedang berjalan (bukan dari queue, tapi dari bcbotRunning)
  // Kita track via bcbotCurrentEntry
  if (bcbotCurrentEntry) {
    allEntries.push({ ...bcbotCurrentEntry, running: true });
  }

  // Yang di antrian (urut sesuai array)
  for (const entry of bcbotQueue) {
    allEntries.push({ ...entry, running: false });
  }

  let text = `<blockquote>⏳ <b>MOHON TUNGGU ANTRIAN</b>\n\n`;
  allEntries.forEach((entry, i) => {
    const uname = entry.username ? `@${entry.username}` : `<code>${entry.userId}</code>`;
    const status = entry.running ? ' ▶️ <i>(sedang berjalan)</i>' : '';
    text += `${i + 1}. Role : ${getBcbotRoleLabel(entry.userId)}${status}\n`;
    text += `    Username : ${uname}\n\n`;
  });

  // Posisi user yang nunggu di antrian
  const myPos = allEntries.findIndex(e => e.userId === waitingUserId);
  if (myPos >= 0) {
    text += `📍 Posisi kamu: <b>#${myPos + 1}</b></blockquote>`;
  } else {
    text += `</blockquote>`;
  }

  return text;
};

// Update semua pesan status antrian user yang sedang nunggu
const updateAllQueueMessages = async () => {
  for (const [uid, { chatId, msgId }] of bcbotQueueMsgIds.entries()) {
    const text = buildQueueStatusText(uid);
    await bot.telegram.editMessageText(chatId, msgId, null, text, { parse_mode: 'HTML' }).catch(() => {});
  }
};

let bcbotCurrentEntry = null; // entry yang sedang berjalan

const runNextBcbot = async () => {
  if (bcbotRunning || bcbotQueue.length === 0) return;

  bcbotRunning = true;

  // Ambil entry prioritas tertinggi (sudah diurutkan saat insert)
  const entry = bcbotQueue.shift();
  bcbotCurrentEntry = entry;

  // Hapus pesan antrian milik user yang sekarang jalan
  const queueMsgData = bcbotQueueMsgIds.get(entry.userId);
  if (queueMsgData) {
    await bot.telegram.deleteMessage(queueMsgData.chatId, queueMsgData.msgId).catch(() => {});
    bcbotQueueMsgIds.delete(entry.userId);
  }

  // Update antrian semua yang masih nunggu
  await updateAllQueueMessages();

  const { ctx, broadcastMsgId, broadcastChatId } = entry;
  const users = loadData(USERS_FILE);
  const total = users.length;

  const progress = await ctx.reply(
    `<blockquote>📢 <b>BROADCAST DIMULAI</b>\n\n` +
    `👤 Role    : ${getBcbotRoleLabel(entry.userId)}\n` +
    `📦 Target  : <b>${total} user</b>\n\n` +
    `⏳ Memulai pengiriman...</blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => null);

  let success = 0, failed = 0;
  const startTime = Date.now();

  for (const u of users) {
    try {
      await bot.telegram.copyMessage(u, broadcastChatId, broadcastMsgId);
      success++;
    } catch {
      failed++;
    }

    if (progress && (success + failed) % 10 === 0) {
      const pct = Math.floor(((success + failed) / total) * 100);
      const bar = '█'.repeat(Math.floor(pct / 10)) + '░'.repeat(10 - Math.floor(pct / 10));
      await ctx.telegram.editMessageText(
        ctx.chat.id, progress.message_id, null,
        `<blockquote>📢 <b>BROADCAST BERJALAN</b>\n\n` +
        `👤 Role    : ${getBcbotRoleLabel(entry.userId)}\n` +
        `📊 Progress: [${bar}] ${pct}%\n` +
        `✅ Berhasil: <b>${success}</b>  ❌ Gagal: <b>${failed}</b>\n` +
        `📦 Terkirim: <b>${success + failed}/${total}</b></blockquote>`,
        { parse_mode: 'HTML' }
      ).catch(() => {});
    }

    // Yield ke event loop agar bot tetap responsif
    await new Promise(r => setTimeout(r, 100));
  }

  const totalTime = Math.floor((Date.now() - startTime) / 1000);

  if (!ctx.message?.reply_to_message && broadcastMsgId) {
    await ctx.telegram.deleteMessage(broadcastChatId, broadcastMsgId).catch(() => {});
  }

  if (progress) {
    await ctx.telegram.editMessageText(
      ctx.chat.id, progress.message_id, null,
      `<blockquote>✅ <b>BROADCAST SELESAI</b>\n\n` +
      `👤 Role    : ${getBcbotRoleLabel(entry.userId)}\n` +
      `✅ Berhasil: <b>${success}</b>  ❌ Gagal: <b>${failed}</b>\n` +
      `📦 Total   : <b>${total} user</b>\n` +
      `⏱️ Durasi  : <b>${Math.floor(totalTime / 60)}m ${totalTime % 60}s</b></blockquote>`,
      { parse_mode: 'HTML' }
    ).catch(() => {});
  }

  bcbotCurrentEntry = null;
  bcbotRunning = false;

  // Update sisa antrian lalu jalankan berikutnya
  await updateAllQueueMessages();
  runNextBcbot();
};

bot.command('bcbot', async (ctx) => {
  const userId = ctx.from.id;

  // Cek akses: hanya admin & owner (isPremium includes admin & owner)
  // /bcbot hanya untuk premium BERBAYAR (beli akses/addprem), admin, dan owner
  // Group premium (gratis dari 3 grup) tidak bisa /bcbot
  if (!isPaidPremium(userId)) return ctx.reply(
    '⛔ <b>Akses ditolak!</b>\n\nFitur /bcbot hanya untuk Premium berbayar, Admin, dan Owner.\n\nBeli akses melalui /start → Buy Akses.',
    { parse_mode: 'HTML' }
  );

  const users = loadData(USERS_FILE);
  if (users.length === 0) return ctx.reply('❌ Belum ada user terdaftar.');

  // Cegah double queue dari user yang sama
  if (bcbotQueue.some(e => e.userId === userId) || (bcbotCurrentEntry?.userId === userId)) {
    return ctx.reply('⏳ Kamu sudah ada di antrian broadcast. Tunggu giliranmu.');
  }

  // Siapkan pesan broadcast
  let broadcastMsgId = null;
  const broadcastChatId = ctx.chat.id;

  if (ctx.message.reply_to_message) {
    broadcastMsgId = ctx.message.reply_to_message.message_id;
  } else {
    const text = ctx.message.text.split(' ').slice(1).join(' ');
    if (!text) return ctx.reply('⚠️ Gunakan: /bcbot teks atau reply pesan');
    const sentMsg = await ctx.reply(text, { parse_mode: 'HTML' });
    broadcastMsgId = sentMsg.message_id;
  }

  const username = ctx.from.username || null;
  const power = getBcbotRolePower(userId);

  // Owner langsung masuk depan antrian, admin & premium diurutkan prioritas
  bcbotQueue.push({ userId, ctx, broadcastMsgId, broadcastChatId, username, power });
  // Sort: owner (3) > admin (2) > premium (1), FIFO dalam tier yang sama
  bcbotQueue.sort((a, b) => b.power - a.power);

  if (bcbotRunning) {
    // Kasih tau user posisi antriannya
    const queueText = buildQueueStatusText(userId);
    const queueMsg = await ctx.reply(queueText, { parse_mode: 'HTML' }).catch(() => null);
    if (queueMsg) {
      bcbotQueueMsgIds.set(userId, { chatId: ctx.chat.id, msgId: queueMsg.message_id });
    }
    // Update semua yang lagi nunggu juga
    await updateAllQueueMessages();
  } else {
    // Langsung jalankan (non-blocking)
    (async () => { await runNextBcbot(); })();
  }
});

// === COMMAND: HELP ===
bot.command('help', (ctx) => {
  const helpText = `
<b>📚 DAFTAR PERINTAH</b>

<b>🔰 UMUM:</b>
• /start - Mulai bot & verifikasi
• /cek - Cek status akun
• /setpesan - Set pesan untuk auto share

<b>📤 SHARE:</b>
• /share [teks] - Share manual
• /sharevip [teks] - Admin share
• auto on - Auto share loop (premium)
• auto off - Matikan auto share
• /cekauto - Cek status auto share

<b>📅 JADWAL (PREMIUM):</b>
• /jadwal - Lihat jadwal & cara pakai
• /jadwal add 08:00 - Tambah jadwal
• /jadwal on/off - Aktifkan/matikan
• /jadwal clear - Hapus semua jadwal

<b>📊 STATISTIK:</b>
• /stats - Statistik share kamu (admin: semua user)

<b>📢 BROADCAST:</b>
• /bcbot [teks] - Broadcast ke semua user (admin)

<b>💾 BACKUP (ADMIN):</b>
• /backup - Backup & kirim ke chat
• /cekdata - Cek data
• /restore - Restore data
• /infobackup - Info backup
• /oldbackups - Lihat backup lama

<b>🔧 MAINTENANCE (OWNER):</b>
• /mtc - Atur mode maintenance

<b>💳 PREMIUM:</b>
• Klik menu "BUY AKSES" di /start
  `;
  
  ctx.reply(helpText, { parse_mode: 'HTML' });
});

// === COMMAND: STATISTIK LENGKAP ===
bot.command('stats', async (ctx) => {
  const userId = ctx.from.id;
  const role = getRole(userId);
  const stats = loadStats();
  const today = new Date().toISOString().slice(0, 10);
  const todayData = stats.dailyStats[today] || { share: 0, success: 0, failed: 0, users: [] };
  const userStat = stats.userStats[userId] || { share: 0, success: 0, failed: 0, lastShare: null };

  // Hitung 7 hari terakhir
  let week7Share = 0, week7Success = 0;
  for (let i = 0; i < 7; i++) {
    const d = new Date(); d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    if (stats.dailyStats[key]) {
      week7Share += stats.dailyStats[key].share || 0;
      week7Success += stats.dailyStats[key].success || 0;
    }
  }

  const users = loadData(USERS_FILE);
  const groups = loadData(GROUPS_FILE);
  const premium = loadData(PREMIUM_FILE);

  let msg = `<b>📊 STATISTIK BOT</b>\n\n`;

  if (isAdmin(userId)) {
    msg += `<b>🌐 GLOBAL:</b>\n`;
    msg += `👥 Total user: <b>${users.length}</b>\n`;
    msg += `🏘️ Total grup: <b>${Object.keys(groups).length}</b>\n`;
    msg += `💎 Premium: <b>${premium.length}</b>\n`;
    msg += `📤 Total share (all time): <b>${stats.totalShare || 0}x</b>\n`;
    msg += `✅ Total berhasil: <b>${stats.totalShareSuccess || 0}</b>\n`;
    msg += `❌ Total gagal: <b>${stats.totalShareFailed || 0}</b>\n\n`;

    msg += `<b>📅 HARI INI (${today}):</b>\n`;
    msg += `📤 Share: <b>${todayData.share}x</b>\n`;
    msg += `✅ Berhasil: <b>${todayData.success}</b>\n`;
    msg += `❌ Gagal: <b>${todayData.failed}</b>\n`;
    msg += `👤 User aktif: <b>${todayData.users.length}</b>\n\n`;

    msg += `<b>📈 7 HARI TERAKHIR:</b>\n`;
    msg += `📤 Share: <b>${week7Share}x</b>\n`;
    msg += `✅ Berhasil: <b>${week7Success}</b>\n\n`;
  }

  msg += `<b>👤 STATISTIK KAMU (${role}):</b>\n`;
  msg += `📤 Total share: <b>${userStat.share}x</b>\n`;
  msg += `✅ Berhasil: <b>${userStat.success}</b>\n`;
  msg += `❌ Gagal: <b>${userStat.failed}</b>\n`;
  if (userStat.lastShare) {
    msg += `🕐 Terakhir share: <b>${new Date(userStat.lastShare).toLocaleString('id-ID')}</b>\n`;
  }

  // Hitung success rate
  if (userStat.success + userStat.failed > 0) {
    const rate = ((userStat.success / (userStat.success + userStat.failed)) * 100).toFixed(1);
    msg += `📊 Success rate: <b>${rate}%</b>\n`;
  }

  ctx.reply(msg, { parse_mode: 'HTML' });
});

// === COMMAND: JADWAL AUTO SHARE ===
bot.command('jadwal', async (ctx) => {
  const userId = ctx.from.id;

  if (!isAdmin(userId)) {
    return ctx.reply("⛔ Fitur jadwal khusus Admin/Owner!");
  }

  const args = ctx.message.text.split(' ').slice(1);
  const schedulers = loadScheduler();

  // /jadwal tanpa argumen = tampilkan status
  if (args.length === 0) {
    const userSched = schedulers[userId];
    let msg = `<b>📅 JADWAL AUTO SHARE</b>\n\n`;

    if (!userSched || !userSched.times || userSched.times.length === 0) {
      msg += `❌ Belum ada jadwal.\n\n`;
    } else {
      msg += `Status: ${userSched.active ? '✅ AKTIF' : '❌ NONAKTIF'}\n`;
      msg += `⏰ Jadwal:\n`;
      userSched.times.forEach((t, i) => { msg += `  ${i+1}. ${t} WIB\n`; });
      msg += `\n`;
    }

    msg += `<b>📋 CARA PAKAI:</b>\n`;
    msg += `• /jadwal add 08:00 - Tambah jadwal jam 8 pagi\n`;
    msg += `• /jadwal add 12:00 20:00 - Tambah banyak jadwal\n`;
    msg += `• /jadwal remove 08:00 - Hapus jadwal\n`;
    msg += `• /jadwal on - Aktifkan jadwal\n`;
    msg += `• /jadwal off - Nonaktifkan jadwal\n`;
    msg += `• /jadwal clear - Hapus semua jadwal\n\n`;
    msg += `⚠️ Wajib /setpesan dulu sebelum jadwal jalan!`;

    return ctx.reply(msg, { parse_mode: 'HTML' });
  }

  const subCmd = args[0].toLowerCase();

  if (subCmd === 'add') {
    const times = args.slice(1);
    if (times.length === 0) return ctx.reply("⚠️ Contoh: /jadwal add 08:00 12:00");

    const invalid = times.filter(t => !parseTimeHHMM(t));
    if (invalid.length > 0) return ctx.reply(`❌ Format jam tidak valid: ${invalid.join(', ')}\nGunakan format HH:MM (contoh: 08:00)`);

    if (!schedulers[userId]) schedulers[userId] = { times: [], active: false };
    for (const t of times) {
      if (!schedulers[userId].times.includes(t)) schedulers[userId].times.push(t);
    }
    schedulers[userId].times.sort();
    saveScheduler(schedulers);

    return ctx.reply(
      `✅ <b>JADWAL DITAMBAHKAN!</b>\n\n` +
      `⏰ Jadwal sekarang:\n${schedulers[userId].times.map((t,i) => `  ${i+1}. ${t} WIB`).join('\n')}\n\n` +
      `Ketik /jadwal on untuk mengaktifkan.`,
      { parse_mode: 'HTML' }
    );
  }

  if (subCmd === 'remove') {
    const time = args[1];
    if (!time) return ctx.reply("⚠️ Contoh: /jadwal remove 08:00");

    if (!schedulers[userId]) return ctx.reply("❌ Belum ada jadwal.");
    schedulers[userId].times = (schedulers[userId].times || []).filter(t => t !== time);
    saveScheduler(schedulers);
    stopUserScheduler(userId);
    if (schedulers[userId].active && schedulers[userId].times.length > 0) startUserScheduler(userId);

    return ctx.reply(`✅ Jadwal <b>${time}</b> dihapus.`, { parse_mode: 'HTML' });
  }

  if (subCmd === 'on') {
    if (!schedulers[userId] || !schedulers[userId].times || schedulers[userId].times.length === 0) {
      return ctx.reply("❌ Belum ada jadwal. Tambah dulu dengan /jadwal add HH:MM");
    }
    if (!userMessages.has(userId)) {
      return ctx.reply("⚠️ Wajib /setpesan dulu sebelum aktifkan jadwal!");
    }

    schedulers[userId].active = true;
    schedulers[userId].savedMsgId = userMessages.get(userId); // Simpan msgId ke file
    saveScheduler(schedulers);
    startUserScheduler(userId);

    const times = schedulers[userId].times;
    return ctx.reply(
      `✅ <b>JADWAL DIAKTIFKAN!</b>\n\n` +
      `⏰ Akan share otomatis jam:\n${times.map((t,i) => `  ${i+1}. ${t} WIB`).join('\n')}\n\n` +
      `🔄 Jadwal akan terus berjalan setiap hari.`,
      { parse_mode: 'HTML' }
    );
  }

  if (subCmd === 'off') {
    if (schedulers[userId]) { schedulers[userId].active = false; saveScheduler(schedulers); }
    stopUserScheduler(userId);
    return ctx.reply("🛑 <b>JADWAL DINONAKTIFKAN!</b>", { parse_mode: 'HTML' });
  }

  if (subCmd === 'clear') {
    if (schedulers[userId]) { schedulers[userId] = { times: [], active: false }; saveScheduler(schedulers); }
    stopUserScheduler(userId);
    return ctx.reply("🗑️ <b>SEMUA JADWAL DIHAPUS!</b>", { parse_mode: 'HTML' });
  }

  ctx.reply("⚠️ Subcommand tidak dikenal. Ketik /jadwal untuk bantuan.");
});

// === EVENT: MEMBER BARU MASUK GRUP ===
bot.on('new_chat_members', async (ctx) => {
  const welcome = loadWelcome();
  if (!welcome.active || !welcome.text) return;

  for (const member of ctx.message.new_chat_members) {
    if (member.is_bot) continue;

    const firstName = member.first_name || '';
    const lastName = member.last_name || '';
    const fullName = [firstName, lastName].filter(Boolean).join(' ');
    const username = member.username ? `@${member.username}` : fullName;
    const groupName = ctx.chat.title || 'Grup';

    // Replace placeholder
    const text = welcome.text
      .replace(/\{nama\}/gi, fullName)
      .replace(/\{username\}/gi, username)
      .replace(/\{grup\}/gi, groupName)
      .replace(/\{id\}/gi, member.id);

    const replyOptions = {
      ...(welcome.buttonText && welcome.buttonUrl
        ? Markup.inlineKeyboard([[Markup.button.url(welcome.buttonText, welcome.buttonUrl)]])
        : {})
    };

    try {
      if (welcome.photo) {
        await ctx.replyWithPhoto(welcome.photo, { caption: text, ...replyOptions });
      } else {
        await ctx.reply(text, replyOptions);
      }
    } catch (e) {
      console.log(`❌ Gagal kirim welcome di ${ctx.chat.id}: ${e.message}`);
    }
  }
});

// === COMMAND: SET WELCOME (OWNER ONLY) ===
bot.command('setwelcome', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply("⛔ Khusus Owner.");

  const welcome = loadWelcome();
  const status = welcome.active ? '✅ AKTIF' : '❌ NONAKTIF';

  await ctx.reply(
    `<blockquote>🎉 <b>PENGATURAN WELCOME MESSAGE</b>\n\n` +
    `Status: <b>${status}</b>\n\n` +
    `<b>Placeholder yang bisa dipakai:</b>\n` +
    `• <code>{nama}</code> — Nama member\n` +
    `• <code>{username}</code> — @username member\n` +
    `• <code>{grup}</code> — Nama grup\n` +
    `• <code>{id}</code> — ID member</blockquote>`,
    {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('✏️ SET TEKS', 'wlc_set_text')],
        [Markup.button.callback('🖼️ SET FOTO', 'wlc_set_photo'), Markup.button.callback('🗑️ HAPUS FOTO', 'wlc_del_photo')],
        [Markup.button.callback('🔘 SET TOMBOL', 'wlc_set_btn'), Markup.button.callback('🗑️ HAPUS TOMBOL', 'wlc_del_btn')],
        [Markup.button.callback(welcome.active ? '🔴 NONAKTIFKAN' : '🟢 AKTIFKAN', 'wlc_toggle')],
        [Markup.button.callback('👁️ PREVIEW', 'wlc_preview')]
      ])
    }
  );
});

// === CALLBACK WELCOME ===
bot.action('wlc_toggle', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  const welcome = loadWelcome();
  welcome.active = !welcome.active;
  saveWelcome(welcome);
  await ctx.answerCbQuery(`Welcome ${welcome.active ? 'DIAKTIFKAN ✅' : 'DINONAKTIFKAN 🔴'}`, { show_alert: true });
  await ctx.deleteMessage().catch(() => {});
  bot.telegram.sendMessage(ctx.from.id,
    `Welcome message sekarang: <b>${welcome.active ? '✅ AKTIF' : '❌ NONAKTIF'}</b>`,
    { parse_mode: 'HTML' }
  );
});

bot.action('wlc_set_text', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  ctx.answerCbQuery().catch(() => {});
  welcomeSetupState.set(ctx.from.id, 'awaiting_text');
  await ctx.reply(
    `✏️ <b>Kirim teks welcome message kamu.</b>\n\n` +
    `Gunakan placeholder:\n<code>{nama}</code> <code>{username}</code> <code>{grup}</code> <code>{id}</code>\n\n` +
    `HTML diperbolehkan. Kirim /batal untuk membatalkan.`,
    { parse_mode: 'HTML' }
  );
});

bot.action('wlc_set_photo', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  ctx.answerCbQuery().catch(() => {});
  welcomeSetupState.set(ctx.from.id, 'awaiting_photo');
  await ctx.reply('🖼️ <b>Kirim foto untuk welcome message.</b>\n\nKirim /batal untuk membatalkan.', { parse_mode: 'HTML' });
});

bot.action('wlc_del_photo', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  const welcome = loadWelcome();
  welcome.photo = null;
  saveWelcome(welcome);
  await ctx.answerCbQuery('🗑️ Foto dihapus!', { show_alert: true });
});

bot.action('wlc_set_btn', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  ctx.answerCbQuery().catch(() => {});
  welcomeSetupState.set(ctx.from.id, 'awaiting_btn');
  await ctx.reply(
    `🔘 <b>Kirim teks dan URL tombol dengan format:</b>\n\n` +
    `<code>Teks Tombol | https://link.com</code>\n\n` +
    `Contoh: <code>Join Channel | https://t.me/channel</code>\n\nKirim /batal untuk membatalkan.`,
    { parse_mode: 'HTML' }
  );
});

bot.action('wlc_del_btn', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  const welcome = loadWelcome();
  welcome.buttonText = null;
  welcome.buttonUrl = null;
  saveWelcome(welcome);
  await ctx.answerCbQuery('🗑️ Tombol dihapus!', { show_alert: true });
});

bot.action('wlc_preview', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  ctx.answerCbQuery().catch(() => {});
  const welcome = loadWelcome();

  if (!welcome.text) return ctx.reply('❌ Belum ada teks welcome. Set dulu dengan /setwelcome.');

  const previewText = welcome.text
    .replace(/\{nama\}/gi, ctx.from.first_name || 'Budi')
    .replace(/\{username\}/gi, ctx.from.username ? `@${ctx.from.username}` : 'Budi')
    .replace(/\{grup\}/gi, 'Nama Grup Contoh')
    .replace(/\{id\}/gi, String(ctx.from.id));

  const replyOptions = {
    ...(welcome.buttonText && welcome.buttonUrl
      ? Markup.inlineKeyboard([[Markup.button.url(welcome.buttonText, welcome.buttonUrl)]])
      : {})
  };

  try {
    if (welcome.photo) {
      await ctx.replyWithPhoto(welcome.photo, {
        caption: `👁️ PREVIEW:\n\n${previewText}`,
        ...replyOptions
      });
    } else {
      await ctx.reply(`👁️ PREVIEW:\n\n${previewText}`, replyOptions);
    }
  } catch (e) {
    console.error('Preview error:', e.message);
    await ctx.reply(`❌ Gagal preview!\n\n<code>${e.message}</code>`, { parse_mode: 'HTML' });
  }
});

// === HANDLER INPUT WELCOME SETUP ===
bot.command('batal', (ctx) => {
  if (welcomeSetupState.has(ctx.from.id)) {
    welcomeSetupState.delete(ctx.from.id);
    return ctx.reply('❌ Dibatalkan.');
  }
});

// === EVENT: AUTO TAG SETIAP PESAN DI GRUP ===
bot.on('message', async (ctx, next) => {
  const chatType = ctx.chat?.type;
  if (chatType !== 'group' && chatType !== 'supergroup') return next();
  if (!ctx.message) return next();

  // Skip pesan dari bot sendiri
  if (ctx.from?.is_bot) return next();

  const autotag = loadAutotag();
  if (!autotag.active || !autotag.text) return next();

  const senderId = ctx.from?.id;
  if (!senderId) return next();

  const users = loadData(USERS_FILE);
  let tagIds = [];

  if (autotag.mode === 'sender') {
    tagIds = [senderId];
  } else if (autotag.mode === 'all') {
    tagIds = users.filter(id => id !== senderId);
  } else if (autotag.mode === 'both') {
    tagIds = [senderId, ...users.filter(id => id !== senderId)];
  }

  if (tagIds.length === 0) return next();

  // Simpan plain text (sudah di-strip saat save)
  const cleanText = autotag.text;

  // Bagi jadi chunk max 50 per pesan
  const chunkSize = 50;
  const chunks = [];
  for (let i = 0; i < tagIds.length; i += chunkSize) {
    chunks.push(tagIds.slice(i, i + chunkSize));
  }

  try {
    for (const chunk of chunks) {
      const hideTags = buildHideTag(chunk);
      // Escape karakter HTML di teks plain agar tidak konflik dengan hidetag
      const escapedText = cleanText
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
      await ctx.reply(`${escapedText}${hideTags}`, { parse_mode: 'HTML' });
      if (chunks.length > 1) await new Promise(r => setTimeout(r, 1000));
    }
  } catch (e) {
    console.log(`❌ Autotag error di ${ctx.chat.id}: ${e.message}`);
  }

  return next();
});

// === COMMAND: SET AUTO TAG (OWNER ONLY) ===
bot.command('setautotag', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('⛔ Khusus Owner.');

  const autotag = loadAutotag();
  const status = autotag.active ? '✅ AKTIF' : '❌ NONAKTIF';
  const modeLabel = autotag.mode === 'sender' ? '👤 Pengirim saja'
    : autotag.mode === 'all' ? '👥 Semua user di database'
    : '👥 Pengirim + Semua user';

  // Strip HTML tags untuk preview teks
  const textPreview = autotag.text
    ? autotag.text.replace(/<[^>]*>/g, '').substring(0, 50) + '...'
    : null;

  await ctx.reply(
    `<blockquote>🏷️ <b>PENGATURAN AUTO TAG</b>\n\n` +
    `Status : <b>${status}</b>\n` +
    `Mode   : <b>${modeLabel}</b>\n` +
    `Teks   : ${textPreview ? `<i>${textPreview}</i>` : '<i>Belum diset</i>'}\n\n` +
    `⚠️ Bot akan auto reply + tag setiap ada pesan masuk di grup.</blockquote>`,
    {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('✏️ SET TEKS', 'atag_set_text')],
        [
          Markup.button.callback('👤 Pengirim', 'atag_mode_sender'),
          Markup.button.callback('👥 Semua', 'atag_mode_all'),
          Markup.button.callback('🔀 Keduanya', 'atag_mode_both'),
        ],
        [Markup.button.callback(autotag.active ? '🔴 NONAKTIFKAN' : '🟢 AKTIFKAN', 'atag_toggle')],
        [Markup.button.callback('👁️ PREVIEW', 'atag_preview')]
      ])
    }
  );
});

// === CALLBACK AUTO TAG ===
bot.action('atag_toggle', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  const autotag = loadAutotag();
  if (!autotag.text && !autotag.active) {
    return ctx.answerCbQuery('❌ Set teks dulu sebelum aktifkan!', { show_alert: true });
  }
  autotag.active = !autotag.active;
  saveAutotag(autotag);
  await ctx.answerCbQuery(`Auto tag ${autotag.active ? 'DIAKTIFKAN ✅' : 'DINONAKTIFKAN 🔴'}`, { show_alert: true });
  await ctx.deleteMessage().catch(() => {});
});

bot.action('atag_set_text', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  ctx.answerCbQuery().catch(() => {});
  autotagSetupState.set(ctx.from.id, 'awaiting_autotag_text');
  await ctx.reply(
    `✏️ <b>Kirim teks untuk auto tag.</b>\n\n` +
    `Teks ini akan dikirim setiap ada pesan masuk di grup.\n` +
    `HTML diperbolehkan.\n\nKirim /batal untuk membatalkan.`,
    { parse_mode: 'HTML' }
  );
});

bot.action(/^atag_mode_(sender|all|both)$/, async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  const mode = ctx.match[1];
  const autotag = loadAutotag();
  autotag.mode = mode;
  saveAutotag(autotag);
  const label = mode === 'sender' ? 'Pengirim saja' : mode === 'all' ? 'Semua user di database' : 'Pengirim + Semua user';
  await ctx.answerCbQuery(`✅ Mode: ${label}`, { show_alert: true });
});

bot.action('atag_preview', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!', { show_alert: true });
  ctx.answerCbQuery().catch(() => {});
  const autotag = loadAutotag();
  if (!autotag.text) return ctx.reply('❌ Belum ada teks. Set dulu dengan /setautotag.');

  const previewTag = buildHideTag([ctx.from.id]);
  await ctx.reply(
    `👁️ <b>PREVIEW AUTO TAG:</b>\n\n${autotag.text}${previewTag}`,
    { parse_mode: 'HTML' }
  );
});

// === COMMAND: ADDADMIN (OWNER ONLY) ===
bot.command('addadmin', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('⛔ Khusus Owner.');

  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 1) return ctx.reply(
    '❌ Format salah!\n\nContoh:\n<code>/addadmin 123456789 30d</code>\n<code>/addadmin 123456789 permanent</code>\n\nSatuan: <code>d</code>=hari, <code>h</code>=jam, <code>m</code>=bulan',
    { parse_mode: 'HTML' }
  );

  const targetId = parseInt(args[0]);
  if (isNaN(targetId)) return ctx.reply('❌ ID tidak valid!');

  const expiryStr = args[1] || 'permanent';

  const data = loadWithExpiry(ADMIN_FILE);
  const existing = data[targetId];
  const expiredAt = extendExpiry(existing?.expiredAt, expiryStr);
  if (expiredAt === false) return ctx.reply('❌ Format waktu salah!\nContoh: <code>30d</code>, <code>7d</code>, <code>1m</code>, <code>permanent</code>', { parse_mode: 'HTML' });

  const isNew = !existing;
  data[targetId] = { expiredAt, addedAt: existing?.addedAt || Date.now(), updatedAt: Date.now(), addedBy: ctx.from.id };
  saveWithExpiry(ADMIN_FILE, data);

  const expiryLabel = formatExpiry(expiredAt);
  await ctx.reply(
    `<blockquote>✅ <b>ADMIN ${isNew ? 'DITAMBAHKAN' : 'DIPERBARUI'}</b>\n\n` +
    `👤 ID     : <code>${targetId}</code>\n` +
    `⏳ Berlaku: <b>${expiryLabel}</b></blockquote>`,
    { parse_mode: 'HTML' }
  );

  bot.telegram.sendMessage(targetId,
    `<blockquote>🎉 <b>Kamu telah ${isNew ? 'diangkat menjadi' : 'diperpanjang sebagai'} ADMIN!</b>\n\n⏳ Berlaku: <b>${expiryLabel}</b></blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});
  notifCh.notifAddAdmin(bot, config, ctx, targetId, expiryLabel, isNew);
});

// === COMMAND: DELADMIN (OWNER ONLY) ===
bot.command('deladmin', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('⛔ Khusus Owner.');

  const args = ctx.message.text.split(' ').slice(1);
  if (!args[0]) return ctx.reply('❌ Format: <code>/deladmin 123456789</code>', { parse_mode: 'HTML' });

  const targetId = parseInt(args[0]);
  if (isNaN(targetId)) return ctx.reply('❌ ID tidak valid!');

  const data = loadWithExpiry(ADMIN_FILE);
  if (!data[targetId]) return ctx.reply('❌ User tersebut bukan Admin.');

  delete data[targetId];
  saveWithExpiry(ADMIN_FILE, data);

  await ctx.reply(
    `<blockquote>✅ <b>ADMIN DIHAPUS</b>\n\n👤 ID: <code>${targetId}</code></blockquote>`,
    { parse_mode: 'HTML' }
  );

  bot.telegram.sendMessage(targetId,
    `<blockquote>⚠️ <b>Akses Admin kamu telah dicabut.</b></blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});
  notifCh.notifDelAdmin(bot, config, ctx, targetId);
});

// === COMMAND: ADDPREM (OWNER & ADMIN) ===
bot.command('addprem', async (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('⛔ Khusus Admin/Owner.');

  const args = ctx.message.text.split(' ').slice(1);
  if (args.length < 1) return ctx.reply(
    '❌ Format salah!\n\nContoh:\n<code>/addprem 123456789 30d</code>\n<code>/addprem 123456789 permanent</code>\n\nSatuan: <code>d</code>=hari, <code>h</code>=jam, <code>m</code>=bulan',
    { parse_mode: 'HTML' }
  );

  const targetId = parseInt(args[0]);
  if (isNaN(targetId)) return ctx.reply('❌ ID tidak valid!');

  const expiryStr = args[1] || 'permanent';

  const data = loadWithExpiry(PREMIUM_FILE);
  const existing = data[targetId];
  const expiredAt = extendExpiry(existing?.expiredAt, expiryStr);
  if (expiredAt === false) return ctx.reply('❌ Format waktu salah!\nContoh: <code>30d</code>, <code>7d</code>, <code>1m</code>, <code>permanent</code>', { parse_mode: 'HTML' });

  const isNew = !existing;
  data[targetId] = { expiredAt, addedAt: existing?.addedAt || Date.now(), updatedAt: Date.now(), addedBy: ctx.from.id };
  saveWithExpiry(PREMIUM_FILE, data);

  const expiryLabel = formatExpiry(expiredAt);
  await ctx.reply(
    `<blockquote>✅ <b>PREMIUM ${isNew ? 'DITAMBAHKAN' : 'DIPERPANJANG'}</b>\n\n` +
    `👤 ID     : <code>${targetId}</code>\n` +
    `⏳ Berlaku: <b>${expiryLabel}</b></blockquote>`,
    { parse_mode: 'HTML' }
  );

  bot.telegram.sendMessage(targetId,
    `<blockquote>🎉 <b>Akses PREMIUM kamu telah ${isNew ? 'aktif' : 'diperpanjang'}!</b>\n\n⏳ Berlaku: <b>${expiryLabel}</b></blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});

  notifCh.notifAddPrem(bot, config, ctx, targetId, expiryLabel, isNew);
});

// === COMMAND: DELPREM (OWNER & ADMIN) ===
bot.command('delprem', async (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('⛔ Khusus Admin/Owner.');

  const args = ctx.message.text.split(' ').slice(1);
  if (!args[0]) return ctx.reply('❌ Format: <code>/delprem 123456789</code>', { parse_mode: 'HTML' });

  const targetId = parseInt(args[0]);
  if (isNaN(targetId)) return ctx.reply('❌ ID tidak valid!');

  const data = loadWithExpiry(PREMIUM_FILE);
  if (!data[targetId]) return ctx.reply('❌ User tersebut bukan Premium.');

  delete data[targetId];
  saveWithExpiry(PREMIUM_FILE, data);

  await ctx.reply(
    `<blockquote>✅ <b>PREMIUM DIHAPUS</b>\n\n👤 ID: <code>${targetId}</code></blockquote>`,
    { parse_mode: 'HTML' }
  );

  bot.telegram.sendMessage(targetId,
    `<blockquote>⚠️ <b>Akses Premium kamu telah dicabut.</b></blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});

  notifCh.notifDelPrem(bot, config, ctx, targetId);
});

// === COMMAND: LISTADMIN & LISTPREM (OWNER & ADMIN) ===
bot.command('listadmin', async (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('⛔ Khusus Admin/Owner.');
  const data = loadWithExpiry(ADMIN_FILE);
  const entries = Object.entries(data);
  if (entries.length === 0) return ctx.reply('📭 Belum ada Admin.');

  let msg = `<blockquote>🛠️ <b>DAFTAR ADMIN (${entries.length})</b>\n\n`;
  entries.forEach(([id, info], i) => {
    const status = isExpired(info.expiredAt) ? '⛔ Expired' : formatExpiry(info.expiredAt);
    msg += `${i+1}. <code>${id}</code> — ${status}\n`;
  });
  msg += `</blockquote>`;
  ctx.reply(msg, { parse_mode: 'HTML' });
});

bot.command('listprem', async (ctx) => {
  if (!isAdmin(ctx.from.id)) return ctx.reply('⛔ Khusus Admin/Owner.');
  const data = loadWithExpiry(PREMIUM_FILE);
  const entries = Object.entries(data);
  if (entries.length === 0) return ctx.reply('📭 Belum ada Premium.');

  let msg = `<blockquote>💎 <b>DAFTAR PREMIUM (${entries.length})</b>\n\n`;
  entries.forEach(([id, info], i) => {
    const status = isExpired(info.expiredAt) ? '⛔ Expired' : formatExpiry(info.expiredAt);
    msg += `${i+1}. <code>${id}</code> — ${status}\n`;
  });
  msg += `</blockquote>`;
  ctx.reply(msg, { parse_mode: 'HTML' });
});

// === COMMAND: SET AUTO BACKUP ===
bot.command('setbackup', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('⛔ Khusus Owner.');
  const args = ctx.message.text.split(' ');
  const input = args[1]?.toLowerCase().trim();

  if (!input) {
    const cur = loadBackupInterval();
    return ctx.reply(
      `<blockquote>🔄 <b>AUTO BACKUP</b>\n\n` +
      `⏱️ Interval saat ini: <b>${cur > 0 ? cur + ' jam' : 'Nonaktif'}</b>\n\n` +
      `Ubah interval:\n` +
      `<code>/setbackup 12</code> — setiap 12 jam\n` +
      `<code>/setbackup 24</code> — setiap 24 jam (1 hari)\n` +
      `<code>/setbackup 0</code> — nonaktifkan\n\n` +
      `<code>/backup</code> — backup manual sekarang</blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  const hours = parseInt(input);
  if (isNaN(hours) || hours < 0 || hours > 168) {
    return ctx.reply('❌ Masukkan angka jam antara 0—168.\n<code>/setbackup 24</code>', { parse_mode: 'HTML' });
  }

  saveBackupInterval(hours);
  startAutoBackup();

  ctx.reply(
    hours === 0
      ? `<blockquote>⏹️ <b>Auto backup dinonaktifkan.</b></blockquote>`
      : `<blockquote>✅ <b>Auto backup diatur setiap <u>${hours} jam</u></b>\n\nBackup pertama dalam ${hours} jam.\nFile dikirim ke chat ini otomatis.</blockquote>`,
    { parse_mode: 'HTML' }
  );
});

// === COMMAND: BROADCAST KE CHANNEL ===
const pendingBroadcast = new Map();

bot.command('bch', async (ctx) => {
  if (!isOwner(ctx.from.id)) return ctx.reply('⛔ Khusus Owner.');

  const replied   = ctx.message.reply_to_message;
  const plainText = ctx.message.text.split(' ').slice(1).join(' ').trim();

  if (!replied && !plainText) {
    return ctx.reply(
      `<blockquote>📢 <b>BROADCAST KE CHANNEL</b>\n\nCara pakai:\n• Reply ke pesan lalu ketik <code>/bch</code>\n• <code>/bch teks pesan</code></blockquote>`,
      { parse_mode: 'HTML' }
    );
  }

  pendingBroadcast.set(ctx.from.id, {
    msgId:     replied ? replied.message_id : null,
    chatId:    replied ? replied.chat.id : null,
    plainText: replied ? null : plainText,
  });

  ctx.reply(
    `<blockquote>📢 <b>BROADCAST — Pilih Tujuan</b>\n\nKirim ke channel mana?</blockquote>`,
    {
      parse_mode: 'HTML',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('📢 Channel 1',     'bc_ch1')],
        [Markup.button.callback('📢 Channel 2',     'bc_ch2')],
        [Markup.button.callback('📢 Semua Channel', 'bc_all')],
        [Markup.button.callback('❌ Batal',          'bc_cancel')],
      ])
    }
  );
});

bot.action('bc_cancel', async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  pendingBroadcast.delete(ctx.from.id);
  ctx.editMessageText('❌ Broadcast dibatalkan.').catch(() => {});
});

bot.action(/^bc_(ch1|ch2|all)$/, async (ctx) => {
  ctx.answerCbQuery().catch(() => {});
  const target = ctx.match[1];
  const data   = pendingBroadcast.get(ctx.from.id);
  if (!data) return ctx.editMessageText('❌ Session habis. Ulangi /bch.').catch(() => {});
  pendingBroadcast.delete(ctx.from.id);

  const targets = target === 'ch1' ? [config.CHANNEL_ID]
    : target === 'ch2' ? [config.CHANNEL_ID_2]
    : [config.CHANNEL_ID, config.CHANNEL_ID_2].filter(Boolean);

  await ctx.editMessageText('📢 Mengirim...').catch(() => {});

  let success = 0, failed = 0;
  for (const ch of targets) {
    try {
      if (data.plainText) {
        await bot.telegram.sendMessage(ch, data.plainText, { parse_mode: 'HTML' });
      } else {
        await bot.telegram.copyMessage(ch, data.chatId, data.msgId);
      }
      success++;
    } catch (e) {
      failed++;
      console.log(`[bch] ❌ ke ${ch}: ${e.message}`);
    }
  }

  ctx.editMessageText(
    `<blockquote>📢 <b>BROADCAST SELESAI</b>\n\n` +
    `📌 Tujuan : <b>${target === 'ch1' ? 'Channel 1' : target === 'ch2' ? 'Channel 2' : 'Semua Channel'}</b>\n` +
    `✅ Berhasil: <b>${success}</b>\n` +
    `❌ Gagal  : <b>${failed}</b></blockquote>`,
    { parse_mode: 'HTML' }
  ).catch(() => {});
});


// === ERROR HANDLER ===
bot.catch((err, ctx) => {
  console.error(`Error:`, err);
});

// === LAUNCH BOT ===
console.log('');
console.log('  ─────────────────────────────────────');
console.log('   Z E T E S H E R  ·  起動完了');
console.log('   system online  ·  all clear ✦');
console.log('  ─────────────────────────────────────');
console.log('');

bot.telegram.sendMessage(Number(config.OWNER_ID),
  '<blockquote>✦ <b>Z E T E S H E R</b>\n' +
  '<i>起動完了  ·  system is now online</i>\n\n' +
  '— status  : <b>running</b>\n' +
  '— time    : ' + new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' }) + '</blockquote>',
  { parse_mode: 'HTML' }
).then(() => console.log('  ✦ owner notified'))
 .catch(e => console.error('  ✗ failed to notify owner:', e.message));

restoreAllSchedulers();
startAutoBackup();
bot.launch().catch(err => console.error('❌ Launch error:', err.message));

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));